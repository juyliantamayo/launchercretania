package com.createnewrecipes.mod;

import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/**
 * Manages the Cretania block-config JSON file.
 *
 * Config location: .minecraft/config/cretania/block_config.json
 *
 * Format:
 * {
 *   "blocked_recipes":    ["namespace:recipe_id", ...],
 *   "blocked_item_usage": ["namespace:item_id", ...],
 *   "blocked_block_usage":["namespace:block_id", ...],
 *   "blocked_mod_recipes":["modid", ...]   <- removes ALL recipes from that mod
 * }
 */
public class ModConfig {

    private static ModConfig INSTANCE;

    private final Path configPath;
    private final Set<String> blockedRecipes    = new LinkedHashSet<>();
    private final Set<String> blockedItemUsage  = new LinkedHashSet<>();
    private final Set<String> blockedBlockUsage = new LinkedHashSet<>();
    private final Set<String> blockedModRecipes = new LinkedHashSet<>();

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();

    private ModConfig(Path configPath) {
        this.configPath = configPath;
    }

    // -------------------------------------------------------------------------
    // Lifecycle
    // -------------------------------------------------------------------------

    public static void init() {
        Path dir = FabricLoader.getInstance().getConfigDir().resolve("createnewrecipes");
        try { Files.createDirectories(dir); } catch (IOException ignored) {}
        Path path = dir.resolve("block_config.json");
        INSTANCE = new ModConfig(path);
        if (!Files.exists(path)) {
            INSTANCE.populateDefaults();
            INSTANCE.save();
        } else {
            INSTANCE.load();
        }
    }

    public static ModConfig getInstance() {
        if (INSTANCE == null) throw new IllegalStateException("ModConfig not yet initialized");
        return INSTANCE;
    }

    public Path getConfigPath() { return configPath; }

    // -------------------------------------------------------------------------
    // Defaults — mirrors every bloqueos_*.js script
    // -------------------------------------------------------------------------

    private void populateDefaults() {
        // --- bloqueos_create_connected.js ---
        String[] createConnected = {
            "create_connected:vertical_six_way_gearbox","create_connected:six_way_gearbox",
            "create_connected:vertical_brass_gearbox","create_connected:brass_gearbox",
            "create_connected:vertical_parallel_gearbox","create_connected:parallel_gearbox",
            "create_connected:brake","create_connected:centrifugal_clutch",
            "create_connected:freewheel_clutch","create_connected:inverted_clutch",
            "create_connected:inverted_gearshift","create_connected:overstress_clutch",
            "create_connected:shear_pin","create_connected:sequenced_pulse_generator",
            "create_connected:fan_splashing_catalyst","create_connected:fan_blasting_catalyst",
            "create_connected:fan_smoking_catalyst","create_connected:fan_haunting_catalyst"
        };
        Collections.addAll(blockedRecipes, createConnected);

        // --- bloqueos_create.js + custom assembler chains replacing vanilla recipes ---
        String[] createItems = {
            "create:mechanical_crafter","create:mechanical_arm","create:blaze_burner",
            "create:schematicannon","create:schematic_table",
            "create:smart_fluid_pipe","create:fluid_valve","create:cart_assembler",
            // These are now crafted via Cretania sequenced-assembly chains
            "create:mechanical_press","create:mechanical_drill",
            "create:mechanical_mixer","create:mechanical_saw"
        };
        Collections.addAll(blockedRecipes, createItems);

        // --- bloqueos_misc.js ---
        blockedRecipes.add("minecraft:ender_eye");
        blockedRecipes.add("minecraft:leather");

        // --- bloqueos_waystones.js ---
        String[] waystones = {
            "waystones:attuned_shard","waystones:black_sharestone","waystones:blue_sharestone",
            "waystones:brown_sharestone","waystones:crumbling_attuned_shard","waystones:cyan_sharestone",
            "waystones:deepslate_waystone","waystones:end_stone_waystone","waystones:gray_sharestone",
            "waystones:green_sharestone","waystones:light_blue_sharestone","waystones:light_gray_sharestone",
            "waystones:lime_sharestone","waystones:magenta_sharestone","waystones:mossy_waystone",
            "waystones:orange_sharestone","waystones:pink_sharestone","waystones:portstone",
            "waystones:purple_sharestone","waystones:red_sharestone","waystones:sandy_waystone",
            "waystones:scoped_sharestone","waystones:sharestone","waystones:warp_dust",
            "waystones:warp_plate","waystones:warp_stone","waystones:waystone",
            "waystones:white_sharestone","waystones:yellow_sharestone"
        };
        Collections.addAll(blockedRecipes, waystones);

        // --- bloqueos_easy_mob_farm.js ---
        String[] easyMobFarm = {
            "easy_mob_farm:ocean_farm","easy_mob_farm:pollen_trap_enhancement",
            "easy_mob_farm:sheep_enhancement","easy_mob_farm:small_slot_upgrade",
            "easy_mob_farm:speed_enhancement","easy_mob_farm:swamp_farm",
            "easy_mob_farm:sword_enhancement","easy_mob_farm:tier0_mob_farm_template",
            "easy_mob_farm:tier1_mob_farm_template","easy_mob_farm:tier2_mob_farm_template",
            "easy_mob_farm:tier3_mob_farm_template","easy_mob_farm:void_binding_chain",
            "easy_mob_farm:animal_plains_farm","easy_mob_farm:bee_hive_farm",
            "easy_mob_farm:big_slot_upgrade","easy_mob_farm:blank_mob_capture_card",
            "easy_mob_farm:creative_blank_mob_capture_card","easy_mob_farm:creative_mob_catcher",
            "easy_mob_farm:creative_mob_farm","easy_mob_farm:creative_speed_enhancement",
            "easy_mob_farm:desert_farm","easy_mob_farm:egg_collector_enhancement",
            "easy_mob_farm:enduring_capture_net","easy_mob_farm:experience_enhancement",
            "easy_mob_farm:frog_catalyst_black_enhancement","easy_mob_farm:frog_catalyst_blue_enhancement",
            "easy_mob_farm:frog_catalyst_brown_enhancement","easy_mob_farm:frog_catalyst_cold_enhancement",
            "easy_mob_farm:frog_catalyst_cyan_enhancement","easy_mob_farm:frog_catalyst_gray_enhancement",
            "easy_mob_farm:frog_catalyst_green_enhancement","easy_mob_farm:frog_catalyst_light_blue_enhancement",
            "easy_mob_farm:frog_catalyst_light_gray_enhancement","easy_mob_farm:frog_catalyst_lime_enhancement",
            "easy_mob_farm:frog_catalyst_magenta_enhancement","easy_mob_farm:frog_catalyst_orange_enhancement",
            "easy_mob_farm:frog_catalyst_pink_enhancement","easy_mob_farm:frog_catalyst_purple_enhancement",
            "easy_mob_farm:frog_catalyst_red_enhancement","easy_mob_farm:frog_catalyst_temperate_enhancement",
            "easy_mob_farm:frog_catalyst_warm_enhancement","easy_mob_farm:frog_catalyst_white_enhancement",
            "easy_mob_farm:frog_catalyst_yellow_enhancement","easy_mob_farm:honey_extractor_enhancement",
            "easy_mob_farm:honey_harvester_frame_enhancement","easy_mob_farm:iron_golem_farm",
            "easy_mob_farm:ironbound_containment_cage","easy_mob_farm:jungle_farm",
            "easy_mob_farm:knife_enhancement","easy_mob_farm:loot_enhancement",
            "easy_mob_farm:luck_enhancement","easy_mob_farm:lucky_drop_farm",
            "easy_mob_farm:milk_bottle","easy_mob_farm:milk_extractor_enhancement",
            "easy_mob_farm:mob_capture_card","easy_mob_farm:monster_plains_cave_farm",
            "easy_mob_farm:mystic_binding_crystal","easy_mob_farm:nether_fortress_farm",
            "easy_mob_farm:no_flowers_filter","easy_mob_farm:no_meat_filter"
        };
        Collections.addAll(blockedRecipes, easyMobFarm);

        // --- bloqueos_immersive_armors.js ---
        blockedRecipes.add("immersive_armors:divine_boots");
        blockedRecipes.add("immersive_armors:divine_leggings");
        blockedRecipes.add("immersive_armors:divine_chestplate");
        blockedRecipes.add("immersive_armors:divine_helmet");

        // --- bloqueos_sophisticated_backpacks.js ---
        String[] backpacks = {
            "sophisticatedbackpacks:iron_backpack","sophisticatedbackpacks:gold_backpack",
            "sophisticatedbackpacks:diamond_backpack","sophisticatedbackpacks:netherite_backpack",
            "sophisticatedbackpacks:netherite_backpacks","sophisticatedbackpacks:upgrade_base"
        };
        Collections.addAll(blockedRecipes, backpacks);

        // --- bloqueos_immersive_paintings.js  (entire mod removed) ---
        blockedModRecipes.add("immersive_paintings");

        // --- bloqueos_uso_items.js  (right-click use blocked) ---
        blockedItemUsage.add("minecraft:ender_eye");
    }

    // -------------------------------------------------------------------------
    // I/O
    // -------------------------------------------------------------------------

    public void load() {
        blockedRecipes.clear();
        blockedItemUsage.clear();
        blockedBlockUsage.clear();
        blockedModRecipes.clear();
        try (Reader r = new InputStreamReader(new FileInputStream(configPath.toFile()), StandardCharsets.UTF_8)) {
            JsonObject obj = GSON.fromJson(r, JsonObject.class);
            if (obj == null) return;
            readStringArray(obj, "blocked_recipes",     blockedRecipes);
            readStringArray(obj, "blocked_item_usage",  blockedItemUsage);
            readStringArray(obj, "blocked_block_usage", blockedBlockUsage);
            readStringArray(obj, "blocked_mod_recipes", blockedModRecipes);
        } catch (Exception e) {
            CreateNewRecipesMod.LOGGER.error("[CreateNewRecipes] Failed to load config: {}", e.getMessage());
        }
    }

    public void save() {
        try (Writer w = new OutputStreamWriter(new FileOutputStream(configPath.toFile()), StandardCharsets.UTF_8)) {
            JsonObject obj = new JsonObject();
            obj.add("blocked_recipes",     toJsonArray(blockedRecipes));
            obj.add("blocked_item_usage",  toJsonArray(blockedItemUsage));
            obj.add("blocked_block_usage", toJsonArray(blockedBlockUsage));
            obj.add("blocked_mod_recipes", toJsonArray(blockedModRecipes));
            GSON.toJson(obj, w);
        } catch (Exception e) {
            CreateNewRecipesMod.LOGGER.error("[CreateNewRecipes] Failed to save config: {}", e.getMessage());
        }
    }

    public void reload() {
        load();
        CreateNewRecipesMod.LOGGER.info("[CreateNewRecipes] Config reloaded.");
    }

    // -------------------------------------------------------------------------
    // Queries
    // -------------------------------------------------------------------------

    public boolean isRecipeBlocked(String id)   { return blockedRecipes.contains(id.toLowerCase(Locale.ROOT)); }
    public boolean isModBlocked(String modId)   { return blockedModRecipes.contains(modId.toLowerCase(Locale.ROOT)); }
    public boolean isItemUsageBlocked(String id){ return blockedItemUsage.contains(id.toLowerCase(Locale.ROOT)); }
    public boolean isBlockUsageBlocked(String id){ return blockedBlockUsage.contains(id.toLowerCase(Locale.ROOT)); }

    public Set<String> getBlockedRecipes()    { return Collections.unmodifiableSet(blockedRecipes); }
    public Set<String> getBlockedItemUsage()  { return Collections.unmodifiableSet(blockedItemUsage); }
    public Set<String> getBlockedBlockUsage() { return Collections.unmodifiableSet(blockedBlockUsage); }
    public Set<String> getBlockedModRecipes() { return Collections.unmodifiableSet(blockedModRecipes); }

    // -------------------------------------------------------------------------
    // Mutators
    // -------------------------------------------------------------------------

    public void addBlockedRecipe(String id)        { blockedRecipes.add(id.toLowerCase(Locale.ROOT)); }
    public void removeBlockedRecipe(String id)     { blockedRecipes.remove(id.toLowerCase(Locale.ROOT)); }
    public void addBlockedItemUsage(String id)     { blockedItemUsage.add(id.toLowerCase(Locale.ROOT)); }
    public void removeBlockedItemUsage(String id)  { blockedItemUsage.remove(id.toLowerCase(Locale.ROOT)); }
    public void addBlockedBlockUsage(String id)    { blockedBlockUsage.add(id.toLowerCase(Locale.ROOT)); }
    public void removeBlockedBlockUsage(String id) { blockedBlockUsage.remove(id.toLowerCase(Locale.ROOT)); }
    public void addBlockedMod(String modId)        { blockedModRecipes.add(modId.toLowerCase(Locale.ROOT)); }
    public void removeBlockedMod(String modId)     { blockedModRecipes.remove(modId.toLowerCase(Locale.ROOT)); }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------

    private static void readStringArray(JsonObject obj, String key, Set<String> target) {
        if (obj.has(key) && obj.get(key).isJsonArray()) {
            for (JsonElement el : obj.getAsJsonArray(key)) {
                if (el.isJsonPrimitive()) target.add(el.getAsString().toLowerCase(Locale.ROOT));
            }
        }
    }

    private static JsonArray toJsonArray(Set<String> set) {
        JsonArray arr = new JsonArray();
        set.stream().sorted().forEach(arr::add);
        return arr;
    }
}
