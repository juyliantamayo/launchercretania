package com.createnewrecipes.mod;

import java.nio.file.Files;
import java.nio.file.Path;

/**
 * JNI bridge to the optional createnewrecipes_native shared library.
 *
 * The library exposes:
 *   - C-callable functions (extern "C") for the Python GUI via ctypes.
 *   - JNI functions (Java_com_createnewrecipes_mod_NativeBridge_*) for Java.
 *
 * If the library is not present the mod falls back to pure-Java config I/O.
 * The library file must be placed at:
 *   .minecraft/config/createnewrecipes/createnewrecipes_native.dll  (Windows)
 *   .minecraft/config/createnewrecipes/libcreatenewrecipes_native.so (Linux/Mac)
 */
public class NativeBridge {

    private static boolean loaded = false;

    public static void tryLoad() {
        try {
            String libName = System.mapLibraryName("createnewrecipes_native");
            Path libPath = ModConfig.getInstance().getConfigPath()
                    .getParent().resolve(libName);

            if (Files.exists(libPath)) {
                System.load(libPath.toAbsolutePath().toString());
                initConfig(ModConfig.getInstance().getConfigPath().toAbsolutePath().toString());
                loaded = true;
                CreateNewRecipesMod.LOGGER.info("[CreateNewRecipes] Native bridge loaded from {}", libPath);
            } else {
                CreateNewRecipesMod.LOGGER.info("[CreateNewRecipes] Native library not found at {}. Using Java-only config I/O.", libPath);
            }
        } catch (Throwable t) {
            CreateNewRecipesMod.LOGGER.warn("[CreateNewRecipes] Native bridge unavailable: {}. Using Java-only config I/O.", t.getMessage());
        }
    }

    public static boolean isLoaded() { return loaded; }

    // -------------------------------------------------------------------------
    // Native methods — implemented in cretania_native.cpp
    // -------------------------------------------------------------------------

    /** Initialize the native config manager with the JSON file path. */
    public static native void initConfig(String configPath);

    /** Return all currently blocked recipe IDs from native state. */
    public static native String[] getBlockedRecipes();

    /** Return all currently blocked item usage IDs from native state. */
    public static native String[] getBlockedItems();

    /** Return all currently blocked block usage IDs from native state. */
    public static native String[] getBlockedBlocks();

    /** Return all mod IDs whose recipes are entirely blocked. */
    public static native String[] getBlockedMods();

    public static native void addBlockedRecipe(String id);
    public static native void removeBlockedRecipe(String id);
    public static native void addBlockedItem(String id);
    public static native void removeBlockedItem(String id);
    public static native void addBlockedBlock(String id);
    public static native void removeBlockedBlock(String id);
    public static native void addBlockedMod(String modId);
    public static native void removeBlockedMod(String modId);

    /** Persist changes to the JSON file. */
    public static native void saveConfig();

    /** Reload from the JSON file (e.g. after GUI edits). */
    public static native void reloadConfig();
}
