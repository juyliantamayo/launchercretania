package com.createnewrecipes.mod;

import net.minecraft.server.MinecraftServer;

import java.io.IOException;
import java.nio.file.*;

/**
 * Background daemon thread that watches {@code block_config.json} for external
 * changes (e.g. edits made by the Python GUI) and immediately re-applies
 * recipe-blocking rules without requiring a server restart or /reload.
 *
 * The server's recipe maps are restored from the cached originals
 * ({@link RecipeRegistry}) and the updated config is applied in-place on the
 * server thread.
 */
public class ConfigFileWatcher {

    private final MinecraftServer server;
    private final Path watchDir;
    private final String configFileName;

    private volatile boolean running = false;
    private Thread watchThread;

    public ConfigFileWatcher(MinecraftServer server) {
        this.server        = server;
        this.watchDir      = ModConfig.getInstance().getConfigPath().getParent();
        this.configFileName = ModConfig.getInstance().getConfigPath()
                                       .getFileName().toString();
    }

    // -------------------------------------------------------------------------
    // Lifecycle
    // -------------------------------------------------------------------------

    public void start() {
        if (running) return;
        running     = true;
        watchThread = new Thread(this::run, "createnewrecipes-config-watcher");
        watchThread.setDaemon(true);
        watchThread.start();
        CreateNewRecipesMod.LOGGER.info(
                "[CreateNewRecipes] Config file watcher started (watching: {})", watchDir);
    }

    public void stop() {
        running = false;
        if (watchThread != null) {
            watchThread.interrupt();
            watchThread = null;
        }
    }

    // -------------------------------------------------------------------------
    // Watch loop
    // -------------------------------------------------------------------------

    private void run() {
        try (WatchService ws = FileSystems.getDefault().newWatchService()) {
            watchDir.register(ws, StandardWatchEventKinds.ENTRY_MODIFY);

            while (running) {
                // Poll with a 2-second timeout so we can check `running` regularly
                WatchKey key = ws.poll(2, java.util.concurrent.TimeUnit.SECONDS);
                if (key == null) continue;

                boolean configChanged = false;
                for (WatchEvent<?> event : key.pollEvents()) {
                    if (event.kind() == StandardWatchEventKinds.OVERFLOW) continue;

                    @SuppressWarnings("unchecked")
                    WatchEvent<Path> ev = (WatchEvent<Path>) event;
                    if (ev.context().getFileName().toString().equals(configFileName)) {
                        configChanged = true;
                    }
                }
                key.reset();

                if (configChanged) {
                    // Brief delay so the writing process can fully flush the file
                    Thread.sleep(300);

                    // All MC state changes must happen on the server thread
                    server.execute(() -> {
                        ModConfig.getInstance().reload();
                        RecipeRegistry.reapplyBlocking(server.method_3772());
                        CreateNewRecipesMod.rebuildFromWatcher(server);
                        CreateNewRecipesMod.LOGGER.info(
                                "[CreateNewRecipes] Config hot-reloaded from file change.");
                    });
                }
            }
        } catch (ClosedWatchServiceException | InterruptedException ignored) {
            // Normal shutdown
        } catch (IOException e) {
            CreateNewRecipesMod.LOGGER.error(
                    "[CreateNewRecipes] Config file watcher error: {}", e.getMessage());
        }
    }
}
