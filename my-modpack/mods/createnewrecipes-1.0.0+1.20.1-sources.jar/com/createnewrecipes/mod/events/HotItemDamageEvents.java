package com.createnewrecipes.mod.events;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1799;
import net.minecraft.class_7923;
import java.util.Set;

/**
 * Mirrors hot_items_damage.js:
 *
 * Every second, every online server player is checked for "hot" items in their
 * inventory. If found, they are set on fire for one second — unless they are in
 * Creative / Spectator mode.
 *
 * The set of hot items is hardcoded here (matching the original KubeJS script),
 * now using the cretania: namespace.
 */
public final class HotItemDamageEvents {

    private static final Set<String> HOT_ITEMS = Set.of(
        // Sheet / laminas process
        "createnewrecipes:molten_iron",   "createnewrecipes:heated_iron_sheet",
        "createnewrecipes:molten_gold",   "createnewrecipes:heated_gold_sheet",
        "createnewrecipes:molten_copper", "createnewrecipes:heated_copper_sheet",
        // Saw process
        "createnewrecipes:hot_mechanical_blade",
        "createnewrecipes:hot_pressed_mechanical_blade",
        // Mixer process
        "createnewrecipes:hot_mechanical_whisk",
        // Drill / taladro process
        "createnewrecipes:hot_raw_steel",
        "createnewrecipes:heated_drill_head",
        // Press process
        "createnewrecipes:hot_leaded_steel",
        "createnewrecipes:mechanical_press_head_heated"
    );

    private static int tickCounter = 0;

    private HotItemDamageEvents() {}

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            // Run once per second (20 ticks)
            if (++tickCounter < 20) return;
            tickCounter = 0;

            for (var player : server.method_3760().method_14571()) {
                if (player.method_7337() || player.method_7325()) continue;
                if (hasHotItem(player.method_31548().field_7547)
                        || hasHotItem(player.method_31548().field_7544)) {
                    player.method_5639(1);
                }
            }
        });
    }

    private static boolean hasHotItem(Iterable<class_1799> slots) {
        for (class_1799 stack : slots) {
            if (!stack.method_7960()) {
                String id = class_7923.field_41178.method_10221(stack.method_7909()).toString();
                if (HOT_ITEMS.contains(id)) return true;
            }
        }
        return false;
    }
}
