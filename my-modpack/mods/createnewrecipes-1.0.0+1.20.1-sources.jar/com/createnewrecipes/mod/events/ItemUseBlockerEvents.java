package com.createnewrecipes.mod.events;

import com.createnewrecipes.mod.ModConfig;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_7923;

/**
 * Blocks right-click item use and block interaction for IDs listed in the
 * "blocked_item_usage" and "blocked_block_usage" config sets.
 *
 * Mirrors bloqueos_uso_items.js:
 *   ItemEvents.rightClicked / BlockEvents.rightClicked
 */
public final class ItemUseBlockerEvents {

    private ItemUseBlockerEvents() {}

    public static void register() {

        // ---- Intercept item right-click ----
        UseItemCallback.EVENT.register((player, world, hand) -> {
            class_1799 stack = player.method_5998(hand);
            if (stack.method_7960()) return class_1271.method_22430(stack);

            String itemId = class_7923.field_41178.method_10221(stack.method_7909()).toString();
            if (ModConfig.getInstance().isItemUsageBlocked(itemId)) {
                if (!player.method_5701()) {
                    player.method_7353(
                        class_2561.method_43469("createnewrecipes.blocked.item_use", itemId), true);
                }
                return class_1271.method_22431(stack);
            }
            return class_1271.method_22430(stack);
        });

        // ---- Intercept block right-click ----
        UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
            // Check the block being right-clicked
            var blockState = world.method_8320(hitResult.method_17777());
            String blockId = class_7923.field_41175.method_10221(blockState.method_26204()).toString();
            if (ModConfig.getInstance().isBlockUsageBlocked(blockId)) {
                if (!player.method_5701()) {
                    player.method_7353(
                        class_2561.method_43469("createnewrecipes.blocked.block_use", blockId), true);
                }
                return class_1269.field_5814;
            }

            // Also check the held item when interacting with a block
            class_1799 heldStack = player.method_5998(hand);
            if (!heldStack.method_7960()) {
                String heldItemId = class_7923.field_41178.method_10221(heldStack.method_7909()).toString();
                if (ModConfig.getInstance().isItemUsageBlocked(heldItemId)) {
                    if (!player.method_5701()) {
                        player.method_7353(
                            class_2561.method_43469("createnewrecipes.blocked.item_use", heldItemId), true);
                    }
                    return class_1269.field_5814;
                }
            }

            return class_1269.field_5811;
        });
    }
}
