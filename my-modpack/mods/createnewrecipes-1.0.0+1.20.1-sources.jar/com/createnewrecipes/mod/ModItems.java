package com.createnewrecipes.mod;

import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_7923;

/**
 * Registers every custom item introduced by Cretania Mod.
 * These replace the kubejs: items from the original KubeJS startup scripts,
 * now under the "cretania:" namespace.
 */
public final class ModItems {

    // ------------------------------------------------------------------
    // Forge Hammers  (cretania_forge_hammer.js)
    // ------------------------------------------------------------------
    public static final class_1792 FORGE_HAMMER_MK1 = simple("forge_hammer_mk1", 1);
    public static final class_1792 FORGE_HAMMER_MK2 = simple("forge_hammer_mk2", 1);
    public static final class_1792 FORGE_HAMMER_MK3 = simple("forge_hammer_mk3", 1);

    // ------------------------------------------------------------------
    // Mechanical Press process  (mehanical_press_items.js)
    // ------------------------------------------------------------------
    public static final class_1792 STEEL_COATED_ROD              = simple("steel_coated_rod", 64);
    public static final class_1792 COATED_CASING                 = simple("coated_casing", 64);
    public static final class_1792 HOT_LEADED_STEEL              = simple("hot_leaded_steel", 64);
    public static final class_1792 INCOMPLETE_PRESS_CASING_MK1   = simple("incomplete_press_casing_mk1", 64);
    public static final class_1792 INCOMPLETE_PRESS_CASING_MK2   = simple("incomplete_press_casing_mk2", 64);
    public static final class_1792 INCOMPLETE_PRESS_CASING_MK3   = simple("incomplete_press_casing_mk3", 64);
    public static final class_1792 PISTON_EXTENSION_HALF         = simple("piston_extension_half", 64);
    public static final class_1792 MECHANICAL_PRESS_HEAD_HEATED  = simple("mechanical_press_head_heated", 64);
    public static final class_1792 MECHANICAL_PRESS_HEAD_TEMPERED= simple("mechanical_press_head_tempered", 64);
    public static final class_1792 MECHANICAL_PRESS_PISTON       = simple("mechanical_press_piston", 64);

    // ------------------------------------------------------------------
    // Drill / Taladro process  (taladro_items.js)
    // ------------------------------------------------------------------
    public static final class_1792 STEEL_COATED_INGOT           = simple("steel_coated_ingot", 64);
    public static final class_1792 INCOMPLETE_COATED_INGOT      = simple("incomplete_coated_ingot", 1);
    public static final class_1792 HOT_RAW_STEEL                = simple("hot_raw_steel", 64);
    public static final class_1792 FRAGILE_DRILL_HEAD           = simple("fragile_drill_head", 64);
    public static final class_1792 HEATED_DRILL_HEAD            = simple("heated_drill_head", 64);
    public static final class_1792 TEMPERED_DRILL_HEAD          = simple("tempered_drill_head", 64);
    public static final class_1792 INCOMPLETE_DRILL_HEAD        = simple("incomplete_drill_head", 1);

    // ------------------------------------------------------------------
    // Brass process  (cretania_brass_process_items.js)
    // ------------------------------------------------------------------
    public static final class_1792 IMPURE_LEAD_RESIDUE  = simple("impure_lead_residue", 64);
    public static final class_1792 RAW_LEAD             = simple("raw_lead", 64);
    public static final class_1792 MALLEABLE_COPPER     = simple("malleable_copper", 64);
    public static final class_1792 ADHERABLE_ZINC       = simple("adherable_zinc", 64);
    public static final class_1792 MALLEABLE_BRASS      = simple("malleable_brass", 64);
    public static final class_1792 MALLEABLE_BRASS_1    = simple("malleable_brass_1", 1);
    public static final class_1792 MALLEABLE_BRASS_2    = simple("malleable_brass_2", 1);

    // ------------------------------------------------------------------
    // Mechanical Mixer process  (cretania_mechanical_mixer_items.js)
    // ------------------------------------------------------------------
    public static final class_1792 MECHANICAL_WHISK   = simple("mechanical_whisk", 64);
    public static final class_1792 MECHANICAL_WHISK_1 = simple("mechanical_whisk_1", 64);
    public static final class_1792 MECHANICAL_WHISK_2 = simple("mechanical_whisk_2", 64);
    public static final class_1792 MECHANICAL_WHISK_3 = simple("mechanical_whisk_3", 64);
    public static final class_1792 HOT_MECHANICAL_WHISK = simple("hot_mechanical_whisk", 64);
    public static final class_1792 COGWHEEL_CASING    = simple("cogwheel_casing", 64);

    // ------------------------------------------------------------------
    // Mechanical Saw process  (cretania_mechanical_saw_items.js)
    // ------------------------------------------------------------------
    public static final class_1792 MECHANICAL_BLADE              = simple("mechanical_blade", 64);
    public static final class_1792 PRESSED_MECHANICAL_BLADE      = simple("pressed_mechanical_blade", 64);
    public static final class_1792 MECHANICAL_BLADE_1            = simple("mechanical_blade_1", 64);
    public static final class_1792 MECHANICAL_BLADE_2            = simple("mechanical_blade_2", 64);
    public static final class_1792 MECHANICAL_BLADE_3            = simple("mechanical_blade_3", 64);
    public static final class_1792 HOT_MECHANICAL_BLADE          = simple("hot_mechanical_blade", 64);
    public static final class_1792 HOT_PRESSED_MECHANICAL_BLADE  = simple("hot_pressed_mechanical_blade", 64);
    public static final class_1792 TEMPERED_MECHANICAL_BLADE     = simple("tempered_mechanical_blade", 64);

    // ------------------------------------------------------------------
    // Sheet / Laminas process — Iron  (cretania_proceso_laminas_items.js)
    // ------------------------------------------------------------------
    public static final class_1792 IMPURE_IRON_RESIDUE           = simple("impure_iron_residue", 64);
    public static final class_1792 CRUDE_IRON                    = simple("crude_iron", 64);
    public static final class_1792 MOLTEN_IRON                   = simple("molten_iron", 64);
    public static final class_1792 FRAGILE_IRON_SHEET            = simple("fragile_iron_sheet", 64);
    public static final class_1792 INCOMPLETE_FRAGILE_IRON_SHEET = simple("incomplete_fragile_iron_sheet", 1);
    public static final class_1792 HEATED_IRON_SHEET             = simple("heated_iron_sheet", 64);

    // ------------------------------------------------------------------
    // Sheet / Laminas process — Gold
    // ------------------------------------------------------------------
    public static final class_1792 IMPURE_GOLD_RESIDUE           = simple("impure_gold_residue", 64);
    public static final class_1792 CRUDE_GOLD                    = simple("crude_gold", 64);
    public static final class_1792 MOLTEN_GOLD                   = simple("molten_gold", 64);
    public static final class_1792 FRAGILE_GOLD_SHEET            = simple("fragile_gold_sheet", 64);
    public static final class_1792 INCOMPLETE_FRAGILE_GOLD_SHEET = simple("incomplete_fragile_gold_sheet", 1);
    public static final class_1792 HEATED_GOLD_SHEET             = simple("heated_gold_sheet", 64);

    // ------------------------------------------------------------------
    // Sheet / Laminas process — Copper
    // ------------------------------------------------------------------
    public static final class_1792 IMPURE_COPPER_RESIDUE           = simple("impure_copper_residue", 64);
    public static final class_1792 CRUDE_COPPER                    = simple("crude_copper", 64);
    public static final class_1792 MOLTEN_COPPER                   = simple("molten_copper", 64);
    public static final class_1792 FRAGILE_COPPER_SHEET            = simple("fragile_copper_sheet", 64);
    public static final class_1792 INCOMPLETE_FRAGILE_COPPER_SHEET = simple("incomplete_fragile_copper_sheet", 1);
    public static final class_1792 HEATED_COPPER_SHEET             = simple("heated_copper_sheet", 64);

    // ------------------------------------------------------------------

    private ModItems() {}

    /** Call from CreateNewRecipesMod.onInitialize() to trigger class loading / registration. */
    public static void register() {
        CreateNewRecipesMod.LOGGER.info("[CreateNewRecipes] Items registered.");
    }

    private static class_1792 simple(String name, int maxStack) {
        class_1792 item = new class_1792(new class_1792.class_1793().method_7889(maxStack));
        class_2378.method_10230(class_7923.field_41178, CreateNewRecipesMod.id(name), item);
        return item;
    }
}
