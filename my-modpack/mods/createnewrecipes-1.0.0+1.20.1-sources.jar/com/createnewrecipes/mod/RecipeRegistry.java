package com.createnewrecipes.mod;

import java.util.*;
import net.minecraft.class_1799;
import net.minecraft.class_1860;
import net.minecraft.class_1863;
import net.minecraft.class_2960;
import net.minecraft.class_3956;
import net.minecraft.class_5455;
import net.minecraft.class_7923;

/**
 * Holds a snapshot of the original (unfiltered) recipe maps loaded by the server,
 * and provides a static method to re-apply the current blocking rules at any time
 * without requiring a full server restart.
 *
 * Workflow:
 *   1. RecipeBlockerMixin.onRecipesLoaded() calls {@link #cacheOriginals} once per world load.
 *   2. Whenever the config changes (FileWatcher, /createnewrecipes reload, GUI save),
 *      call {@link #reapplyBlocking(class_1863)} to restore originals and re-filter.
 */
public final class RecipeRegistry {

    private static volatile Map<class_2960, class_1860<?>> originalByName = null;
    private static volatile Map<class_3956<?>, Map<class_2960, class_1860<?>>> originalByType = null;

    private RecipeRegistry() {}

    // -------------------------------------------------------------------------
    // Cache management
    // -------------------------------------------------------------------------

    /**
     * Stores a deep copy of the full recipe maps BEFORE any blocking is applied.
     * Called once by the mixin each time the server loads recipes.
     */
    public static void cacheOriginals(
            Map<class_2960, class_1860<?>> byName,
            Map<class_3956<?>, Map<class_2960, class_1860<?>>> byType) {

        originalByName = new HashMap<>(byName);

        Map<class_3956<?>, Map<class_2960, class_1860<?>>> copy = new HashMap<>();
        byType.forEach((type, m) -> copy.put(type, new HashMap<>(m)));
        originalByType = copy;
    }

    public static boolean hasCachedOriginals() {
        return originalByName != null;
    }

    public static Map<class_2960, class_1860<?>> getOriginalByName()  { return originalByName; }
    public static Map<class_3956<?>, Map<class_2960, class_1860<?>>> getOriginalByType() { return originalByType; }

    /**
     * Re-caches originals from the CURRENT RecipeManager state, merging back
     * any recipes that we previously blocked so the cache is a complete snapshot
     * including KubeJS/other-mod changes but without our blocking.
     * Call from END_DATA_PACK_RELOAD to capture post-KubeJS recipe state.
     */
    public static void reCacheFromLive(class_1863 manager) {
        // Use public getRecipes() instead of accessor to read live state reliably
        Map<class_2960, class_1860<?>> live = new HashMap<>();
        Map<class_3956<?>, Map<class_2960, class_1860<?>>> liveByType = new HashMap<>();
        for (class_1860<?> recipe : manager.method_8126()) {
            live.put(recipe.method_8114(), recipe);
            liveByType.computeIfAbsent(recipe.method_17716(), k -> new HashMap<>())
                      .put(recipe.method_8114(), recipe);
        }

        // Merge back any recipes from old originals that are absent in current live
        // (these were removed by our blocking; we want them back in the clean cache)
        if (originalByName != null) {
            for (var entry : originalByName.entrySet()) {
                live.putIfAbsent(entry.getKey(), entry.getValue());
                liveByType.computeIfAbsent(entry.getValue().method_17716(), k -> new HashMap<>())
                        .putIfAbsent(entry.getKey(), entry.getValue());
            }
        }

        originalByName = live;
        originalByType = liveByType;

        CreateNewRecipesMod.LOGGER.info(
                "[CreateNewRecipes] Re-cached {} originals from live RecipeManager (post-KubeJS).",
                live.size());
    }

    // -------------------------------------------------------------------------
    // Hot-reload
    // -------------------------------------------------------------------------

    /**
     * Restores the original recipe maps and re-applies the current blocking rules.
     * Safe to call from the server thread at any time after world load.
     *
     * @param manager the server's live RecipeManager
     */
    public static void reapplyBlocking(class_1863 manager) {
        if (originalByName == null) {
            CreateNewRecipesMod.LOGGER.warn(
                    "[CreateNewRecipes] Hot-reload skipped — recipe cache not built yet.");
            return;
        }

        int origSize = originalByName.size();

        // Restore from originals
        Map<class_2960, class_1860<?>> byName = new HashMap<>(originalByName);
        Map<class_3956<?>, Map<class_2960, class_1860<?>>> byType = new HashMap<>();
        originalByType.forEach((type, m) -> byType.put(type, new HashMap<>(m)));

        // Apply current blocking rules
        applyBlocking(byName, byType);

        int filteredSize = byName.size();

        // Write back using vanilla replaceRecipes() — guaranteed to set the fields
        manager.method_20702(byName.values());

        // Verify
        int verifySize = manager.method_8126().size();
        CreateNewRecipesMod.LOGGER.info(
                "[CreateNewRecipes] Hot-reload: originals={}, afterBlock={}, verify={}",
                origSize, filteredSize, verifySize);
    }

    // -------------------------------------------------------------------------
    // Core blocking logic (shared by initial load and hot-reload)
    // -------------------------------------------------------------------------

    /**
     * Removes blocked entries in-place from the provided recipe maps.
     * Uses the current state of {@link ModConfig}.
     *
     * Two-pass approach:
     *  Pass 1 — direct recipe-ID match (fast, O(1) per blocked ID).
     *  Pass 2 — output item-ID scan: for IDs that didn't match as recipe IDs,
     *           scan all remaining recipes and remove those whose output item
     *           matches the blocked ID.
     */
    public static void applyBlocking(
            Map<class_2960, class_1860<?>> byName,
            Map<class_3956<?>, Map<class_2960, class_1860<?>>> byType) {

        ModConfig config;
        try {
            config = ModConfig.getInstance();
        } catch (IllegalStateException e) {
            return;
        }

        int removed = 0;

        // ---- Pass 1: Block by direct recipe ID ----
        Set<String> blockedRecipes = config.getBlockedRecipes();
        CreateNewRecipesMod.LOGGER.info(
                "[CreateNewRecipes] applyBlocking: {} blocked IDs in config, {} recipes in map",
                blockedRecipes.size(), byName.size());
        Set<class_2960> unmatchedAsRecipeId = new HashSet<>();
        for (String id : blockedRecipes) {
            class_2960 loc = class_2960.method_12829(id);
            if (loc == null) continue;
            class_1860<?> recipe = byName.remove(loc);
            if (recipe != null) {
                Map<class_2960, class_1860<?>> typeMap = byType.get(recipe.method_17716());
                if (typeMap != null) typeMap.remove(loc);
                removed++;
            } else {
                unmatchedAsRecipeId.add(loc);
            }
        }
        CreateNewRecipesMod.LOGGER.info(
                "[CreateNewRecipes] Pass 1 (recipe ID): removed={}, unmatched={}",
                removed, unmatchedAsRecipeId.size());

        // ---- Pass 2: Block by output item ID (for entries that didn't match as recipe IDs) ----
        int removedPass2 = 0;
        if (!unmatchedAsRecipeId.isEmpty()) {
            List<class_2960> toRemove = new ArrayList<>();
            for (Map.Entry<class_2960, class_1860<?>> entry : byName.entrySet()) {
                try {
                    class_1799 result = entry.getValue().method_8110(class_5455.field_40585);
                    if (!result.method_7960()) {
                        class_2960 itemId = class_7923.field_41178.method_10221(result.method_7909());
                        if (unmatchedAsRecipeId.contains(itemId)) {
                            toRemove.add(entry.getKey());
                        }
                    }
                } catch (Exception ignored) {}
            }
            for (class_2960 loc : toRemove) {
                class_1860<?> r = byName.remove(loc);
                if (r != null) {
                    Map<class_2960, class_1860<?>> typeMap = byType.get(r.method_17716());
                    if (typeMap != null) typeMap.remove(loc);
                    removedPass2++;
                }
            }
            removed += removedPass2;
            CreateNewRecipesMod.LOGGER.info(
                    "[CreateNewRecipes] Pass 2 (item ID scan): removed={}", removedPass2);
        }

        // ---- Block all recipes from specified mods ----
        Set<String> blockedMods = config.getBlockedModRecipes();
        if (!blockedMods.isEmpty()) {
            List<class_2960> toRemoveMod = new ArrayList<>();
            for (class_2960 loc : byName.keySet()) {
                if (blockedMods.contains(loc.method_12836())) {
                    toRemoveMod.add(loc);
                }
            }
            for (class_2960 loc : toRemoveMod) {
                byName.remove(loc);
                byType.values().forEach(m -> m.remove(loc));
            }
        }

        if (removed > 0 || !blockedMods.isEmpty()) {
            CreateNewRecipesMod.LOGGER.info(
                    "[CreateNewRecipes] Blocked {} individual recipes and recipes from {} mods.",
                    removed, blockedMods.size());
        }
    }
}
