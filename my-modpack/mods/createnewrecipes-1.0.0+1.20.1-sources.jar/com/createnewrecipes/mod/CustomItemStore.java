package com.createnewrecipes.mod;

import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/**
 * Reads and writes the list of user-defined custom items from/to
 *   config/createnewrecipes/custom_items.json
 *
 * Thread-safety: all public methods are synchronised so they can safely
 * be called from the server thread while the config-file watcher may run
 * concurrently (though we don't expect high contention here).
 */
public final class CustomItemStore {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();

    private static Path configPath() {
        return FabricLoader.getInstance().getConfigDir()
                .resolve("createnewrecipes")
                .resolve("custom_items.json");
    }

    private CustomItemStore() {}

    // ── I/O ──────────────────────────────────────────────────────────────────

    public static synchronized List<CustomItemDefinition> load() {
        Path path = configPath();
        List<CustomItemDefinition> result = new ArrayList<>();
        if (!Files.exists(path)) return result;
        try (Reader r = new InputStreamReader(
                new FileInputStream(path.toFile()), StandardCharsets.UTF_8)) {
            JsonArray arr = GSON.fromJson(r, JsonArray.class);
            if (arr == null) return result;
            for (JsonElement el : arr) {
                if (!el.isJsonObject()) continue;
                JsonObject obj = el.getAsJsonObject();
                String id = str(obj, "id", "").strip()
                        .toLowerCase().replaceAll("[^a-z0-9_/]", "_");
                if (id.isEmpty()) continue;
                result.add(new CustomItemDefinition(
                        id,
                        str(obj, "displayName", "Custom Item"),
                        clamp(getInt(obj, "maxStack",  64), 1, 64),
                        Math.max(0, getInt(obj, "durability", 0)),
                        str(obj, "parentModel", CustomItemDefinition.PARENT_GENERATED),
                        str(obj, "textureB64", "")
                ));
            }
        } catch (Exception e) {
            CreateNewRecipesMod.LOGGER.warn(
                    "[CNR-Items] Could not load custom_items.json: {}", e.getMessage());
        }
        return result;
    }

    public static synchronized void save(List<CustomItemDefinition> defs) {
        Path path = configPath();
        try { Files.createDirectories(path.getParent()); } catch (IOException ignored) {}
        JsonArray arr = new JsonArray();
        for (CustomItemDefinition d : defs) {
            JsonObject obj = new JsonObject();
            obj.addProperty("id",          d.id());
            obj.addProperty("displayName", d.displayName());
            obj.addProperty("maxStack",    d.maxStack());
            obj.addProperty("durability",  d.durability());
            obj.addProperty("parentModel", d.parentModel());
            obj.addProperty("textureB64",  d.textureB64() != null ? d.textureB64() : "");
            arr.add(obj);
        }
        try (Writer w = new OutputStreamWriter(
                new FileOutputStream(path.toFile()), StandardCharsets.UTF_8)) {
            GSON.toJson(arr, w);
        } catch (Exception e) {
            CreateNewRecipesMod.LOGGER.error(
                    "[CNR-Items] Could not save custom_items.json: {}", e.getMessage());
        }
    }

    // ── CRUD helpers ─────────────────────────────────────────────────────────

    /** Add or replace (by id) a definition. Persists immediately. */
    public static synchronized void upsert(CustomItemDefinition def) {
        List<CustomItemDefinition> list = new ArrayList<>(load());
        list.removeIf(d -> d.id().equals(def.id()));
        list.add(def);
        save(list);
    }

    /** Remove a definition by id. Persists immediately. */
    public static synchronized boolean remove(String id) {
        List<CustomItemDefinition> list = new ArrayList<>(load());
        boolean removed = list.removeIf(d -> d.id().equals(id));
        if (removed) save(list);
        return removed;
    }

    // ── JSON helpers ──────────────────────────────────────────────────────────

    private static String str(JsonObject obj, String key, String def) {
        return obj.has(key) && obj.get(key).isJsonPrimitive()
                ? obj.get(key).getAsString() : def;
    }

    private static int getInt(JsonObject obj, String key, int def) {
        try {
            return obj.has(key) ? obj.get(key).getAsInt() : def;
        } catch (Exception e) { return def; }
    }

    private static int clamp(int v, int min, int max) {
        return Math.max(min, Math.min(max, v));
    }
}
