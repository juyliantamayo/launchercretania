package com.createnewrecipes.mod;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.server.MinecraftServer;

/**
 * Registers the {@code /createnewrecipes reload} server command (requires OP level 2).
 *
 * This command:
 *   1. Reloads {@code block_config.json} from disk into {@link ModConfig}.
 *   2. Re-applies the new blocking rules live via {@link RecipeRegistry#reapplyBlocking},
 *      without requiring a full server restart or {@code /reload}.
 */
public class RecipeReloadCommand {

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(
            class_2170.method_9247("createnewrecipes")
                .requires(src -> src.method_9259(2))
                .then(class_2170.method_9247("reload")
                    .executes(ctx -> {
                        MinecraftServer server = ctx.getSource().method_9211();

                        ModConfig.getInstance().reload();
                        RecipeRegistry.reapplyBlocking(server.method_3772());

                        ctx.getSource().method_9226(
                            () -> class_2561.method_43470(
                                "[CreateNewRecipes] Config reloaded — recipe blocking updated live."),
                            true);

                        return 1;
                    }))
        );
    }
}
