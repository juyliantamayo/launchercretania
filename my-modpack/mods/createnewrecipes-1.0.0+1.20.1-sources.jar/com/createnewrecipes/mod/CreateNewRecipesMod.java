package com.createnewrecipes.mod;

import com.createnewrecipes.mod.events.HotItemDamageEvents;
import com.createnewrecipes.mod.events.ItemUseBlockerEvents;
import com.createnewrecipes.mod.network.ConfigPackets;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2540;
import net.minecraft.class_2788;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

public class CreateNewRecipesMod implements ModInitializer {

    public static final String MOD_ID = "createnewrecipes";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    /** Current active config-file watcher; null when no server is running. */
    private static ConfigFileWatcher configWatcher = null;

    /** SQLite database for user-created custom recipes. */
    private static RecipeDatabase recipeDb = null;

    /** Live server reference — set on SERVER_STARTED, cleared on SERVER_STOPPING. */
    private static volatile MinecraftServer currentServer = null;

    @Override
    public void onInitialize() {
        LOGGER.info("[CreateNewRecipes] Initializing Create New Recipes Mod...");

        // Register all custom items and creative tab
        ModItems.register();
        ModCreativeTab.register();

        // Initialize config (creates default file + loads existing)
        ModConfig.init();

        // Attempt to load optional C++ native bridge (non-fatal if absent)
        NativeBridge.tryLoad();

        // Register Fabric event listeners
        ItemUseBlockerEvents.register();
        HotItemDamageEvents.register();

        // Register /createnewrecipes reload command
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                RecipeReloadCommand.register(dispatcher));

        // ── In-game GUI network handlers ────────────────────────────────────

        // C2S: client requests config snapshot → send S2C_DATA + S2C_CUSTOM_RECIPES
        ServerPlayNetworking.registerGlobalReceiver(ConfigPackets.C2S_REQUEST,
                (server, player, handler, buf, sender) -> {
                    if (!player.method_5687(4)) return; // OP level 4 only
                    server.execute(() -> {
                        sendConfigToPlayer(player);
                        sendCustomRecipes(player);
                    });
                });

        // C2S: client applies one add/remove operation
        ServerPlayNetworking.registerGlobalReceiver(ConfigPackets.C2S_MODIFY,
                (server, player, handler, buf, sender) -> {
                    if (!player.method_5687(4)) return;
                    byte op    = buf.readByte();
                    String val = buf.method_19772();
                    server.execute(() -> {
                        LOGGER.info("[CreateNewRecipes] C2S_MODIFY op={} val='{}'", op, val);
                        ModConfig cfg = ModConfig.getInstance();
                        applyOp(cfg, op, val);
                        cfg.save();
                        LOGGER.info("[CreateNewRecipes] Config saved. Blocked recipes count: {}",
                                cfg.getBlockedRecipes().size());
                        RecipeRegistry.reapplyBlocking(server.method_3772());
                        // Keep custom recipes alive after blocking re-apply
                        rebuildCustomRecipes(server);
                        // Broadcast updated config to ALL connected OP players
                        broadcastConfig(server);
                        LOGGER.info("[CreateNewRecipes] Auto-reload complete for op={} val='{}'", op, val);
                    });
                });

        // C2S: client sends a new recipe to save in the database
        ServerPlayNetworking.registerGlobalReceiver(ConfigPackets.C2S_NEW_RECIPE,
                (server, player, handler, buf, sender) -> {
                    if (!player.method_5687(4)) return;
                    String type         = buf.method_19772();
                    String recipeId     = buf.method_19772();
                    boolean consumeInput = buf.readBoolean();
                    int count           = buf.method_10816();
                    List<String> fields = new ArrayList<>();
                    for (int i = 0; i < count; i++) fields.add(buf.method_19772());
                    server.execute(() -> {
                        if (recipeDb != null) {
                            recipeDb.saveRecipe(type, recipeId, consumeInput, fields);
                        }
                        // Inject the new recipe immediately into the live RecipeManager
                        rebuildCustomRecipes(server);
                        // Broadcast updated recipe list to ALL connected players
                        broadcastCustomRecipes(server);
                    });
                });

        // C2S: client requests deletion of a custom recipe
        ServerPlayNetworking.registerGlobalReceiver(ConfigPackets.C2S_DELETE_CUSTOM,
                (server, player, handler, buf, sender) -> {
                    if (!player.method_5687(4)) return;
                    String recipeId = buf.method_19772();
                    server.execute(() -> {
                        if (recipeDb != null) recipeDb.deleteRecipe(recipeId);
                        // Rebuild recipes without the deleted one
                        RecipeRegistry.reapplyBlocking(server.method_3772());
                        rebuildCustomRecipes(server);
                        // Broadcast updated recipe list to ALL connected players
                        broadcastCustomRecipes(server);
                    });
                });

        // Auto-sync config + recipes when any player joins the server
        ServerPlayConnectionEvents.JOIN.register((handler2, sender2, server2) ->
                server2.execute(() -> {
                    class_3222 joiner = handler2.field_14140;
                    // Give the join packet a moment to settle (next tick is fine)
                    sendConfigToPlayer(joiner);
                    sendCustomRecipes(joiner);
                }));

        // Re-cache originals then re-inject custom recipes after any data-pack reload
        // This fires AFTER KubeJS and other mods have modified recipes,
        // so our originals cache captures the complete post-mod state.
        ServerLifecycleEvents.END_DATA_PACK_RELOAD.register((server, resourceManager, success) -> {
            if (!success) return;
            RecipeRegistry.reCacheFromLive(server.method_3772());
            RecipeRegistry.reapplyBlocking(server.method_3772());
            rebuildCustomRecipes(server);
        });

        // Start config file-watcher when server is ready; stop it on shutdown
        ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            currentServer = server;
            // Open SQLite database
            recipeDb = new RecipeDatabase(
                    net.fabricmc.loader.api.FabricLoader.getInstance().getConfigDir());
            recipeDb.open();

            configWatcher = new ConfigFileWatcher(server);
            configWatcher.start();

            // Inject any custom recipes saved from previous sessions
            rebuildCustomRecipes(server);
        });

        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            currentServer = null;
            if (configWatcher != null) {
                configWatcher.stop();
                configWatcher = null;
            }
            if (recipeDb != null) {
                recipeDb.close();
                recipeDb = null;
            }
        });

        LOGGER.info("[CreateNewRecipes] Initialization complete.");
    }

    /** Helper to create a ResourceLocation in the createnewrecipes namespace. */
    public static class_2960 id(String path) {
        return new class_2960(MOD_ID, path);
    }

    // ── Packet helpers ────────────────────────────────────────────────────────

    private static void writeStringSet(class_2540 buf, Set<String> set) {
        List<String> sorted = new ArrayList<>(set);
        Collections.sort(sorted);
        buf.method_10804(sorted.size());
        sorted.forEach(buf::method_10814);
    }

    /** Send the full custom-recipes list to a single player. */
    private static void sendCustomRecipes(net.minecraft.class_3222 player) {
        List<RecipeDatabase.CustomRecipeEntry> list =
                (recipeDb != null) ? recipeDb.getAllRecipes() : List.of();
        class_2540 buf = buildCustomRecipesBuf(list);
        ServerPlayNetworking.send(player, ConfigPackets.S2C_CUSTOM_RECIPES, buf);
    }

    /** Broadcast the full custom-recipes list to ALL connected players. */
    private static void broadcastCustomRecipes(MinecraftServer server) {
        List<RecipeDatabase.CustomRecipeEntry> list =
                (recipeDb != null) ? recipeDb.getAllRecipes() : List.of();
        for (class_3222 p : server.method_3760().method_14571()) {
            ServerPlayNetworking.send(p, ConfigPackets.S2C_CUSTOM_RECIPES, buildCustomRecipesBuf(list));
        }
    }

    /** Builds a S2C_CUSTOM_RECIPES buffer from a recipe list. */
    private static class_2540 buildCustomRecipesBuf(List<RecipeDatabase.CustomRecipeEntry> list) {
        class_2540 buf = PacketByteBufs.create();
        buf.method_10804(list.size());
        for (RecipeDatabase.CustomRecipeEntry e : list) {
            buf.method_10814(e.type());
            buf.method_10814(e.recipeId());
            buf.writeBoolean(e.consumeInput());
            buf.method_10814(e.createdAt());
            buf.method_10804(e.fields().size());
            e.fields().forEach(buf::method_10814);
        }
        return buf;
    }

    /** Build and send a S2C_DATA config packet to a single player. */
    private static void sendConfigToPlayer(class_3222 player) {
        ModConfig cfg = ModConfig.getInstance();
        class_2540 out = PacketByteBufs.create();
        writeStringSet(out, cfg.getBlockedRecipes());
        writeStringSet(out, cfg.getBlockedItemUsage());
        writeStringSet(out, cfg.getBlockedBlockUsage());
        writeStringSet(out, cfg.getBlockedModRecipes());
        ServerPlayNetworking.send(player, ConfigPackets.S2C_DATA, out);
    }

    /** Broadcast the full config snapshot to ALL connected OP players. */
    private static void broadcastConfig(MinecraftServer server) {
        for (class_3222 p : server.method_3760().method_14571()) {
            if (p.method_5687(4)) sendConfigToPlayer(p);
        }
    }

    /**
     * Injects all custom recipes from the DB into the live RecipeManager,
     * then syncs the updated recipe list to all connected clients so that
     * EMI/JEI refresh immediately without needing /reload.
     */
    private static void rebuildCustomRecipes(MinecraftServer server) {
        if (recipeDb == null) return;
        List<RecipeDatabase.CustomRecipeEntry> entries = recipeDb.getAllRecipes();
        CreateRecipeInjector.injectAll(server.method_3772(), entries);
        syncRecipesToClients(server);
    }

    /** Called by ConfigFileWatcher after hot-reloading blocking rules. */
    public static void rebuildFromWatcher(MinecraftServer server) {
        rebuildCustomRecipes(server);
    }

    /**
     * Sends ClientboundUpdateRecipesPacket to every connected player so their
     * client-side RecipeManager (and EMI/JEI) sees the latest recipe list.
     */
    private static void syncRecipesToClients(MinecraftServer server) {
        class_2788 packet =
                new class_2788(server.method_3772().method_8126());
        for (class_3222 player : server.method_3760().method_14571()) {
            player.field_13987.method_14364(packet);
        }
    }

    /**
     * Called by {@link com.createnewrecipes.mod.mixin.RecipeBlockerMixin} at the
     * end of every RecipeManager.apply() — including KubeJS reloads that happen
     * after SERVER_STARTED. Re-injects custom recipes so they survive any reload,
     * then syncs to clients if the server is running.
     */
    public static void reinjectFromMixin(net.minecraft.class_1863 manager) {
        if (recipeDb == null) return;
        List<RecipeDatabase.CustomRecipeEntry> entries = recipeDb.getAllRecipes();
        if (!entries.isEmpty()) {
            CreateRecipeInjector.injectAll(manager, entries);
            // Sync to clients when the server is live (not during initial startup load)
            MinecraftServer srv = currentServer;
            if (srv != null && !srv.method_3760().method_14571().isEmpty()) {
                syncRecipesToClients(srv);
            }
        }
    }

    private static void applyOp(ModConfig cfg, byte op, String value) {
        switch (op) {
            case ConfigPackets.ADD_RECIPE    -> cfg.addBlockedRecipe(value);
            case ConfigPackets.REMOVE_RECIPE -> cfg.removeBlockedRecipe(value);
            case ConfigPackets.ADD_ITEM      -> cfg.addBlockedItemUsage(value);
            case ConfigPackets.REMOVE_ITEM   -> cfg.removeBlockedItemUsage(value);
            case ConfigPackets.ADD_BLOCK     -> cfg.addBlockedBlockUsage(value);
            case ConfigPackets.REMOVE_BLOCK  -> cfg.removeBlockedBlockUsage(value);
            case ConfigPackets.ADD_MOD       -> cfg.addBlockedMod(value);
            case ConfigPackets.REMOVE_MOD    -> cfg.removeBlockedMod(value);
        }
    }
}
