package com.createnewrecipes.mod;

import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_7923;

public final class ModCreativeTab {

    public static final class_1761 TAB = FabricItemGroup.builder()
            .method_47320(() -> new class_1799(ModItems.FORGE_HAMMER_MK1))
            .method_47321(class_2561.method_43471("itemGroup.createnewrecipes.main"))
            .method_47317((params, output) -> {

                // ── Forge Hammers ────────────────────────────────────────
                output.method_45421(ModItems.FORGE_HAMMER_MK1);
                output.method_45421(ModItems.FORGE_HAMMER_MK2);
                output.method_45421(ModItems.FORGE_HAMMER_MK3);

                // ── Brass process ────────────────────────────────────────
                output.method_45421(ModItems.IMPURE_LEAD_RESIDUE);
                output.method_45421(ModItems.RAW_LEAD);
                output.method_45421(ModItems.MALLEABLE_COPPER);
                output.method_45421(ModItems.ADHERABLE_ZINC);
                output.method_45421(ModItems.MALLEABLE_BRASS);
                output.method_45421(ModItems.MALLEABLE_BRASS_1);
                output.method_45421(ModItems.MALLEABLE_BRASS_2);

                // ── Mechanical Press process ─────────────────────────────
                output.method_45421(ModItems.STEEL_COATED_ROD);
                output.method_45421(ModItems.COATED_CASING);
                output.method_45421(ModItems.HOT_LEADED_STEEL);
                output.method_45421(ModItems.INCOMPLETE_PRESS_CASING_MK1);
                output.method_45421(ModItems.INCOMPLETE_PRESS_CASING_MK2);
                output.method_45421(ModItems.INCOMPLETE_PRESS_CASING_MK3);
                output.method_45421(ModItems.PISTON_EXTENSION_HALF);
                output.method_45421(ModItems.MECHANICAL_PRESS_HEAD_HEATED);
                output.method_45421(ModItems.MECHANICAL_PRESS_HEAD_TEMPERED);
                output.method_45421(ModItems.MECHANICAL_PRESS_PISTON);

                // ── Drill / Taladro process ──────────────────────────────
                output.method_45421(ModItems.STEEL_COATED_INGOT);
                output.method_45421(ModItems.INCOMPLETE_COATED_INGOT);
                output.method_45421(ModItems.HOT_RAW_STEEL);
                output.method_45421(ModItems.FRAGILE_DRILL_HEAD);
                output.method_45421(ModItems.HEATED_DRILL_HEAD);
                output.method_45421(ModItems.TEMPERED_DRILL_HEAD);
                output.method_45421(ModItems.INCOMPLETE_DRILL_HEAD);

                // ── Mechanical Mixer process ─────────────────────────────
                output.method_45421(ModItems.MECHANICAL_WHISK_1);
                output.method_45421(ModItems.MECHANICAL_WHISK_2);
                output.method_45421(ModItems.MECHANICAL_WHISK_3);
                output.method_45421(ModItems.MECHANICAL_WHISK);
                output.method_45421(ModItems.HOT_MECHANICAL_WHISK);
                output.method_45421(ModItems.COGWHEEL_CASING);

                // ── Mechanical Saw process ───────────────────────────────
                output.method_45421(ModItems.MECHANICAL_BLADE);
                output.method_45421(ModItems.MECHANICAL_BLADE_1);
                output.method_45421(ModItems.MECHANICAL_BLADE_2);
                output.method_45421(ModItems.MECHANICAL_BLADE_3);
                output.method_45421(ModItems.PRESSED_MECHANICAL_BLADE);
                output.method_45421(ModItems.HOT_MECHANICAL_BLADE);
                output.method_45421(ModItems.HOT_PRESSED_MECHANICAL_BLADE);
                output.method_45421(ModItems.TEMPERED_MECHANICAL_BLADE);

                // ── Sheet / Laminas — Iron ───────────────────────────────
                output.method_45421(ModItems.IMPURE_IRON_RESIDUE);
                output.method_45421(ModItems.CRUDE_IRON);
                output.method_45421(ModItems.MOLTEN_IRON);
                output.method_45421(ModItems.FRAGILE_IRON_SHEET);
                output.method_45421(ModItems.INCOMPLETE_FRAGILE_IRON_SHEET);
                output.method_45421(ModItems.HEATED_IRON_SHEET);

                // ── Sheet / Laminas — Gold ───────────────────────────────
                output.method_45421(ModItems.IMPURE_GOLD_RESIDUE);
                output.method_45421(ModItems.CRUDE_GOLD);
                output.method_45421(ModItems.MOLTEN_GOLD);
                output.method_45421(ModItems.FRAGILE_GOLD_SHEET);
                output.method_45421(ModItems.INCOMPLETE_FRAGILE_GOLD_SHEET);
                output.method_45421(ModItems.HEATED_GOLD_SHEET);

                // ── Sheet / Laminas — Copper ─────────────────────────────
                output.method_45421(ModItems.IMPURE_COPPER_RESIDUE);
                output.method_45421(ModItems.CRUDE_COPPER);
                output.method_45421(ModItems.MOLTEN_COPPER);
                output.method_45421(ModItems.FRAGILE_COPPER_SHEET);
                output.method_45421(ModItems.INCOMPLETE_FRAGILE_COPPER_SHEET);
                output.method_45421(ModItems.HEATED_COPPER_SHEET);
            })
            .method_47324();

    private ModCreativeTab() {}

    public static void register() {
        class_2378.method_10230(class_7923.field_44687,
                CreateNewRecipesMod.id("main"), TAB);
    }
}
