package com.createnewrecipes.mod.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Map;
import net.minecraft.class_1860;
import net.minecraft.class_1863;
import net.minecraft.class_2960;
import net.minecraft.class_3956;

/**
 * Exposes RecipeManager's private recipe maps so RecipeBlockerMixin can
 * replace them with filtered copies.
 *
 * Field names ("recipes" and "byName") are the official Mojang-mapped names
 * present in Minecraft 1.20.1.
 */
@Mixin(class_1863.class)
public interface RecipeManagerAccessor {

    /** All recipes keyed by RecipeType, then by ResourceLocation. */
    @Accessor("recipes")
    Map<class_3956<?>, Map<class_2960, class_1860<?>>> getRecipesByType();

    @Accessor("recipes")
    void setRecipesByType(Map<class_3956<?>, Map<class_2960, class_1860<?>>> recipes);

    /** All recipes keyed by their unique ResourceLocation ID. */
    @Accessor("byName")
    Map<class_2960, class_1860<?>> getByName();

    @Accessor("byName")
    void setByName(Map<class_2960, class_1860<?>> byName);
}
