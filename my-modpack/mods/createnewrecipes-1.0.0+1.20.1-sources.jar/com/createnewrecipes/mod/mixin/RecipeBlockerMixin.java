package com.createnewrecipes.mod.mixin;

import com.createnewrecipes.mod.CreateNewRecipesMod;
import com.createnewrecipes.mod.ModConfig;
import com.createnewrecipes.mod.RecipeRegistry;
import com.google.gson.JsonElement;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1860;
import net.minecraft.class_1863;
import net.minecraft.class_2960;
import net.minecraft.class_3300;
import net.minecraft.class_3695;
import net.minecraft.class_3956;

@Mixin(class_1863.class)
public class RecipeBlockerMixin {

    @Inject(
        method = "apply(Ljava/util/Map;Lnet/minecraft/server/packs/resources/ResourceManager;Lnet/minecraft/util/profiling/ProfilerFiller;)V",
        at = @At("RETURN")
    )
    private void onRecipesLoaded(
            Map<class_2960, JsonElement> map,
            class_3300 resourceManager,
            class_3695 profiler,
            CallbackInfo ci
    ) {
        try {
            ModConfig.getInstance();
        } catch (IllegalStateException e) {
            return;
        }

        class_1863 rm = (class_1863) (Object) this;
        RecipeManagerAccessor self = (RecipeManagerAccessor) this;

        // Build mutable copies (the maps inside RecipeManager may be ImmutableMaps)
        Map<class_2960, class_1860<?>> byName = new HashMap<>(self.getByName());
        Map<class_3956<?>, Map<class_2960, class_1860<?>>> byType = new HashMap<>();
        self.getRecipesByType().forEach((type, recipeMap) ->
                byType.put(type, new HashMap<>(recipeMap)));

        int beforeCount = byName.size();

        // Step 1: snapshot originals before any filtering
        RecipeRegistry.cacheOriginals(byName, byType);

        // Step 2: apply blocking rules to the working copies
        RecipeRegistry.applyBlocking(byName, byType);

        int afterCount = byName.size();
        CreateNewRecipesMod.LOGGER.info(
                "[CreateNewRecipes] Mixin blocking: {} recipes before, {} after ({} removed)",
                beforeCount, afterCount, beforeCount - afterCount);

        // Step 3: write filtered maps back using vanilla replaceRecipes()
        rm.method_20702(byName.values());

        // Verify the write succeeded
        int verifyCount = self.getByName().size();
        CreateNewRecipesMod.LOGGER.info(
                "[CreateNewRecipes] Mixin verify: RecipeManager now has {} recipes", verifyCount);

        // Step 4: re-inject custom DB recipes
        CreateNewRecipesMod.reinjectFromMixin(rm);
    }
}
