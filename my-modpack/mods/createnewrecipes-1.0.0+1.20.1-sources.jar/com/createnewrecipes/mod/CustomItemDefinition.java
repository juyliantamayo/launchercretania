package com.createnewrecipes.mod;

/**
 * Represents one user-defined custom item stored in custom_items.json.
 *
 * @param id          Short ID (no namespace).  Full ID = "cretania:{id}"
 * @param displayName Item name shown in-game
 * @param maxStack    Stack size 1–64
 * @param durability  Max durability (0 = indestructible / no damage bar)
 * @param parentModel "generated" (flat sprite) or "handheld" (held in hand)
 * @param textureB64  Base64-encoded 16×16 PNG (may be empty = use fallback placeholder)
 */
public record CustomItemDefinition(
        String id,
        String displayName,
        int    maxStack,
        int    durability,
        String parentModel,
        String textureB64
) {
    public static final String PARENT_GENERATED = "generated";
    public static final String PARENT_HANDHELD  = "handheld";

    /** Full resource-location string: "cretania:{id}" */
    public String fullId() { return "cretania:" + id; }

    /** Normalised parent model path understood by Minecraft. */
    public String resolvedParent() {
        return PARENT_HANDHELD.equals(parentModel) ? "item/handheld" : "item/generated";
    }
}
