package com.createnewrecipes.mod.client;

import com.createnewrecipes.mod.network.ConfigPackets;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.class_2540;
import net.minecraft.class_310;
import java.util.ArrayList;
import java.util.List;

import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.literal;

/**
 * Client-side initializer for the in-game GUI.
 *
 * Opens via:  /cnr gui  (typed in chat while in-game, OP 2 required on server side)
 */
@Environment(EnvType.CLIENT)
public class CreateNewRecipesClient implements ClientModInitializer {

    // ── Cached config data received from the server ──────────────────────────
    public static volatile List<String> recipes = new ArrayList<>();
    public static volatile List<String> items   = new ArrayList<>();
    public static volatile List<String> blocks  = new ArrayList<>();
    public static volatile List<String> mods    = new ArrayList<>();

    /** A saved custom recipe as received from the server. */
    public record CustomRecipeInfo(
            String type,
            String recipeId,
            boolean consumeInput,
            String createdAt,
            List<String> fields
    ) {}

    /** All user-created custom recipes (newest first). */
    public static volatile List<CustomRecipeInfo> customRecipes = new ArrayList<>();

    /** Set to true when the player explicitly opens the GUI via command; reset after screen opens. */
    private static volatile boolean guiRequested = false;

    @Override
    public void onInitializeClient() {

        // S2C: receive config snapshot → refresh or open screen
        ClientPlayNetworking.registerGlobalReceiver(ConfigPackets.S2C_DATA,
                (client, handler, buf, sender) -> {
                    List<String> r = readList(buf);
                    List<String> i = readList(buf);
                    List<String> b = readList(buf);
                    List<String> m = readList(buf);

                    client.execute(() -> {
                        recipes = r;
                        items   = i;
                        blocks  = b;
                        mods    = m;

                        if (client.field_1755 instanceof RecipeBlockerScreen existing) {
                            // Already open — just refresh the data
                            existing.refreshData();
                        } else if (guiRequested) {
                            // Only open the screen when the player explicitly requested it
                            guiRequested = false;
                            client.method_1507(new RecipeBlockerScreen());
                        }
                    });
                });

        // S2C: receive custom recipes list
        ClientPlayNetworking.registerGlobalReceiver(ConfigPackets.S2C_CUSTOM_RECIPES,
                (client, handler, buf, sender) -> {
                    int count = buf.method_10816();
                    List<CustomRecipeInfo> list = new ArrayList<>(count);
                    for (int i = 0; i < count; i++) {
                        String type      = buf.method_19772();
                        String recipeId  = buf.method_19772();
                        boolean consume  = buf.readBoolean();
                        String createdAt = buf.method_19772();
                        int fc           = buf.method_10816();
                        List<String> fields = new ArrayList<>(fc);
                        for (int j = 0; j < fc; j++) fields.add(buf.method_19772());
                        list.add(new CustomRecipeInfo(type, recipeId, consume, createdAt, fields));
                    }
                    client.execute(() -> {
                        customRecipes = list;
                        if (client.field_1755 instanceof RecipeBlockerScreen scr)
                            scr.refreshCustomRecipes();
                    });
                });

        // Client command:  /cnr  → request config from server (OP 4 required server-side)
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, ctx) ->
                dispatcher.register(literal("cnr").executes(c -> {
                    guiRequested = true;
                    class_310.method_1551().execute(() ->
                            ClientPlayNetworking.send(
                                    ConfigPackets.C2S_REQUEST,
                                    PacketByteBufs.empty()));
                    return 1;
                })));
    }

    // ── Outgoing packets ─────────────────────────────────────────────────────

    /** Send an add/remove operation to the server. */
    public static void sendModify(byte op, String value) {
        class_2540 buf = PacketByteBufs.create();
        buf.writeByte(op);
        buf.method_10814(value);
        ClientPlayNetworking.send(ConfigPackets.C2S_MODIFY, buf);
    }

    /** Send a new recipe (type, id, consumeInput, field values) to the server for saving. */
    public static void sendNewRecipe(String type, String id, boolean consumeInput,
                                     List<String> fields) {
        class_2540 buf = PacketByteBufs.create();
        buf.method_10814(type);
        buf.method_10814(id);
        buf.writeBoolean(consumeInput);
        buf.method_10804(fields.size());
        fields.forEach(buf::method_10814);
        ClientPlayNetworking.send(ConfigPackets.C2S_NEW_RECIPE, buf);
    }

    /** Request deletion of a custom recipe by ID. */
    public static void sendDeleteCustom(String recipeId) {
        class_2540 buf = PacketByteBufs.create();
        buf.method_10814(recipeId);
        ClientPlayNetworking.send(ConfigPackets.C2S_DELETE_CUSTOM, buf);
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private static List<String> readList(class_2540 buf) {
        int n = buf.method_10816();
        List<String> list = new ArrayList<>(n);
        for (int i = 0; i < n; i++) list.add(buf.method_19772());
        return list;
    }
}
