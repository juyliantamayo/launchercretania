package com.createnewrecipes.mod.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_437;
import net.minecraft.class_7923;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;

/**
 * A popup screen that lists all registered items so the user can pick one.
 * When an item is selected, the caller's callback receives "namespace:item_id".
 *
 * Opens on top of RecipeBuilderScreen (parent screen is stored and restored on close).
 */
@Environment(EnvType.CLIENT)
public class ItemPickerScreen extends class_437 {

    // ── palette (mirrors RecipeBlockerScreen) ─────────────────────────────────
    private static final int C_BG         = 0xFF161618;
    private static final int C_PANEL      = 0xFF1E1E26;
    private static final int C_HEADER     = 0xFF0F0F14;
    private static final int C_ACCENT     = 0xFFE8662A;
    private static final int C_BORDER     = 0xFF3A3A4A;
    private static final int C_TEXT       = 0xFFE0E0E0;
    private static final int C_TEXT_DIM   = 0xFF888898;
    private static final int C_ENTRY_SEL  = 0xFF2D3D5A;
    private static final int C_ENTRY_HOV  = 0xFF252535;
    private static final int C_ACCENT2    = 0xFF5B8FBF;

    /** All registered items (built once per JVM) */
    private static List<class_1792> ALL_ITEMS;

    private final class_437 parent;
    private final Consumer<String> callback;

    private class_342 searchBox;
    private List<class_1792> filtered = new ArrayList<>();

    // scroll state
    private int scrollOffset = 0;

    // layout
    private int px, py, pw, ph; // popup bounds
    private static final int CELL = 20; // item grid cell size
    private int cols, rows;
    private int gridX, gridY, gridW, gridH;

    // hovered cell
    private int hoveredIdx = -1;

    // ─────────────────────────────────────────────────────────────────────────
    public ItemPickerScreen(class_437 parent, Consumer<String> callback) {
        super(class_2561.method_43470("Pick an Item"));
        this.parent   = parent;
        this.callback = callback;
        buildAllItems();
    }

    private static void buildAllItems() {
        if (ALL_ITEMS != null) return;
        ALL_ITEMS = new ArrayList<>();
        for (class_1792 item : class_7923.field_41178) {
            if (item != class_1802.field_8162) ALL_ITEMS.add(item);
        }
        ALL_ITEMS.sort(Comparator.comparing(i ->
                class_7923.field_41178.method_10221(i).toString()));
    }

    // ── init ─────────────────────────────────────────────────────────────────
    @Override
    protected void method_25426() {
        // Popup dimensions — leave some screen margin
        pw = Math.min(field_22789  - 40, 320);
        ph = Math.min(field_22790 - 40, 260);
        px = (field_22789  - pw) / 2;
        py = (field_22790 - ph) / 2;

        int headerH = 22;
        int searchH = 14;
        int searchPad = 6;

        gridX = px + 4;
        gridY = py + headerH + searchH + searchPad * 2 + 2;
        gridW = pw - 8;
        gridH = ph - (gridY - py) - 4;
        cols  = Math.max(1, gridW / CELL);
        rows  = Math.max(1, gridH / CELL);

        searchBox = new class_342(field_22793,
                px + searchPad, py + headerH + searchPad,
                pw - searchPad * 2, searchH,
                class_2561.method_43473());
        searchBox.method_1880(80);
        searchBox.method_47404(class_2561.method_43470("Search items…"));
        searchBox.method_1858(false);
        searchBox.method_1863(s -> { scrollOffset = 0; rebuildFiltered(); });
        method_37063(searchBox);

        rebuildFiltered();
    }

    private void rebuildFiltered() {
        String q = searchBox != null ? searchBox.method_1882().toLowerCase() : "";
        filtered.clear();
        for (class_1792 item : ALL_ITEMS) {
            String id = class_7923.field_41178.method_10221(item).toString();
            String name = item.method_7848().getString().toLowerCase();
            if (q.isEmpty() || id.contains(q) || name.contains(q)) {
                filtered.add(item);
            }
        }
    }

    // ── render ────────────────────────────────────────────────────────────────
    @Override
    public void method_25394(class_332 g, int mx, int my, float dt) {

        // darken the background screen
        g.method_25294(0, 0, field_22789, field_22790, 0xAA000000);

        // popup outer shadow
        g.method_25294(px - 2, py - 2, px + pw + 2, py + ph + 2, 0xFF0A0A10);

        // main panel
        g.method_25294(px, py, px + pw, py + ph, C_PANEL);

        // header
        g.method_25294(px, py, px + pw, py + 22, C_HEADER);
        g.method_25294(px, py + 21, px + pw, py + 22, C_ACCENT);
        g.method_25300(field_22793, "§6Pick an Item", px + pw / 2, py + 7, C_TEXT);

        // close ×
        boolean closeHov = mx >= px + pw - 16 && mx <= px + pw - 2
                        && my >= py + 4          && my <= py + 18;
        g.method_51433(field_22793, "×", px + pw - 12, py + 7, closeHov ? 0xFFFF6666 : C_TEXT_DIM, false);

        // search underline
        if (searchBox != null) {
            int sy = searchBox.method_46427() + searchBox.method_25364();
            g.method_25294(searchBox.method_46426(), sy, searchBox.method_46426() + searchBox.method_25368(), sy + 1, C_BORDER);
        }

        // item count
        String cnt = filtered.size() + " items";
        g.method_51433(field_22793, cnt, px + pw - field_22793.method_1727(cnt) - 6, py + 30, C_TEXT_DIM, false);

        // ── item grid ────────────────────────────────────────────────────────
        int startIdx = scrollOffset * cols;
        hoveredIdx = -1;

        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                int idx = startIdx + r * cols + c;
                if (idx >= filtered.size()) break;

                int cx = gridX + c * CELL;
                int cy = gridY + r * CELL;

                boolean hov = mx >= cx && mx < cx + CELL && my >= cy && my < cy + CELL;
                if (hov) hoveredIdx = idx;

                if (hov) {
                    // hover highlight
                    g.method_25294(cx, cy, cx + CELL, cy + CELL, C_ENTRY_HOV);
                    g.method_25294(cx, cy, cx + CELL, cy + 1, C_ACCENT2);
                    g.method_25294(cx, cy + CELL - 1, cx + CELL, cy + CELL, C_ACCENT2);
                    g.method_25294(cx, cy, cx + 1, cy + CELL, C_ACCENT2);
                    g.method_25294(cx + CELL - 1, cy, cx + CELL, cy + CELL, C_ACCENT2);
                }

                class_1792 item = filtered.get(idx);
                var stack = new net.minecraft.class_1799(item);
                g.method_51427(stack, cx + 2, cy + 2);
            }
        }

        // scrollbar
        int totalRows = (int) Math.ceil((double) filtered.size() / cols);
        if (totalRows > rows) {
            int sbH   = gridH;
            int thumbH = Math.max(12, sbH * rows / totalRows);
            int thumbY = gridY + (sbH - thumbH) * scrollOffset / Math.max(1, totalRows - rows);
            int sbX    = gridX + gridW + 2;
            g.method_25294(sbX, gridY, sbX + 3, gridY + gridH, C_BORDER);
            g.method_25294(sbX, thumbY, sbX + 3, thumbY + thumbH, C_TEXT_DIM);
        }

        // ── tooltip for hovered item ─────────────────────────────────────────
        if (hoveredIdx >= 0 && hoveredIdx < filtered.size()) {
            class_1792 item = filtered.get(hoveredIdx);
            String id   = class_7923.field_41178.method_10221(item).toString();
            String name = item.method_7848().getString();

            int ttW = Math.max(field_22793.method_1727(id), field_22793.method_1727(name)) + 8;
            int ttH = 22;
            int ttX = Math.min(mx + 10, field_22789  - ttW - 2);
            int ttY = Math.min(my + 10, field_22790 - ttH - 2);

            g.method_25294(ttX - 1, ttY - 1, ttX + ttW + 1, ttY + ttH + 1, 0xFF0A0A10);
            g.method_25294(ttX, ttY, ttX + ttW, ttY + ttH, 0xFF22222E);
            g.method_25294(ttX, ttY, ttX + 2, ttY + ttH, C_ACCENT);
            g.method_51433(field_22793, name, ttX + 5, ttY + 3, C_TEXT,     false);
            g.method_51433(field_22793, id,   ttX + 5, ttY + 13, C_TEXT_DIM, false);
        }

        // widgets (search box)
        super.method_25394(g, mx, my, dt);
    }

    // ── input ─────────────────────────────────────────────────────────────────
    @Override
    public boolean method_25402(double mx, double my, int button) {
        // Close ×
        if (mx >= px + pw - 16 && mx <= px + pw - 2 && my >= py + 4 && my <= py + 18) {
            method_25419(); return true;
        }

        // Click outside popup → close
        if (mx < px || mx > px + pw || my < py || my > py + ph) {
            method_25419(); return true;
        }

        // Grid click
        if (hoveredIdx >= 0 && hoveredIdx < filtered.size()) {
            class_1792 item = filtered.get(hoveredIdx);
            String id = class_7923.field_41178.method_10221(item).toString();
            callback.accept(id);
            method_25419();
            return true;
        }

        return super.method_25402(mx, my, button);
    }

    @Override
    public boolean method_25401(double mx, double my, double delta) {
        if (mx >= gridX && mx <= gridX + gridW && my >= gridY && my <= gridY + gridH) {
            int totalRows = (int) Math.ceil((double) filtered.size() / cols);
            scrollOffset = Math.max(0, Math.min(totalRows - rows, scrollOffset - (int) delta));
            return true;
        }
        return super.method_25401(mx, my, delta);
    }

    @Override
    public void method_25419() {
        assert field_22787 != null;
        field_22787.method_1507(parent);
    }

    @Override public boolean method_25421() { return false; }
}
