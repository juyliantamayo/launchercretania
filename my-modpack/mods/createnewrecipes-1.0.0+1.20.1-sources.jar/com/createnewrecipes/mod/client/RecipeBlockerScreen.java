package com.createnewrecipes.mod.client;

import com.createnewrecipes.mod.network.ConfigPackets;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_4280;
import net.minecraft.class_437;
import net.minecraft.class_6382;
import net.minecraft.class_7923;
import java.util.*;

/**
 * Main in-game GUI.  Two modes:
 *
 *  MANAGE (Recipes / Items / Blocks / Mods)
 *  ─────────────────────────────────────────
 *  Sidebar nav → content panel with search bar + scrollable list + add/remove bar.
 *
 *  NEW RECIPE
 *  ──────────
 *  Left column  – scrollable recipe-type list, each row shows a small VISUAL
 *                 diagram (input → machine → output drawn with ASCII/symbols).
 *  Right column – step-by-step form with ITEM PICKER buttons for every item
 *                 field and plain-English labels.  Clicking "[Pick]" opens
 *                 ItemPickerScreen (a searchable grid of all registered items).
 *
 *  Open with:  /cnr gui   (requires OP level 2)
 */
@Environment(EnvType.CLIENT)
public class RecipeBlockerScreen extends class_437 {

    // ── palette ───────────────────────────────────────────────────────────────
    private static final int C_BG        = 0xFF16161E;
    private static final int C_PANEL     = 0xFF1C1C28;
    private static final int C_SIDEBAR   = 0xFF131320;
    private static final int C_HEADER    = 0xFF0C0C18;
    private static final int C_ACCENT    = 0xFF50C8E0;   // cyan
    private static final int C_ACCENT_OR = 0xFFE8662A;   // orange (diagram top bar)
    private static final int C_ACCENT2   = 0xFF5B8FBF;
    private static final int C_GREEN     = 0xFF48C878;
    private static final int C_BTN_ADD   = 0xFF264A26;
    private static final int C_BTN_ADDH  = 0xFF336633;
    private static final int C_BTN_REM   = 0xFF4A2626;
    private static final int C_BTN_REMH  = 0xFF663333;
    private static final int C_BTN_SAV   = 0xFF243680;
    private static final int C_BTN_SAVH  = 0xFF3050A0;
    private static final int C_BTN_PICK  = 0xFF252838;
    private static final int C_BTN_PICKH = 0xFF333A50;
    private static final int C_BTN_NORM  = 0xFF282838;
    private static final int C_BTN_NORMH = 0xFF363650;
    private static final int C_NAV_SEL   = 0xFF252535;
    private static final int C_ENTRY_SEL = 0xFF263050;
    private static final int C_ENTRY_HOV = 0xFF202030;
    private static final int C_TEXT      = 0xFFDDDDEE;
    private static final int C_TEXT_DIM  = 0xFF7878A0;
    private static final int C_TEXT_ACC  = 0xFF50C8E0;
    private static final int C_BORDER    = 0xFF333345;
    private static final int C_DIAGRAM   = 0xFF232335;

    // ── nav ───────────────────────────────────────────────────────────────────
    private enum Nav { RECIPES, ITEMS, BLOCKS, MODS, MY_RECIPES, NEW_RECIPE, PROCESS_CHAIN, MOD_RECIPES, CUSTOM_ITEMS }
    private Nav activeNav = Nav.RECIPES;

    // ── manage panel ──────────────────────────────────────────────────────────
    private EntryList entryList;      // kept for reference, not used in grid mode
    private class_342   searchBox;
    private class_342   addBox;
    private int   manageScroll    = 0;
    private int   manageSelected  = -1;

    // ── manage-panel item picker (for ITEMS / BLOCKS nav) ────────────────────
    private boolean managePickerOpen = false;
    private int     managePickerScroll = 0;
    private class_1792    managePickerHoverItem = null;
    private class_342 managePickerSearch;
    private final List<class_1792> managePickerFiltered = new ArrayList<>();

    // ── manage-panel mod picker (for MODS nav) ────────────────────────────────
    private int     modPickerScroll = 0;
    private class_342 modPickerSearch;
    private final List<String[]> modPickerFiltered = new ArrayList<>(); // {id, name}

    // ── manage-panel recipe picker (for RECIPES nav) ──────────────────────────
    private boolean recipePickerOpen   = false;
    private int     recipePickerScroll = 0;
    private class_342 recipePickerSearch;
    /** Each entry: [itemId, itemId] — one row per unique output item */
    private final List<String[]> recipePickerFiltered = new ArrayList<>();
    /** Maps output itemId → list of recipe IDs that produce it (populated by applyRecipePickerFilter) */
    private final Map<String, List<String>> recipeIdsByItem = new LinkedHashMap<>();

    // ── my-recipes panel state ────────────────────────────────────────────────
    private int     selectedCustomIdx = -1;
    private int     customListScroll  = 0;
    private class_342 customSearchBox;

    // ── process-chain state ──────────────────────────────────────────────────
    /** Each node: {typeIdx, itemId, label} */
    private final List<int[]>    chainNodes     = new ArrayList<>(); // [typeIdx, fieldItem0_picked?]
    private final List<String>   chainItemIds   = new ArrayList<>(); // output item ID per node
    private final List<class_1799> chainItemStacks = new ArrayList<>();
    /** Per-node field values and item stacks (persists across init()) */
    private final List<Map<Integer, String>>    chainFieldVals   = new ArrayList<>();
    private final List<Map<Integer, class_1799>> chainFieldStacks = new ArrayList<>();
    private int    chainSelected = -1;  // selected node index
    private class_342 chainIdBox;  // prefix for generated recipe IDs
    private int     chainPickerFor = -1; // node index being picked (-1 = none)
    private int     chainPickerScroll = 0;
    private final List<class_1792> chainPickerFiltered = new ArrayList<>();
    private class_342 chainPickerSearch;
    private class_1792    chainPickerHoverItem;

    // ── mod-recipes state ────────────────────────────────────────────────────
    private int     modRecipesScroll   = 0;
    private int     modRecipesSelected = -1;
    private String  modRecipesFilter   = "";
    private class_342 modRecipesSearchBox;

    // ── new-recipe: consume toggle ────────────────────────────────────────────
    private boolean consumeInput = true;

    // ── per-slot quantity and consumable ──────────────────────────────────────
    /** Per field index: how many of this item are required (default 1). */
    private final Map<Integer, Integer> fieldCounts   = new HashMap<>();
    /** Per field index: false = item is NOT consumed (kept in slot). Default = consumeInput. */
    private final Map<Integer, Boolean> fieldConsumed = new HashMap<>();

    // ── recipe-type data ──────────────────────────────────────────────────────
    // roleName, typeId, shortDesc, ASCII machine diagram, fields[]
    // Each field: "ROLE|label|isItem|hint"
    //   ROLE:   OUT / IN / IN2 / IN3 / EXTRA / TIME / HEAT / STEP / PATTERN
    //   isItem: true → show [Pick] button
    private record RecipeType(
            String label,
            String typeId,
            String shortDesc,
            String diagram,        // small multi-line art
            String[][] fields      // { role, label, isItem?, hint }
    ) {}

    private static final List<RecipeType> TYPES = List.of(

        new RecipeType("Deploying", "create:deploying",
            "Mechanical Deployer applies an item to another item.",
            """
            [  Input  ] ──▶ [Deployer] ──▶ [ Output ]
                                ▲
                           [Held item]
            """,
            new String[][]{
                {"OUT","Output item","true","The item produced"},
                {"IN", "Base item (goes on the belt)","true","The item being processed"},
                {"IN2","Deployer held item","true","The item the Deployer holds/applies"},
            }),

        new RecipeType("Mixing", "create:mixing",
            "Mechanical Mixer combines ingredients in a Blaze Burner basin.",
            """
            [Item 1] ─┐
            [Item 2] ─┼▶ [ Mixer ] ──▶ [ Output ]
            [Item 3] ─┘   (basin)
            """,
            new String[][]{
                {"OUT",  "Output item","true","The result of mixing"},
                {"IN",   "Ingredient 1","true","First ingredient"},
                {"IN2",  "Ingredient 2","true","Second ingredient"},
                {"IN3",  "Ingredient 3 (optional)","true","Third ingredient – leave blank if unused"},
                {"HEAT", "Heat level (optional)","false","none  /  heated  /  superheated"},
            }),

        new RecipeType("Crushing", "create:crushing",
            "Crushing Wheels grind a single item into multiple outputs.",
            """
            [ Input ] ──▶ [Crushing] ──▶ [Output 1]
                          [ Wheels ]  └─▶ [Output 2]
            """,
            new String[][]{
                {"IN",   "Input item","true","The item to crush"},
                {"OUT",  "Output 1","true","Primary output item"},
                {"OUT2", "Output 2 (optional, add chance %)","true","e.g. minecraft:flint  50%"},
                {"TIME", "Processing time in ticks (optional)","false","Default: 200"},
            }),

        new RecipeType("Splashing", "create:splashing",
            "Fan blows items through water, washing them.",
            """
            [ Input ] ──▶ [Fan+Water] ──▶ [ Output ]
            """,
            new String[][]{
                {"IN",  "Input item","true","The item to wash"},
                {"OUT", "Output item","true","The washed result"},
            }),

        new RecipeType("Pressing", "create:pressing",
            "Mechanical Press stamps a single item on a Depot or Belt.",
            """
                    ↓ [Press]
            [Input] ──▶ [Depot] ──▶ [Output]
            """,
            new String[][]{
                {"IN",  "Input item","true","The item to press"},
                {"OUT", "Output item","true","The pressed result (e.g. a sheet)"},
            }),

        new RecipeType("Rolling", "createaddition:rolling",
            "Roller processes an item passing underneath on a Belt.",
            """
            [Input] ──▶ [Roller] ──▶ [Output]
            """,
            new String[][]{
                {"IN",  "Input item","true","The item to roll"},
                {"OUT", "Output item","true","The rolled result"},
            }),

        new RecipeType("Cutting", "create:cutting",
            "Mechanical Saw cuts an item moving on a Belt.",
            """
            [Input] ──▶ [Mech.Saw] ──▶ [Output]
            """,
            new String[][]{
                {"IN",   "Input item","true","The item to cut"},
                {"OUT",  "Output item","true","The cut result"},
                {"TIME", "Processing time in ticks (optional)","false","Default: 50"},
            }),

        new RecipeType("Haunting", "create:haunting",
            "Fan blows items through Soul Fire smoke, haunting them.",
            """
            [Input] ──▶ [Fan+Soul Fire] ──▶ [Output]
            """,
            new String[][]{
                {"IN",  "Input item","true","The item to haunt"},
                {"OUT", "Output item","true","The haunted result"},
            }),

        new RecipeType("Compacting", "create:compacting",
            "Mechanical Press + Mixer basin compacts items, with optional heat.",
            """
            [Item 1] ─┐         ↓ [Press]
            [Item 2] ─┼▶ [Mixing Basin] ──▶ [Output]
            [Item 3] ─┘
            """,
            new String[][]{
                {"OUT",  "Output item","true","The compacted result"},
                {"IN",   "Ingredient 1","true","First ingredient"},
                {"IN2",  "Ingredient 2","true","Second ingredient"},
                {"IN3",  "Ingredient 3 (optional)","true","Third ingredient – leave blank if unused"},
                {"HEAT", "Heat level (optional)","false","none  /  heated  /  superheated"},
            }),

        new RecipeType("Caldera+Prensa", "create:compacting",
            "Prensa Mecánica sobre Cuenca con Quemador de Blaze (superheated).",
            """
            [Carbón]→[Blaze]   ↓ [Prensa Mecánica]
            [Item 1] ─┐
            [Item 2] ─┼▶ [ Cuenca ]──▶ [Lingotes/Output]
            [Item 3] ─┘  (superheated)
            """,
            new String[][]{
                {"OUT",  "Output (lingotes/resultado)","true","Resultado: e.g. create:brass_ingot"},
                {"IN",   "Armadura / Material 1","true","e.g. minecraft:iron_helmet"},
                {"IN2",  "Material 2 (opcional)","true","Segundo ingrediente – dejar vacío si no aplica"},
                {"IN3",  "Material 3 (opcional)","true","Tercer ingrediente – dejar vacío si no aplica"},
                {"HEAT", "Nivel de calor","false","superheated"},
            }),

        new RecipeType("Sandpaper Polish", "create:sandpaper_polishing",
            "Right-clicking with Sandpaper polishes the item in your other hand.",
            """
            [Input] + [Sandpaper] ──▶ [Polished Output]
              (held in off-hand)  (right-click)
            """,
            new String[][]{
                {"IN",  "Input item","true","The item to polish"},
                {"OUT", "Output item","true","The polished result"},
            }),

        new RecipeType("Mech. Crafting", "create:mechanical_crafting",
            "Shaped crafting using a grid of Mechanical Crafters (up to 9×9).",
            """
            Pattern grid:
            [ A ][ B ][ C ]
            [ A ][   ][ C ]  ──▶ [ Output ]
            [   ][ B ][   ]
            """,
            new String[][]{
                {"OUT",     "Output item","true","The item produced"},
                {"PATTERN", "Pattern row 1 (e.g.  ABC  or  AA )","false","Use letters A–I; each letter maps to an item key below"},
                {"PATTERN", "Pattern row 2 (optional)","false","Same width as row 1, or leave blank"},
                {"PATTERN", "Pattern row 3 (optional)","false","Same width, or leave blank"},
                {"KEY",     "Key A → item","true","The item that letter A represents"},
                {"KEY",     "Key B → item (optional)","true","The item that letter B represents"},
                {"KEY",     "Key C → item (optional)","true","The item that letter C represents"},
            }),

        new RecipeType("Sequenced Assembly", "create:sequenced_assembly",
            "Multi-step assembly line: a series of processing steps on a transitional item.",
            """
            [Ingredient] ──▶ [Step 1] ──▶ [Step 2] ──▶ ... ──▶ [Final Output]
                              Deploy    Press/Mix
            """,
            new String[][]{
                {"OUT",  "Final output item","true","The finished product"},
                {"IN",   "Transitional item","true","Created between steps; consumed at the end"},
                {"STEP", "Step 1 — type + ingredient","false","e.g.  create:deploying  minecraft:iron_nugget"},
                {"STEP", "Step 2 (optional)","false","e.g.  create:pressing"},
                {"STEP", "Step 3 (optional)","false","e.g.  create:deploying  minecraft:gold_nugget"},
                {"STEP", "Step 4 (optional)","false","leave blank if not needed"},
            }),

        new RecipeType("Emptying", "create:emptying",
            "A Fluid Tank extracts a fluid from a filled container item.",
            """
            [Filled Container] ──▶ [Fluid Tank] ──▶ [Empty Container]
                                                └──▶ [Fluid Output]
            """,
            new String[][]{
                {"IN",   "Filled container input","true","e.g.  minecraft:water_bucket"},
                {"OUT",  "Fluid output","false","e.g.  minecraft:water  1000 mb"},
                {"OUT2", "Empty container output","true","e.g.  minecraft:bucket"},
            }),

        new RecipeType("Filling", "create:filling",
            "A Fluid Tank fills an empty container with a fluid.",
            """
            [Empty Container] ─┐
            [Fluid input]      ├▶ [Fluid Tank] ──▶ [Filled Container]
            """,
            new String[][]{
                {"IN",   "Empty container input","true","e.g.  minecraft:bucket"},
                {"IN2",  "Fluid input","false","e.g.  minecraft:water  1000 mb"},
                {"OUT",  "Filled container output","true","e.g.  minecraft:water_bucket"},
            })
    );

    // ── new-recipe state ──────────────────────────────────────────────────────
    private int selectedType = 0;
    private class_342 recipeIdBox;
    // field values for current type: index → current string value
    private final Map<Integer, String> fieldValues = new LinkedHashMap<>();
    // item stacks for item-type fields (for rendering)
    private final Map<Integer, class_1799> fieldItems = new HashMap<>();
    // item slot buttons in the new-recipe form
    private final Map<Integer, ItemSlotButton> itemSlotButtons = new LinkedHashMap<>();

    // ── diagram-slot click state ─────────────────────────────────────────────
    /** Stores the screen position of each diagram slot for click detection.
     *  Key = field index in current RecipeType, Value = [x,y,w,h] */
    private final Map<Integer, int[]> diagSlotBounds = new HashMap<>();

    // ── inline picker state ───────────────────────────────────────────────────
    private int              activePicker   = -1; // field index being picked, -1 = none
    private boolean          pickerInChainMode = false; // true when activePicker is for a chain node
    private int              pickerScroll   = 0;
    private class_342          pickerSearchBox;
    private class_1792             pickerHoverItem;
    private final List<class_1792> pickerFiltered = new ArrayList<>();
    private static List<class_1792> ALL_ITEMS_CACHE;
    /** Cached mod-icon textures — loaded once per mod and reused. */
    private static final java.util.Map<String, net.minecraft.class_2960> MOD_ICON_CACHE =
            new java.util.HashMap<>();

    // ── pending edit staging (for doEditModRecipe → buildNewRecipePanel) ──────
    private String                 pendingEditId     = null;
    private Map<Integer, String>   pendingEditVals   = null;
    private Map<Integer, class_1799> pendingEditStacks = null;

    private static List<class_1792> getAllItems() {
        if (ALL_ITEMS_CACHE == null) {
            ALL_ITEMS_CACHE = new ArrayList<>();
            class_7923.field_41178.forEach(ALL_ITEMS_CACHE::add);
            ALL_ITEMS_CACHE.sort(Comparator.comparing(i ->
                    class_7923.field_41178.method_10221(i).toString()));
        }
        return ALL_ITEMS_CACHE;
    }

    // ── layout ───────────────────────────────────────────────────────────────
    private static final int SIDEBAR_W = 88;
    private static final int HEADER_H  = 18;
    private static final int NAV_H     = 17;
    private int cX, cY, cW, cH;

    // ── hover ─────────────────────────────────────────────────────────────────
    private boolean closeHov;

    // ── animation state ──────────────────────────────────────────────────────
    /** Screen open: 0→1 over ~8 ticks. Controls scale+fade-in. */
    private float openAnim  = 0f;
    /** Nav transition: 0→1 over ~5 ticks. Controls panel slide. */
    private float navAnim   = 1f;
    private Nav   navAnimFrom = null;
    /** Header shimmer phase, advances each tick. */
    private float shimmer   = 0f;
    /** Per-NavBtn hover brightness (Nav ordinal → 0..1) */
    private final float[] navHov = new float[Nav.values().length];
    /** Close button hover glow */
    private float closeGlow = 0f;

    // =========================================================================
    public RecipeBlockerScreen() {
        super(class_2561.method_43470("Create New Recipes"));
    }

    // ── tick (animation) ──────────────────────────────────────────────────────────
    @Override
    public void method_25393() {
        super.method_25393();
        if (openAnim < 1f) openAnim = Math.min(1f, openAnim + 0.12f);
        if (navAnim  < 1f) navAnim  = Math.min(1f, navAnim  + 0.20f);
        shimmer = (shimmer + 0.04f) % 1f;
    }

    // ── init ──────────────────────────────────────────────────────────────────
    @Override
    protected void method_25426() {
        method_37067();
        entryList       = null;
        searchBox       = null;
        addBox              = null;
        pickerSearchBox     = null;
        activePicker        = -1;
        pickerInChainMode   = false;
        pickerScroll        = 0;
        pickerHoverItem     = null;
        customSearchBox     = null;
        chainIdBox          = null;
        chainPickerSearch   = null;
        chainPickerFor      = -1;
        chainPickerScroll   = 0;
        chainPickerHoverItem = null;
        modRecipesSearchBox = null;
        managePickerSearch  = null;
        managePickerHoverItem = null;
        managePickerScroll  = 0;
        modPickerSearch     = null;
        modPickerScroll     = 0;
        diagSlotBounds.clear();
        fieldValues.clear();
        fieldItems.clear();
        fieldCounts.clear();
        fieldConsumed.clear();
        itemSlotButtons.clear();
        manageScroll   = 0;
        manageSelected = -1;

        cX = SIDEBAR_W;
        cY = HEADER_H;
        cW = field_22789  - SIDEBAR_W;
        cH = field_22790 - HEADER_H;

        buildSidebar();
        switch (activeNav) {
            case RECIPES, ITEMS, BLOCKS, MODS -> buildManagePanel();
            case MY_RECIPES                   -> buildMyRecipesPanel();
            case CUSTOM_ITEMS                 -> buildCustomItemsPanel();
            case NEW_RECIPE                   -> buildNewRecipePanel();
            case PROCESS_CHAIN               -> buildProcessChainPanel();
            case MOD_RECIPES                 -> buildModRecipesPanel();
        }
    }

    // ── sidebar ───────────────────────────────────────────────────────────────
    private void buildSidebar() {
        record E(String label, Nav nav) {}
        var group1 = List.of(
            new E("Recetas",       Nav.RECIPES),
            new E("Ítems",         Nav.ITEMS),
            new E("Bloques",       Nav.BLOCKS),
            new E("Mods",          Nav.MODS)
        );
        var group2 = List.of(
            new E("Nueva Receta",  Nav.NEW_RECIPE),
            new E("Proceso",       Nav.PROCESS_CHAIN),
            new E("Ver Recetas",   Nav.MOD_RECIPES)
        );
        var group3 = List.of(
            new E("Items Din.",    Nav.CUSTOM_ITEMS)
        );
        // Group 1 — Gestión
        int y = HEADER_H + 16;
        for (var e : group1) {
            method_37063(new NavBtn(4, y, SIDEBAR_W - 8, NAV_H, e.label(), e.nav()));
            y += NAV_H + 2;
        }
        // Group 2 — Recetas
        y += 14;
        for (var e : group2) {
            method_37063(new NavBtn(4, y, SIDEBAR_W - 8, NAV_H, e.label(), e.nav()));
            y += NAV_H + 2;
        }
        // Group 3 — Items Dinámicos
        y += 14;
        for (var e : group3) {
            method_37063(new NavBtn(4, y, SIDEBAR_W - 8, NAV_H, e.label(), e.nav()));
            y += NAV_H + 2;
        }
    }

    // ── manage panel ──────────────────────────────────────────────────────────
    private void buildManagePanel() {
        int pad    = 7;
        int titleH = 28; // space for title + subtitle
        int searchY = cY + titleH + 2;
        int listTop = searchY + 14 + 4;
        int barH    = 26;
        int listBot = cY + cH - barH - 2;
        int barY    = cY + cH - barH + 2;

        boolean useItemPicker   = (activeNav == Nav.ITEMS || activeNav == Nav.BLOCKS);
        boolean useModPicker    = (activeNav == Nav.MODS);
        boolean useRecipePicker = (activeNav == Nav.RECIPES);
        boolean usePicker       = useItemPicker || useModPicker;

        // If picker is open, search goes in left half
        boolean anyPickerOpen = (usePicker && managePickerOpen) || (useRecipePicker && recipePickerOpen);
        int searchW = anyPickerOpen ? cW / 2 - pad * 2 - 4 : cW - pad * 2;
        searchBox = box(cX + pad, searchY, searchW, 13, "Buscar…");
        searchBox.method_1863(s -> refreshList());
        method_37063(searchBox);

        entryList = null; // replaced by manual grid renderer

        if (useItemPicker) {
            // Item/Block navigation: use a picker button instead of raw text field
            method_37063(new FlatBtn(
                    cX + pad, barY - 2, 148, 20,
                    managePickerOpen ? "✕  Cerrar buscador" : "⊞  Agregar ítem",
                    managePickerOpen ? C_BTN_REM : C_BTN_ADD,
                    managePickerOpen ? C_BTN_REMH : C_BTN_ADDH,
                    managePickerOpen ? 0xFFE08888 : 0xFF88E088,
                    b -> { managePickerOpen = !managePickerOpen; method_25426(); }));
            method_37063(new FlatBtn(
                    cX + pad + 154, barY - 2, 22, 20, "−",
                    C_BTN_REM, C_BTN_REMH, 0xFFE08888, b -> doRemove()));

            // If picker open: search field in right half
            if (managePickerOpen) {
                int pickX = cX + cW / 2 + 4;
                int pickW = cW / 2 - pad - 4;
                managePickerSearch = box(pickX, cY + 32, pickW - 4, 13, "Buscar ítem…");
                managePickerSearch.method_1863(this::applyManagePickerFilter);
                method_37063(managePickerSearch);
                applyManagePickerFilter("");
            }
        } else if (useModPicker) {
            // MODS: picker button (browse all loaded mods)
            method_37063(new FlatBtn(
                    cX + pad, barY - 2, 148, 20,
                    managePickerOpen ? "✕  Cerrar buscador" : "⊞  Agregar mod",
                    managePickerOpen ? C_BTN_REM : C_BTN_ADD,
                    managePickerOpen ? C_BTN_REMH : C_BTN_ADDH,
                    managePickerOpen ? 0xFFE08888 : 0xFF88E088,
                    b -> { managePickerOpen = !managePickerOpen; method_25426(); }));
            method_37063(new FlatBtn(
                    cX + pad + 154, barY - 2, 22, 20, "−",
                    C_BTN_REM, C_BTN_REMH, 0xFFE08888, b -> doRemove()));
            // If picker open: search field in right half
            if (managePickerOpen) {
                int pickX = cX + cW / 2 + 4;
                int pickW = cW / 2 - pad - 4;
                modPickerSearch = box(pickX, cY + 52, pickW - 4, 13, "Buscar mod…");
                modPickerSearch.method_1863(this::applyModPickerFilter);
                method_37063(modPickerSearch);
                applyModPickerFilter("");
            }
        } else {
            // RECIPES: manual text input + picker toggle button
            int btnW    = recipePickerOpen ? 96 : 120;
            int addW    = cW - pad * 2 - btnW - 4 - 22 - 2 - 22 - 2;
            addBox = box(cX + pad, barY, addW, 14, "namespace:id  ej. minecraft:iron_sword");
            method_37063(addBox);
            method_37063(new FlatBtn(
                    cX + pad + addW + 2, barY - 2, 22, 20, "+",
                    C_BTN_ADD, C_BTN_ADDH, 0xFF88E088, b -> doAdd()));
            method_37063(new FlatBtn(
                    cX + pad + addW + 26, barY - 2, 22, 20, "−",
                    C_BTN_REM, C_BTN_REMH, 0xFFE08888, b -> doRemove()));
            method_37063(new FlatBtn(
                    cX + pad + addW + 52, barY - 2, btnW, 20,
                    recipePickerOpen ? "✕ Cerrar" : "⊞ Buscar",
                    recipePickerOpen ? C_BTN_REM : C_BTN_NORM,
                    recipePickerOpen ? C_BTN_REMH : C_BTN_NORMH,
                    recipePickerOpen ? 0xFFE08888 : 0xFFAAAACC,
                    b -> { recipePickerOpen = !recipePickerOpen; method_25426(); }));
            if (recipePickerOpen) {
                int pickX = cX + cW / 2 + 4;
                int pickW = cW / 2 - pad - 4;
                recipePickerSearch = box(pickX, cY + 52, pickW - 4, 13, "Filtrar receta…");
                recipePickerSearch.method_1863(this::applyRecipePickerFilter);
                method_37063(recipePickerSearch);
                applyRecipePickerFilter("");
            }
        }

        refreshList();
    }

    // ── custom items panel ─────────────────────────────────────────────────────
    /** State for the custom-items form */
    private class_342 ciNameBox, ciIdBox;

    private void buildCustomItemsPanel() {
        int pad  = 7;
        int barY = cY + cH - 26;
        int fw   = (cW - pad * 3) / 2;
        ciIdBox   = box(cX + pad,          cY + 44, fw, 14, "ID  e.g. createnewrecipes:my_item");
        ciNameBox = box(cX + pad * 2 + fw, cY + 44, fw, 14, "Nombre para mostrar");
        method_37063(ciIdBox);
        method_37063(ciNameBox);
        method_37063(new FlatBtn(
                cX + pad, barY, 80, 20, "\u25b6  Guardar",
                C_BTN_SAV, C_BTN_SAVH, 0xFF88AAFF,
                b -> { /* TODO: save custom item */ }));
    }

    private void drawCustomItems(class_332 g, int mx, int my) {
        // Title strip
        g.method_25294(cX, cY, cX + cW, cY + 28, 0xFF181824);
        g.method_25294(cX, cY + 27, cX + cW, cY + 28, C_BORDER);
        g.method_25294(cX, cY + 5, cX + 3, cY + 23, C_ACCENT);
        g.method_51433(field_22793, "\u00a7b\u2022 \u00a7rItems Din\u00e1micos", cX + 9, cY + 6, C_TEXT, false);
        g.method_51433(field_22793, "\u00a78Define \u00edtems personalizados con modelo y textura propios.",
                cX + 14, cY + 16, C_TEXT_DIM, false);
        // Field labels
        g.method_51433(field_22793, "\u00a77ID del \u00edtem",    cX + 7,  cY + 34, C_TEXT_DIM, false);
        int fw2 = (cW - 7 * 3) / 2;
        g.method_51433(field_22793, "\u00a77Nombre visible", cX + 7 * 2 + fw2, cY + 34, C_TEXT_DIM, false);
        if (ciIdBox != null)
            g.method_25294(ciIdBox.method_46426(), ciIdBox.method_46427() + ciIdBox.method_25364(),
                   ciIdBox.method_46426() + ciIdBox.method_25368(), ciIdBox.method_46427() + ciIdBox.method_25364() + 1, C_ACCENT);
        if (ciNameBox != null)
            g.method_25294(ciNameBox.method_46426(), ciNameBox.method_46427() + ciNameBox.method_25364(),
                   ciNameBox.method_46426() + ciNameBox.method_25368(), ciNameBox.method_46427() + ciNameBox.method_25364() + 1, C_ACCENT);
        // Bottom bar
        int barSep = cY + cH - 28;
        g.method_25294(cX, barSep, cX + cW, cY + cH, 0xFF151520);
        g.method_25294(cX, barSep, cX + cW, barSep + 1, C_BORDER);
        g.method_51433(field_22793, "\u00a78M\u00e1s opciones (textura, modelo, stack\u2026) pr\u00f3ximamente.",
                cX + 8, cY + 68, C_TEXT_DIM, false);
    }

    // ── my-recipes panel ──────────────────────────────────────────────────────
    private void buildMyRecipesPanel() {
        int pad = 7;
        int titleH = 28;
        int searchY = cY + titleH + 2;
        customSearchBox = box(cX + pad, searchY, cW / 2 - pad * 2, 13, "Search saved recipes…");
        customSearchBox.method_1863(s -> { /* list redrawn every frame */ });
        method_37063(customSearchBox);

        // Delete button at bottom
        method_37063(new FlatBtn(
                cX + cW / 2 - 70, cY + cH - 24, 68, 20,
                "✖ Delete", C_BTN_REM, C_BTN_REMH, 0xFFE08888,
                b -> doDeleteCustom()));
    }

    private void doDeleteCustom() {
        List<CreateNewRecipesClient.CustomRecipeInfo> list = filteredCustom();
        if (selectedCustomIdx < 0 || selectedCustomIdx >= list.size()) return;
        String rid = list.get(selectedCustomIdx).recipeId();
        CreateNewRecipesClient.sendDeleteCustom(rid);
        selectedCustomIdx = -1;
    }

    /** Returns custom recipes filtered by the search box. */
    private List<CreateNewRecipesClient.CustomRecipeInfo> filteredCustom() {
        String q = customSearchBox != null ? customSearchBox.method_1882().toLowerCase() : "";
        List<CreateNewRecipesClient.CustomRecipeInfo> src = CreateNewRecipesClient.customRecipes;
        if (q.isEmpty()) return src;
        return src.stream().filter(r ->
                r.recipeId().toLowerCase().contains(q) ||
                r.type().toLowerCase().contains(q)).toList();
    }

    public void refreshCustomRecipes() {
        // No widgets to rebuild; list is redrawn every frame
        if (selectedCustomIdx >= filteredCustom().size()) selectedCustomIdx = -1;
    }

    // ── new-recipe panel ──────────────────────────────────────────────────────
    private static final int TYPE_COL_W = 110; // left column width
    private static final int FORM_COL_W = 290; // form fields column width
    private static final int DIAG_H     = 110; // height of diagram card

    private void buildNewRecipePanel() {
        // ── Apply pending edit staging (set by doEditModRecipe before switchNav) ──
        if (pendingEditVals != null) {
            fieldValues.putAll(pendingEditVals);
            pendingEditVals = null;
        }
        if (pendingEditStacks != null) {
            fieldItems.putAll(pendingEditStacks);
            pendingEditStacks = null;
        }
        // Re-parse any count/nc suffixes from pending field values
        for (var kv : fieldValues.entrySet()) {
            String raw = kv.getValue();
            if (raw == null || raw.isEmpty()) continue;
            String[] parts = raw.trim().split("\\s+");
            // parts[0] = item_id, parts[1] = count (opt), parts[2] = nc (opt)
            for (int pi = 1; pi < parts.length; pi++) {
                if (parts[pi].equalsIgnoreCase("nc")) {
                    fieldConsumed.put(kv.getKey(), false);
                } else {
                    try { fieldCounts.put(kv.getKey(), Math.max(1, Integer.parseInt(parts[pi]))); }
                    catch (NumberFormatException ignored) {}
                }
            }
        }

        RecipeType rt = TYPES.get(selectedType);
        int pad   = 8;
        int formX = cX + TYPE_COL_W + pad;
        int formW = FORM_COL_W;

        // Inline picker bounds (right panel)
        int pickX = formX + formW + pad;
        int pickW = cX + cW - pickX - 2;

        // ── Auto-fill defaults for special types (only when fields are fresh) ──
        if ("Caldera+Prensa".equals(rt.label())) {
            // Pre-set HEAT field (index 4) to "superheated" if user hasn't set it yet
            String[][] rtf = rt.fields();
            for (int i = 0; i < rtf.length; i++) {
                if ("HEAT".equals(rtf[i][0]) && !fieldValues.containsKey(i)) {
                    fieldValues.put(i, "superheated");
                }
            }
        }

        // ── Recipe ID ──────────────────────────────────────────────────────
        int fy = cY + pad;
        method_37063(new Label(formX, fy, "§7Recipe ID"));
        fy += 10;
        recipeIdBox = box(formX, fy, formW, 14, "createnewrecipes:my_recipe_id");
        if (pendingEditId != null) {
            recipeIdBox.method_1852(pendingEditId);
            pendingEditId = null;
        }
        method_37063(recipeIdBox);
        fy += 18;

        // ── Diagram — item slots are clickable, no form rows for item fields ──
        fy += DIAG_H + 4;

        // ── Non-item fields only (text fields like heat, time, pattern) ──────
        String[][] fields = rt.fields();
        for (int i = 0; i < fields.length; i++) {
            String[] f = fields[i];
            boolean isItem = "true".equals(f[2]);
            if (isItem) continue; // handled by diagram slot click
            if (fy + 20 > cY + cH - 28) break;
            String label = f[1];
            String hint  = f[3];
            boolean opt  = label.contains("optional");
            method_37063(new Label(formX, fy, opt ? "§7" + label : label));
            fy += 10;
            final int fi = i;
            String curVal = fieldValues.getOrDefault(i, "");
            class_342 eb = box(formX, fy, Math.min(formW, 260), 14, hint);
            eb.method_1852(curVal);
            eb.method_1863(v -> fieldValues.put(fi, v));
            method_37063(eb);
            fy += 18;
        }

        // ── Per-slot controls (shown when a slot is active) ──────────────
        if (activePicker >= 0 && activePicker < rt.fields().length) {
            boolean isItemSlot = "true".equals(rt.fields()[activePicker][2]);
            if (isItemSlot) {
                final int fi = activePicker;
                int ctrlY = cY + pad + 10 + 18 + 2; // just below recipe ID box
                // Quantity row label
                method_37063(new Label(formX, ctrlY, "§7Cantidad §8(slot activo §b" + (fi+1) + "§8)"));
                ctrlY += 10;
                int qtyVal = fieldCounts.getOrDefault(fi, 1);
                // − button
                method_37063(new FlatBtn(formX, ctrlY, 16, 14, "−",
                        C_BTN_NORM, C_BTN_NORMH, 0xFFCCBBAA,
                        b -> { fieldCounts.put(fi, Math.max(1, fieldCounts.getOrDefault(fi, 1) - 1)); method_25426(); }));
                // count display (static label)
                method_37063(new Label(formX + 20, ctrlY + 2, "§f" + qtyVal));
                // + button
                method_37063(new FlatBtn(formX + 36, ctrlY, 16, 14, "+",
                        C_BTN_NORM, C_BTN_NORMH, 0xFFAABBCC,
                        b -> { fieldCounts.put(fi, Math.min(64, fieldCounts.getOrDefault(fi, 1) + 1)); method_25426(); }));
                // Consumable toggle for this slot
                boolean slotConsumed = fieldConsumed.getOrDefault(fi, true);
                String conLabel = slotConsumed ? "\u00a7a\u25a3 Consumir" : "\u00a7c\u25a1 No consumir";
                int conBg = slotConsumed ? C_BTN_ADD : C_BTN_REM;
                int conBgh = slotConsumed ? C_BTN_ADDH : C_BTN_REMH;
                method_37063(new FlatBtn(formX + 58, ctrlY, 110, 14,
                        conLabel, conBg, conBgh, 0xFFEEEEAA,
                        b -> { fieldConsumed.put(fi, !fieldConsumed.getOrDefault(fi, true)); method_25426(); }));
            }
        }

        // ── Save button ────────────────────────────────────────────────────
        method_37063(new FlatBtn(formX, cY + cH - 24, formW, 20,
                "▶  Guardar Receta",
                C_BTN_SAV, C_BTN_SAVH, 0xFF9BC0E8, b -> doSaveRecipe()));

        // ── Consume-input toggle (default for new slots) ─────────────────
        method_37063(new ToggleBtn(
                formX + formW + 4, cY + cH - 24, 160, 20,
                () -> consumeInput ? "▣ Consumir (defecto)" : "□ No consumir (def.)",
                () -> consumeInput ? C_BTN_ADD : C_BTN_REM,
                () -> consumeInput ? C_BTN_ADDH : C_BTN_REMH,
                b -> consumeInput = !consumeInput));

        // ── Inline picker search box (right panel) ─────────────────────────
        if (pickW > 60) {
            pickerSearchBox = box(pickX + 4, cY + 26, pickW - 8, 14, "Search items…");
            pickerSearchBox.method_1863(this::applyPickerFilter);
            method_37063(pickerSearchBox);
        }
        applyPickerFilter("");
    }

    // ── process-chain panel ──────────────────────────────────────────────────
    private void buildProcessChainPanel() {
        int pad = 8;

        // Add node button
        method_37063(new FlatBtn(
                cX + pad, cY + pad + 30, 100, 16, "+ Paso",
                C_BTN_ADD, C_BTN_ADDH, 0xFF88E088, b -> {
                    chainNodes.add(new int[]{0});
                    chainItemIds.add("");
                    chainItemStacks.add(class_1799.field_8037);
                    chainFieldVals.add(new java.util.HashMap<>());
                    chainFieldStacks.add(new java.util.HashMap<>());
                    method_25426();
                }));

        // Remove selected node
        method_37063(new FlatBtn(
                cX + pad + 106, cY + pad + 30, 100, 16, "✖ Quitar",
                C_BTN_REM, C_BTN_REMH, 0xFFE08888, b -> {
                    if (chainSelected >= 0 && chainSelected < chainNodes.size()) {
                        chainNodes.remove(chainSelected);
                        chainItemIds.remove(chainSelected);
                        chainItemStacks.remove(chainSelected);
                        if (chainSelected < chainFieldVals.size())   chainFieldVals.remove(chainSelected);
                        if (chainSelected < chainFieldStacks.size()) chainFieldStacks.remove(chainSelected);
                        chainSelected = Math.min(chainSelected, chainNodes.size() - 1);
                        fieldValues.clear();
                        fieldItems.clear();
                        diagSlotBounds.clear();
                        activePicker = -1;
                        method_25426();
                    }
                }));

        // Chain ID prefix box
        chainIdBox = box(cX + pad, cY + pad + 10, 220, 14, "createnewrecipes:mi_proceso");
        method_37063(chainIdBox);

        // Diagram slot picker search (right panel, below diagram) — only when a node is selected
        if (chainSelected >= 0 && chainSelected < chainNodes.size()) {
            int splitX2  = cX + cW * 35 / 100;
            int rightW   = cX + cW - splitX2;
            int typeRowH = 20;
            int diagTop  = cY + 54 + typeRowH;
            int searchY2 = diagTop + DIAG_H + 8;
            if (searchY2 + 14 < cY + cH - 30) {
                chainPickerSearch = box(splitX2 + 6, searchY2, rightW - 12, 13, "Buscar ítem…");
                chainPickerSearch.method_1863(q -> { applyChainPickerFilter(q); chainPickerScroll = 0; });
                method_37063(chainPickerSearch);
                applyChainPickerFilter("");
            }
        }

        // Save chain button
        method_37063(new FlatBtn(
                cX + pad, cY + cH - 24, 200, 20,
                "▶  Guardar Proceso",
                C_BTN_SAV, C_BTN_SAVH, 0xFF9BC0E8,
                b -> doSaveProcessChain()));

        // Restore selected node's field data into fieldValues/fieldItems
        // (init() cleared them; we re-populate so the diagram shows the right items)
        if (chainSelected >= 0 && chainSelected < chainFieldVals.size()) {
            fieldValues.putAll(chainFieldVals.get(chainSelected));
        }
        if (chainSelected >= 0 && chainSelected < chainFieldStacks.size()) {
            fieldItems.putAll(chainFieldStacks.get(chainSelected));
        }
    }

    private void applyChainPickerFilter(String q) {
        chainPickerScroll = 0;
        chainPickerFiltered.clear();
        String lq = q.toLowerCase();
        for (class_1792 item : getAllItems()) {
            String id   = class_7923.field_41178.method_10221(item).toString();
            String name = item.method_7848().getString().toLowerCase();
            if (lq.isEmpty() || id.contains(lq) || name.contains(lq))
                chainPickerFiltered.add(item);
        }
    }

    private void doSaveProcessChain() {
        if (chainNodes.isEmpty()) return;
        String prefix = chainIdBox != null ? chainIdBox.method_1882().strip() : "createnewrecipes:proceso";
        if (prefix.isEmpty()) prefix = "createnewrecipes:proceso";
        if (field_22787 != null && field_22787.field_1724 != null) {
            field_22787.field_1724.method_7353(
                    net.minecraft.class_2561.method_43470(
                            "§b[CNR] Guardando proceso de §e" + chainNodes.size() + "§b pasos…"),
                    false);
        }
        for (int i = 0; i < chainNodes.size(); i++) {
            int typeIdx = chainNodes.get(i)[0];
            RecipeType rt = TYPES.get(typeIdx);
            String recipeId = prefix + "_paso" + (i + 1);
            // Use per-node stored field values
            Map<Integer, String> nodeVals = i < chainFieldVals.size() ? chainFieldVals.get(i) : java.util.Collections.emptyMap();
            List<String> vals = new ArrayList<>();
            for (int fi = 0; fi < rt.fields().length; fi++) {
                vals.add(nodeVals.getOrDefault(fi, "").strip());
            }
            CreateNewRecipesClient.sendNewRecipe(rt.typeId(), recipeId, consumeInput, vals);
        }
    }

    // ── mod-recipes panel ────────────────────────────────────────────────────
    private void buildModRecipesPanel() {
        int pad = 7;
        modRecipesSearchBox = box(cX + pad, cY + 32, cW - pad * 2, 13, "Buscar receta o tipo…");
        modRecipesSearchBox.method_1863(s -> {
            modRecipesFilter = s.toLowerCase();
            modRecipesScroll = 0;
        });
        method_37063(modRecipesSearchBox);

        // Edit button — opens selected recipe in NEW_RECIPE form for editing
        method_37063(new FlatBtn(
                cX + cW - 90, cY + cH - 24, 86, 20,
                "✎  Editar", C_BTN_SAV, C_BTN_SAVH, 0xFF9BC0E8,
                b -> doEditModRecipe()));
    }

    private void applyPickerFilter(String q) {
        pickerScroll = 0;
        pickerFiltered.clear();
        String lq = q.toLowerCase();
        for (class_1792 item : getAllItems()) {
            String id   = class_7923.field_41178.method_10221(item).toString();
            String name = item.method_7848().getString().toLowerCase();
            if (lq.isEmpty() || id.contains(lq) || name.contains(lq))
                pickerFiltered.add(item);
        }
    }

    private class_342 box(int x, int y, int w, int h, String hint) {
        class_342 b = new class_342(field_22793, x, y, w, h, class_2561.method_43473());
        b.method_1880(256);
        b.method_47404(class_2561.method_43470(hint));
        b.method_1858(false);
        return b;
    }

    // =========================================================================
    //  Actions
    // =========================================================================
    private void doAdd() {
        if (addBox == null) return;
        String val = addBox.method_1882().strip();
        if (val.isEmpty()) return;
        byte op = opForAdd();
        if (op < 0) return;
        CreateNewRecipesClient.sendModify(op, val);
        if (!activeList().contains(val)) activeList().add(val);
        addBox.method_1852("");
        refreshList();
    }

    private void doRemove() {
        List<String> fl = filteredManageList();
        if (manageSelected < 0 || manageSelected >= fl.size()) return;
        String val = fl.get(manageSelected);
        byte op = opForRemove();
        if (op < 0) return;
        CreateNewRecipesClient.sendModify(op, val);
        activeList().remove(val);
        manageSelected = -1;
        refreshList();
    }

    private void doSaveRecipe() {
        String id   = recipeIdBox != null ? recipeIdBox.method_1882().strip() : "";
        String type = TYPES.get(selectedType).typeId();
        String[][] fields = TYPES.get(selectedType).fields();

        List<String> vals = new ArrayList<>();
        for (int i = 0; i < fields.length; i++) {
            String base = fieldValues.getOrDefault(i, "").strip();
            boolean isItem = "true".equals(fields[i][2]);
            if (isItem && !base.isEmpty()) {
                int cnt = fieldCounts.getOrDefault(i, 1);
                boolean consumed = fieldConsumed.getOrDefault(i, consumeInput);
                StringBuilder sb = new StringBuilder(base);
                if (cnt > 1) sb.append(' ').append(cnt);
                if (!consumed) sb.append(" nc");
                vals.add(sb.toString());
            } else {
                vals.add(base);
            }
        }

        if (field_22787 != null && field_22787.field_1724 != null) {
            field_22787.field_1724.method_7353(
                    class_2561.method_43470("§b[CNR] Guardando → §r" + id + " (" + type + ")"),
                    false);
        }
        CreateNewRecipesClient.sendNewRecipe(type, id, consumeInput, vals);
    }

    // =========================================================================
    //  Helpers
    // =========================================================================
    private byte opForAdd() {
        return switch (activeNav) {
            case RECIPES -> ConfigPackets.ADD_RECIPE;
            case ITEMS   -> ConfigPackets.ADD_ITEM;
            case BLOCKS  -> ConfigPackets.ADD_BLOCK;
            case MODS    -> ConfigPackets.ADD_MOD;
            default      -> -1;
        };
    }
    private byte opForRemove() {
        return switch (activeNav) {
            case RECIPES -> ConfigPackets.REMOVE_RECIPE;
            case ITEMS   -> ConfigPackets.REMOVE_ITEM;
            case BLOCKS  -> ConfigPackets.REMOVE_BLOCK;
            case MODS    -> ConfigPackets.REMOVE_MOD;
            default      -> -1;
        };
    }
    private List<String> activeList() {
        return switch (activeNav) {
            case RECIPES -> CreateNewRecipesClient.recipes;
            case ITEMS   -> CreateNewRecipesClient.items;
            case BLOCKS  -> CreateNewRecipesClient.blocks;
            case MODS    -> CreateNewRecipesClient.mods;
            default      -> new ArrayList<>();
        };
    }

    public void refreshData() {
        if (searchBox != null) searchBox.method_1852("");
        refreshList();
    }

    private void refreshList() {
        // grid re-filtered on every frame via filteredManageList()
    }

    private List<String> filteredManageList() {
        String q = searchBox != null ? searchBox.method_1882().toLowerCase() : "";
        List<String> src = activeList();
        if (q.isEmpty()) return src.stream().sorted().toList();
        return src.stream().filter(s -> s.toLowerCase().contains(q)).sorted().toList();
    }

    /** Add mod by ID (used by manage-panel mod picker for MODS) */
    private void doAddMod(String modId) {
        byte op = opForAdd();
        if (op < 0) return;
        CreateNewRecipesClient.sendModify(op, modId);
        if (!activeList().contains(modId)) activeList().add(modId);
        managePickerOpen = false;
        method_25426();
    }

    /**
     * Returns (and caches) a ResourceLocation for the given mod's icon texture.
     * Returns null if the mod has no icon or the icon cannot be loaded.
     */
    private net.minecraft.class_2960 getModIconTexture(String modId) {
        if (MOD_ICON_CACHE.containsKey(modId)) return MOD_ICON_CACHE.get(modId);
        try {
            var containerOpt = net.fabricmc.loader.api.FabricLoader.getInstance().getModContainer(modId);
            if (containerOpt.isEmpty()) { MOD_ICON_CACHE.put(modId, null); return null; }
            var container = containerOpt.get();
            var iconPathOpt = container.getMetadata().getIconPath(32);
            if (iconPathOpt.isEmpty()) { MOD_ICON_CACHE.put(modId, null); return null; }
            var filePathOpt = container.findPath(iconPathOpt.get());
            if (filePathOpt.isEmpty()) { MOD_ICON_CACHE.put(modId, null); return null; }
            try (var is = java.nio.file.Files.newInputStream(filePathOpt.get())) {
                var img = net.minecraft.class_1011.method_4309(is);
                var tex = new net.minecraft.class_1043(img);
                // Build a safe RL path — only lowercase alphanumeric, underscore, hyphen, dot
                String safeName = modId.toLowerCase().replaceAll("[^a-z0-9_.\\-]", "_");
                var rl = new net.minecraft.class_2960("createnewrecipes", "modicon/" + safeName);
                net.minecraft.class_310.method_1551().method_1531().method_4616(rl, tex);
                MOD_ICON_CACHE.put(modId, rl);
                return rl;
            }
        } catch (Exception e) {
            MOD_ICON_CACHE.put(modId, null);
            return null;
        }
    }

    /** Filter the manage-panel mod picker list */
    private void applyModPickerFilter(String q) {
        modPickerScroll = 0;
        modPickerFiltered.clear();
        String lq = q.toLowerCase();
        net.fabricmc.loader.api.FabricLoader.getInstance().getAllMods().stream()
            // Only top-level mods (exclude JiJ / embedded sub-mods)
            .filter(mod -> {
                try { return mod.getContainingMod().isEmpty(); }
                catch (Exception e) { return true; }
            })
            .sorted(Comparator.comparing(m -> m.getMetadata().getId()))
            .forEach(mod -> {
                String id   = mod.getMetadata().getId();
                String name = mod.getMetadata().getName();
                if (lq.isEmpty() || id.contains(lq) || name.toLowerCase().contains(lq))
                    modPickerFiltered.add(new String[]{id, name});
            });
    }

    /** Filter the manage-panel recipe picker list (RECIPES nav) */
    private void applyRecipePickerFilter(String q) {
        recipePickerScroll = 0;
        recipePickerFiltered.clear();
        recipeIdsByItem.clear();
        String lq = q.strip().toLowerCase();
        if (field_22787 == null || field_22787.field_1687 == null) return;
        net.minecraft.class_1863 rm = field_22787.field_1687.method_8433();
        net.minecraft.class_5455 ra = field_22787.field_1687.method_30349();
        com.createnewrecipes.mod.mixin.RecipeManagerAccessor acc =
                (com.createnewrecipes.mod.mixin.RecipeManagerAccessor) rm;
        java.util.Map<net.minecraft.class_2960, ?> byNameMap = acc.getByName();
        if (byNameMap == null || byNameMap.isEmpty()) return;

        // Build itemId → [recipeId, ...] mapping (one entry per unique output item)
        byNameMap.entrySet().stream()
            .sorted(Comparator.comparing(e -> e.getKey().toString()))
            .forEach(e -> {
                String recipeId = e.getKey().toString();
                String outItemId = "";
                try {
                    net.minecraft.class_1860<?> recipe =
                            (net.minecraft.class_1860<?>) e.getValue();
                    class_1799 result = recipe.method_8110(ra);
                    if (!result.method_7960()) {
                        net.minecraft.class_2960 rl =
                                class_7923.field_41178.method_10221(result.method_7909());
                        if (rl != null && !rl.toString().equals("minecraft:air"))
                            outItemId = rl.toString();
                    }
                } catch (Exception ignored) {}
                if (outItemId.isEmpty()) return; // skip recipes with no determinable output
                recipeIdsByItem.computeIfAbsent(outItemId, k -> new ArrayList<>()).add(recipeId);
            });

        // Build filtered list: one per unique item; skip fully-blocked items; apply search
        List<String> activeL = activeList();
        recipeIdsByItem.entrySet().stream()
            .sorted(java.util.Map.Entry.comparingByKey())
            .filter(e -> !activeL.containsAll(e.getValue()))              // not all recipes blocked
            .filter(e -> lq.isEmpty() || e.getKey().contains(lq))        // search filter on item ID
            .forEach(e -> recipePickerFiltered.add(new String[]{e.getKey(), e.getKey()}));
    }

    /** Block a recipe directly (used by manage-panel recipe picker for RECIPES) */
    private void doAddRecipe(String recipeId) {
        byte op = opForAdd();
        if (op < 0) return;
        CreateNewRecipesClient.sendModify(op, recipeId);
        if (!activeList().contains(recipeId)) activeList().add(recipeId);
        if (addBox != null) addBox.method_1852(recipeId);
        String q = recipePickerSearch != null ? recipePickerSearch.method_1882() : "";
        applyRecipePickerFilter(q);
        refreshList();
    }

    /** Block ALL recipe IDs that produce the given item (used by recipe picker click) */
    private void doBlockByItemId(String itemId) {
        byte op = opForAdd();
        if (op < 0) return;
        List<String> recipeIds = recipeIdsByItem.getOrDefault(itemId, List.of(itemId));
        for (String rid : recipeIds) {
            CreateNewRecipesClient.sendModify(op, rid);
            if (!activeList().contains(rid)) activeList().add(rid);
        }
        if (addBox != null) addBox.method_1852(itemId + " ("+recipeIds.size()+" recipe(s))");
        String q = recipePickerSearch != null ? recipePickerSearch.method_1882() : "";
        applyRecipePickerFilter(q);
        refreshList();
    }

    /** Add item by ID directly (used by manage-panel item picker for ITEMS/BLOCKS) */
    private void doAddItem(String itemId) {
        byte op = opForAdd();
        if (op < 0) return;
        CreateNewRecipesClient.sendModify(op, itemId);
        if (!activeList().contains(itemId)) activeList().add(itemId);
        managePickerOpen = false;
        method_25426();
    }

    /** Filter the manage-panel item picker list */
    private void applyManagePickerFilter(String q) {
        managePickerScroll = 0;
        managePickerFiltered.clear();
        String lq = q.toLowerCase();
        boolean blocksOnly = (activeNav == Nav.BLOCKS);
        for (class_1792 item : getAllItems()) {
            if (blocksOnly && !(item instanceof net.minecraft.class_1747)) continue;
            String id   = class_7923.field_41178.method_10221(item).toString();
            String name = item.method_7848().getString().toLowerCase();
            if (lq.isEmpty() || id.contains(lq) || name.contains(lq))
                managePickerFiltered.add(item);
        }
    }

    /** Pre-populate NEW_RECIPE form with an existing mod recipe for editing */
    private void doEditModRecipe() {
        List<CreateNewRecipesClient.CustomRecipeInfo> list = filteredModRecipes();
        if (modRecipesSelected < 0 || modRecipesSelected >= list.size()) return;
        CreateNewRecipesClient.CustomRecipeInfo r = list.get(modRecipesSelected);

        // Find matching recipe type
        for (int i = 0; i < TYPES.size(); i++) {
            if (TYPES.get(i).typeId().equals(r.type())) { selectedType = i; break; }
        }

        // Stage field values (consumed in buildNewRecipePanel after init clears fieldValues)
        pendingEditId     = r.recipeId();
        pendingEditVals   = new java.util.HashMap<>();
        pendingEditStacks = new java.util.HashMap<>();
        for (int i = 0; i < r.fields().size(); i++) {
            String val = r.fields().get(i);
            if (val != null && !val.isEmpty()) {
                pendingEditVals.put(i, val);
                final int fi = i;
                // Extract just the item ID (first token); field may also contain count and "nc"
                String itemId = val.trim().split("\\s+")[0];
                try {
                    class_7923.field_41178.method_17966(
                            new net.minecraft.class_2960(itemId)).ifPresent(item ->
                        pendingEditStacks.put(fi, new class_1799(item)));
                } catch (Exception ignored) {}
            }
        }
        switchNav(Nav.NEW_RECIPE);
    }

    private void switchNav(Nav nav) {
        navAnimFrom = activeNav;
        navAnim = 0f;
        activeNav = nav;
        method_25426();
    }

    // =========================================================================
    //  Render
    // =========================================================================
    @Override
    public void method_25394(class_332 g, int mx, int my, float dt) {
        // ── Open animation: ease-in-out scale + fade ──────────────────────────
        float t = openAnim;
        float ease = t < 0.5f ? 2*t*t : (1 - (float)Math.pow(-2*t+2,2)/2);
        com.mojang.blaze3d.systems.RenderSystem.enableBlend();
        if (ease < 1f) {
            // Scale from center using matrix stack
            net.minecraft.class_4587 ps = g.method_51448();
            ps.method_22903();
            float cx = field_22789 / 2f, cy = field_22790 / 2f;
            float sc = 0.88f + 0.12f * ease;
            ps.method_46416(cx, cy, 0);
            ps.method_22905(sc, sc, 1);
            ps.method_46416(-cx, -cy, 0);
            renderContent(g, mx, my, dt, ease);
            ps.method_22909();
        } else {
            renderContent(g, mx, my, dt, 1f);
        }
    }

    /** All actual content rendering, separated so we can wrap in a pose-stack. */
    @SuppressWarnings("unused")
    private void renderContent(class_332 g, int mx, int my, float dt, float alpha) {
        g.method_25294(0, 0, field_22789, field_22790, C_BG);

        // ── animated header ───────────────────────────────────────────────────────────
        g.method_25294(0, 0, field_22789, HEADER_H, C_HEADER);
        // Shimmer: a brighter band scanning across the header accent line
        g.method_25294(0, HEADER_H - 1, field_22789, HEADER_H, C_ACCENT);
        int shimX = (int)(shimmer * (field_22789 + 60)) - 30;
        g.method_25294(Math.max(0, shimX), HEADER_H - 1,
               Math.min(field_22789, shimX + 40), HEADER_H,
               0xFFAAEEFF);
        g.method_25300(field_22793, "§b✦§r  Create New Recipes  §b✦", field_22789 / 2, 5, C_TEXT);

        // close × — animated glow
        int cx = field_22789 - 14, cy2 = 5;
        closeHov = mx >= cx - 2 && mx <= cx + 12 && my >= cy2 - 2 && my <= cy2 + 10;
        closeGlow = closeHov ? Math.min(1f, closeGlow + 0.15f) : Math.max(0f, closeGlow - 0.1f);
        int closeCol = lerpColor(C_TEXT_DIM, 0xFFFF6666, closeGlow);
        g.method_51433(field_22793, "×", cx, cy2, closeCol, false);

        // ── sidebar ─────────────────────────────────────────────────────────────────────
        g.method_25294(0, HEADER_H, SIDEBAR_W, field_22790, C_SIDEBAR);
        g.method_25294(SIDEBAR_W - 1, HEADER_H, SIDEBAR_W, field_22790, C_BORDER);
        g.method_51433(field_22793, "§8GESTIÓN", 8, HEADER_H + 5, C_TEXT_DIM, false);
        g.method_25294(8, HEADER_H + 13, SIDEBAR_W - 9, HEADER_H + 14, C_BORDER);
        int cat2y = HEADER_H + 16 + 4 * (NAV_H + 2) + 3;
        g.method_51433(field_22793, "§8RECETAS", 8, cat2y, C_TEXT_DIM, false);
        g.method_25294(8, cat2y + 8, SIDEBAR_W - 9, cat2y + 9, C_BORDER);
        int cat3y = cat2y + 14 + 3 * (NAV_H + 2) + 3;
        g.method_51433(field_22793, "§8CUSTOM", 8, cat3y, C_TEXT_DIM, false);
        g.method_25294(8, cat3y + 8, SIDEBAR_W - 9, cat3y + 9, C_BORDER);

        // ── content panel (with nav slide animation) ────────────────────────────
        float navEase = navAnim < 1f ? (1 - (float)Math.pow(1 - navAnim, 3)) : 1f;
        int slideOff = navAnim < 1f ? (int)((1f - navEase) * 12) : 0;
        net.minecraft.class_4587 ps2 = g.method_51448();
        if (slideOff > 0) {
            ps2.method_22903();
            ps2.method_46416(slideOff, 0, 0);
        }
        g.method_25294(cX, cY, cX + cW, cY + cH, C_PANEL);

        g.method_25300(field_22793, "§8/cnr gui", SIDEBAR_W / 2, field_22790 - 10, C_TEXT_DIM);

        switch (activeNav) {
            case RECIPES, ITEMS, BLOCKS, MODS -> drawManage(g, mx, my, dt);
            case MY_RECIPES                   -> drawMyRecipes(g, mx, my);
            case NEW_RECIPE                   -> drawNewRecipe(g, mx, my, dt);
            case PROCESS_CHAIN                -> drawProcessChain(g, mx, my);
            case MOD_RECIPES                  -> drawModRecipes(g, mx, my);
            case CUSTOM_ITEMS                 -> drawCustomItems(g, mx, my);
        }

        if (activeNav == Nav.NEW_RECIPE)    drawInlinePicker(g, mx, my);
        super.method_25394(g, mx, my, dt); // all widgets painted on top of picker bg
        if (slideOff > 0) ps2.method_22909();
        // grid rendered directly in drawManage
        if (activeNav == Nav.NEW_RECIPE)   drawItemSlotOverlay(g, mx, my);
        if (activeNav == Nav.MY_RECIPES)   drawMyRecipeRows(g, mx, my);
        if (activeNav == Nav.MOD_RECIPES)  drawModRecipeRows(g, mx, my);
        if (activeNav == Nav.PROCESS_CHAIN) drawChainPickerOverlay(g, mx, my);
    }

    // ── my-recipes draw \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
    /** Background / frame drawn BEFORE super.render (so widgets sit on top). */
    private void drawMyRecipes(class_332 g, int mx, int my) {
        // title strip — "• Title" style
        g.method_25294(cX, cY, cX + cW, cY + 28, 0xFF181824);
        g.method_25294(cX, cY + 27, cX + cW, cY + 28, C_BORDER);
        g.method_25294(cX, cY + 5, cX + 3, cY + 23, C_ACCENT);
        g.method_51433(field_22793, "§b• §rMis Recetas Guardadas", cX + 9, cY + 9, C_TEXT, false);
        int cnt = CreateNewRecipesClient.customRecipes.size();
        String badge = "(" + cnt + ")";
        g.method_51433(field_22793, badge, cX + cW - field_22793.method_1727(badge) - 8, cY + 9, C_TEXT_ACC, false);

        // two-column split
        int listW = cW * 55 / 100;
        // left panel bg
        g.method_25294(cX, cY + 28, cX + listW, cY + cH, 0xFF191924);
        // right panel bg
        g.method_25294(cX + listW + 1, cY + 28, cX + cW, cY + cH, 0xFF1C1C2E);
        // vertical divider
        g.method_25294(cX + listW, cY + 28, cX + listW + 1, cY + cH, C_BORDER);

        // search box underline
        if (customSearchBox != null)
            g.method_25294(customSearchBox.method_46426(),
                   customSearchBox.method_46427() + customSearchBox.method_25364(),
                   customSearchBox.method_46426() + customSearchBox.method_25368(),
                   customSearchBox.method_46427() + customSearchBox.method_25364() + 1, C_ACCENT);

        // delete button area separator
        g.method_25294(cX + 4, cY + cH - 28, cX + listW - 4, cY + cH - 27, C_BORDER);
        g.method_25294(cX, cY + cH - 27, cX + listW, cY + cH, 0xFF151520);
    }

    /** List rows + detail panel drawn AFTER super.render (on top of widget backgrounds). */
    private void drawMyRecipeRows(class_332 g, int mx, int my) {
        List<CreateNewRecipesClient.CustomRecipeInfo> list = filteredCustom();
        if (list == null) return;

        int listW  = cW * 55 / 100;
        int rowH   = 18;
        int listTop = cY + 44; // below title + search row
        int listBot = cY + cH - 30;
        int maxVis  = Math.max(1, (listBot - listTop) / rowH);
        if (customListScroll > Math.max(0, list.size() - maxVis))
            customListScroll = Math.max(0, list.size() - maxVis);

        for (int i = 0; i < maxVis; i++) {
            int idx = i + customListScroll;
            if (idx >= list.size()) break;
            CreateNewRecipesClient.CustomRecipeInfo rec = list.get(idx);
            int ry  = listTop + i * rowH;
            boolean sel = idx == selectedCustomIdx;
            boolean hov = mx >= cX && mx < cX + listW && my >= ry && my < ry + rowH;
            if      (sel) { g.method_25294(cX, ry, cX + listW, ry + rowH, C_ENTRY_SEL); g.method_25294(cX, ry, cX + 3, ry + rowH, C_ACCENT); }
            else if (hov) { g.method_25294(cX, ry, cX + listW, ry + rowH, C_ENTRY_HOV); g.method_25294(cX, ry, cX + 2, ry + rowH, C_BORDER); }
            String rp = sel ? "§b» §r" : "§7  ";
            g.method_51433(field_22793, rp + rec.recipeId(), cX + 4, ry + 2, sel ? 0xFFCCEEFF : C_TEXT, false);
            String typeName = rec.type().replace("create:", "");
            String conBadge = rec.consumeInput() ? "\u00a7a\u25a3" : "\u00a7c\u25a1";
            g.method_51433(field_22793, "\u00a78" + typeName + " " + conBadge, cX + 6, ry + 10, C_TEXT_DIM, false);
        }

        // scrollbar
        if (list.size() > maxVis) {
            int sbX = cX + listW - 5;
            int sbH = listBot - listTop;
            g.method_25294(sbX, listTop, sbX + 3, listBot, 0xFF252533);
            int thumbH = Math.max(8, sbH * maxVis / list.size());
            int thumbY = listTop + (list.size() > maxVis
                    ? (sbH - thumbH) * customListScroll / (list.size() - maxVis)
                    : 0);
            g.method_25294(sbX, thumbY, sbX + 3, thumbY + thumbH, C_BORDER);
        }

        // detail panel
        int detailX = cX + listW + 10;
        int detailW = cW - listW - 14;
        if (selectedCustomIdx >= 0 && selectedCustomIdx < list.size()) {
            CreateNewRecipesClient.CustomRecipeInfo r = list.get(selectedCustomIdx);
            int dy = cY + 32;
            // «• recipe_id» header in cyan
            g.method_51433(field_22793, "§b• §r" + r.recipeId(), detailX, dy, C_TEXT, false); dy += 14;
            // —— Tipo ——
            g.method_25300(field_22793, "§8—— Tipo ——", detailX + detailW / 2, dy, C_TEXT_DIM); dy += 11;
            g.method_51433(field_22793, "  §8create:§7" + r.type().replace("create:", ""), detailX, dy, C_TEXT, false); dy += 12;
            String conLabel = r.consumeInput() ? "§a▣ Consume inputs: §aSí" : "§c□ Consume inputs: §cNo";
            g.method_51433(field_22793, conLabel, detailX, dy, C_TEXT, false); dy += 12;
            // —— Campos ——
            g.method_25300(field_22793, "§8—— Campos ——", detailX + detailW / 2, dy, C_TEXT_DIM); dy += 11;
            RecipeType rt = TYPES.stream()
                    .filter(t -> t.typeId().equals(r.type())).findFirst().orElse(null);
            List<String> fields = r.fields();
            for (int i = 0; i < fields.size(); i++) {
                if (dy + 10 > cY + cH - 30) break;
                String val = fields.get(i);
                if (val == null || val.isEmpty()) continue;
                String lbl = (rt != null && i < rt.fields().length) ? rt.fields()[i][1] : "Campo " + (i + 1);
                if (field_22793.method_1727(lbl) > detailW - 8) lbl = field_22793.method_1714(net.minecraft.class_2561.method_43470(lbl), detailW - 12).getString() + "\u2026";
                g.method_51433(field_22793, "§8" + lbl + ":", detailX + 2, dy, C_TEXT_DIM, false); dy += 9;
                g.method_51433(field_22793, "  §f" + val, detailX + 2, dy, C_TEXT, false); dy += 10;
            }
            // —— Info ——
            if (dy + 20 < cY + cH - 5) {
                g.method_25300(field_22793, "§8—— Info ——", detailX + detailW / 2, dy + 2, C_TEXT_DIM); dy += 12;
                g.method_51433(field_22793, "§8" + r.createdAt(), detailX + 2, dy, C_TEXT_DIM, false);
            }
        } else if (list.isEmpty()) {
            g.method_25300(field_22793, "§8No hay recetas guardadas.",
                    cX + cW / 2, cY + cH / 2 - 5, C_TEXT_DIM);
            g.method_25300(field_22793, "§8Usa §7Nueva Receta §8para crear una.",
                    cX + cW / 2, cY + cH / 2 + 5, C_TEXT_DIM);
        } else {
            g.method_25300(field_22793, "§8\u2190 Selecciona una receta",
                    detailX + detailW / 2, cY + cH / 2 - 4, C_TEXT_DIM);
            g.method_25300(field_22793, "§8para ver los detalles",
                    detailX + detailW / 2, cY + cH / 2 + 6, C_TEXT_DIM);
        }
    }

    // ── manage decorations ────────────────────────────────────────────────────
    private void drawManage(class_332 g, int mx, int my, float dt) {
        String title = switch (activeNav) {
            case RECIPES -> "Recetas Bloqueadas";
            case ITEMS   -> "Ítems Bloqueados";
            case BLOCKS  -> "Bloques Bloqueados";
            case MODS    -> "Mods Bloqueados";
            default      -> "";
        };
        String sub = switch (activeNav) {
            case RECIPES -> "Recetas eliminadas del sistema de crafteo.";
            case ITEMS   -> "Los jugadores no pueden usar estos ítems.";
            case BLOCKS  -> "Los jugadores no pueden interactuar con estos bloques.";
            case MODS    -> "TODAS las recetas de estos mods quedan bloqueadas.";
            default      -> "";
        };

        // Title strip
        g.method_25294(cX, cY, cX + cW, cY + 28, 0xFF181824);
        g.method_25294(cX, cY + 27, cX + cW, cY + 28, C_BORDER);
        g.method_25294(cX, cY + 5, cX + 3, cY + 23, C_ACCENT);
        g.method_51433(field_22793, "§b• §r" + title, cX + 9, cY + 6, C_TEXT, false);
        g.method_51433(field_22793, "§8" + sub, cX + 14, cY + 16, C_TEXT_DIM, false);
        List<String> all = filteredManageList();
        String badge = "§7(" + all.size() + ")";
        g.method_51433(field_22793, badge, cX + cW - field_22793.method_1727(badge) - 8, cY + 9, C_TEXT_ACC, false);

        // Search underline
        if (searchBox != null)
            g.method_25294(searchBox.method_46426(), searchBox.method_46427() + searchBox.method_25364(),
                   searchBox.method_46426() + searchBox.method_25368(),
                   searchBox.method_46427() + searchBox.method_25364() + 1, C_BORDER);

        // Bottom bar
        int barSep = cY + cH - 28;
        g.method_25294(cX, barSep, cX + cW, cY + cH, 0xFF151520);
        g.method_25294(cX, barSep, cX + cW, barSep + 1, C_BORDER);
        if (addBox != null)
            g.method_25294(addBox.method_46426(), addBox.method_46427() + addBox.method_25364(),
                   addBox.method_46426() + addBox.method_25368(),
                   addBox.method_46427() + addBox.method_25364() + 1, C_ACCENT);

        // When picker is open: split panel into left grid + right picker
        boolean useItemPicker   = (activeNav == Nav.ITEMS || activeNav == Nav.BLOCKS);
        boolean useModPicker    = (activeNav == Nav.MODS);
        boolean useRecipePicker = (activeNav == Nav.RECIPES);
        boolean anyPickerOpen   = (managePickerOpen && (useItemPicker || useModPicker))
                               || (useRecipePicker && recipePickerOpen);
        int gridRight = anyPickerOpen ? cX + cW / 2 - 4 : cX + cW;
        int pickerLeft = cX + cW / 2;

        // Picker panel background (ITEMS/BLOCKS only, when open)
        if (useItemPicker && managePickerOpen) {
            g.method_25294(pickerLeft, cY + 28, cX + cW, barSep, 0xFF1A1A2A);
            g.method_25294(pickerLeft, cY + 28, pickerLeft + 1, barSep, C_BORDER);
            // Picker header
            g.method_25294(pickerLeft, cY + 28, cX + cW, cY + 50, 0xFF131320);
            g.method_25294(pickerLeft, cY + 49, cX + cW, cY + 50, C_BORDER);
            g.method_25294(pickerLeft + 2, cY + 29, pickerLeft + 4, cY + 49, C_ACCENT);
            g.method_51433(field_22793, "§b Elegir " + (activeNav == Nav.ITEMS ? "Ítem" : "Bloque"),
                    pickerLeft + 8, cY + 34, C_TEXT_ACC, false);
            if (managePickerSearch != null) {
                g.method_25294(managePickerSearch.method_46426(), managePickerSearch.method_46427() + managePickerSearch.method_25364(),
                       managePickerSearch.method_46426() + managePickerSearch.method_25368(),
                       managePickerSearch.method_46427() + managePickerSearch.method_25364() + 1, C_ACCENT);
            }
            // Picker item grid
            final int CELL = 18;
            int pgX = pickerLeft + 4;
            int pgY = cY + 52;
            int pgW = cX + cW - pickerLeft - 10;
            int pgCols = Math.max(1, pgW / CELL);
            int pgH = barSep - pgY - 2;
            int pgRows = Math.max(1, pgH / CELL);
            int pgMax = Math.max(0, (managePickerFiltered.size() + pgCols - 1) / pgCols - pgRows);
            if (managePickerScroll > pgMax) managePickerScroll = pgMax;
            managePickerHoverItem = null;
            for (int row = 0; row <= pgRows; row++) {
                for (int col2 = 0; col2 < pgCols; col2++) {
                    int idx = (row + managePickerScroll) * pgCols + col2;
                    if (idx >= managePickerFiltered.size()) break;
                    int ix = pgX + col2 * CELL;
                    int iy = pgY + row * CELL;
                    if (iy + CELL > barSep - 2) continue;
                    class_1792 pItem = managePickerFiltered.get(idx);
                    boolean hov2 = mx >= ix && mx < ix + CELL && my >= iy && my < iy + CELL;
                    if (hov2) { g.method_25294(ix, iy, ix + CELL, iy + CELL, 0xFF3A4A6A); managePickerHoverItem = pItem; }
                    g.method_51427(new class_1799(pItem), ix + 1, iy + 1);
                }
            }
            if (pgMax > 0) {
                int sbX2 = cX + cW - 6;
                g.method_25294(sbX2, pgY, sbX2 + 3, barSep - 2, 0xFF252533);
                int th2 = Math.max(8, pgH * pgRows / (pgRows + pgMax));
                int ty2 = pgY + (pgH - th2) * managePickerScroll / pgMax;
                g.method_25294(sbX2, ty2, sbX2 + 3, ty2 + th2, C_BORDER);
            }
        }

        // Recipe picker panel (RECIPES only, when open)
        if (useRecipePicker && recipePickerOpen) {
            final int ROW_H = 22;
            g.method_25294(pickerLeft, cY + 28, cX + cW, barSep, 0xFF1A1A2A);
            g.method_25294(pickerLeft, cY + 28, pickerLeft + 1, barSep, C_BORDER);
            // Header row
            g.method_25294(pickerLeft, cY + 28, cX + cW, cY + 49, 0xFF131320);
            g.method_25294(pickerLeft, cY + 48, cX + cW, cY + 49, C_BORDER);
            g.method_25294(pickerLeft + 2, cY + 29, pickerLeft + 4, cY + 48, C_ACCENT);
            g.method_51433(field_22793, "\u00a7b Elegir Receta", pickerLeft + 8, cY + 34, C_TEXT_ACC, false);
            // Search row
            g.method_25294(pickerLeft, cY + 49, cX + cW, cY + 67, 0xFF0F0F1E);
            g.method_25294(pickerLeft, cY + 66, cX + cW, cY + 67, C_BORDER);
            if (recipePickerSearch != null) {
                g.method_25294(recipePickerSearch.method_46426(), recipePickerSearch.method_46427() + recipePickerSearch.method_25364(),
                       recipePickerSearch.method_46426() + recipePickerSearch.method_25368(),
                       recipePickerSearch.method_46427() + recipePickerSearch.method_25364() + 1, C_ACCENT);
            }
            // Recipe rows
            int rpX = pickerLeft + 4;
            int rpY = cY + 70;
            int rpW = cX + cW - pickerLeft - 10;
            int rpH = barSep - rpY - 2;
            int rpVisRows = Math.max(1, rpH / ROW_H);
            int rpMax = Math.max(0, recipePickerFiltered.size() - rpVisRows);
            if (recipePickerScroll > rpMax) recipePickerScroll = rpMax;
            net.minecraft.class_5455 rpRa = (field_22787.field_1687 != null)
                    ? field_22787.field_1687.method_30349() : net.minecraft.class_5455.field_40585;
            for (int ri = 0; ri < rpVisRows; ri++) {
                int idx = ri + recipePickerScroll;
                if (idx >= recipePickerFiltered.size()) break;
                String[] entry = recipePickerFiltered.get(idx);
                String recipeId = entry[0];
                String outItemId = entry[1];
                int ry = rpY + ri * ROW_H;
                boolean hov = mx >= rpX && mx < rpX + rpW && my >= ry && my < ry + ROW_H;
                if (hov) g.method_25294(rpX, ry, rpX + rpW, ry + ROW_H, 0xFF2A3A5A);
                else     g.method_25294(rpX, ry, rpX + rpW, ry + ROW_H, (idx % 2 == 0) ? 0xFF191926 : 0xFF161622);
                // Output item icon
                int rpTx = rpX + 4;
                if (!outItemId.isEmpty()) {
                    try {
                        class_1792 outItem = class_7923.field_41178.method_10223(
                                new net.minecraft.class_2960(outItemId));
                        g.method_51427(new class_1799(outItem), rpX + 2, ry + (ROW_H - 16) / 2);
                        rpTx = rpX + 20;
                    } catch (Exception ignored) {}
                }
                // Recipe ID text: namespace in dim, path in normal
                int txMax = rpW - (rpTx - rpX) - 4;
                String[] parts = recipeId.split(":", 2);
                String ns   = parts.length > 0 ? parts[0] : recipeId;
                String path = parts.length > 1 ? parts[1] : "";
                String full = "\u00a78" + ns + "\u00a77:\u00a7f" + path;
                boolean tooLong = field_22793.method_1727(recipeId) > txMax;
                String display = tooLong
                        ? field_22793.method_1714(class_2561.method_43470(recipeId), txMax - 6).getString() + "\u2026"
                        : null;
                g.method_51433(field_22793,
                        hov ? "\u00a7b" + (tooLong ? display : recipeId) : (tooLong ? "\u00a77" + display : full),
                        rpTx, ry + (ROW_H - 9) / 2, C_TEXT, false);
            }
            // Scrollbar
            if (rpMax > 0) {
                int sbX = cX + cW - 6;
                g.method_25294(sbX, rpY, sbX + 3, barSep - 2, 0xFF252533);
                int th = Math.max(8, rpH * rpVisRows / (rpVisRows + rpMax));
                int ty = rpY + (rpH - th) * recipePickerScroll / rpMax;
                g.method_25294(sbX, ty, sbX + 3, ty + th, C_BORDER);
            }
        }

        // Mod picker panel (MODS only, when open)
        if (useModPicker && managePickerOpen) {
            final int ROW_H = 24;
            g.method_25294(pickerLeft, cY + 28, cX + cW, barSep, 0xFF1A1A2A);
            g.method_25294(pickerLeft, cY + 28, pickerLeft + 1, barSep, C_BORDER);
            // Title-only header row
            g.method_25294(pickerLeft, cY + 28, cX + cW, cY + 49, 0xFF131320);
            g.method_25294(pickerLeft, cY + 48, cX + cW, cY + 49, C_BORDER);
            g.method_25294(pickerLeft + 2, cY + 29, pickerLeft + 4, cY + 48, C_ACCENT);
            g.method_51433(field_22793, "§b Elegir Mod", pickerLeft + 8, cY + 34, C_TEXT_ACC, false);
            // Search row (below header)
            g.method_25294(pickerLeft, cY + 49, cX + cW, cY + 67, 0xFF0F0F1E);
            g.method_25294(pickerLeft, cY + 66, cX + cW, cY + 67, C_BORDER);
            if (modPickerSearch != null) {
                g.method_25294(modPickerSearch.method_46426(), modPickerSearch.method_46427() + modPickerSearch.method_25364(),
                       modPickerSearch.method_46426() + modPickerSearch.method_25368(),
                       modPickerSearch.method_46427() + modPickerSearch.method_25364() + 1, C_ACCENT);
            }
            // Mod rows
            int mpX = pickerLeft + 4;
            int mpY = cY + 70;
            int mpW = cX + cW - pickerLeft - 10;
            int mpH = barSep - mpY - 2;
            int visRows2 = Math.max(1, mpH / ROW_H);
            int mpMax = Math.max(0, modPickerFiltered.size() - visRows2);
            if (modPickerScroll > mpMax) modPickerScroll = mpMax;
            for (int ri = 0; ri < visRows2; ri++) {
                int idx = ri + modPickerScroll;
                if (idx >= modPickerFiltered.size()) break;
                String[] mod = modPickerFiltered.get(idx);
                int ry = mpY + ri * ROW_H;
                boolean hov2 = mx >= mpX && mx < mpX + mpW && my >= ry && my < ry + ROW_H;
                if (hov2) g.method_25294(mpX, ry, mpX + mpW, ry + ROW_H, 0xFF2A3A5A);
                else      g.method_25294(mpX, ry, mpX + mpW, ry + ROW_H, (idx % 2 == 0) ? 0xFF191926 : 0xFF161622);
                // Mod icon (or letter badge fallback)
                net.minecraft.class_2960 iconRL = getModIconTexture(mod[0]);
                if (iconRL != null) {
                    g.method_25290(iconRL, mpX + 2, ry + 4, 0, 0, 16, 16, 16, 16);
                } else {
                    int lc = typeChipColor(mod[0] + ":");
                    g.method_25294(mpX + 2, ry + 4, mpX + 18, ry + 20, lc & 0x00FFFFFF | 0x55000000);
                    g.method_25294(mpX + 2, ry + 4, mpX + 18, ry + 5, lc);
                    g.method_25294(mpX + 2, ry + 19, mpX + 18, ry + 20, lc);
                    g.method_25294(mpX + 2, ry + 4, mpX + 3, ry + 20, lc);
                    g.method_25294(mpX + 17, ry + 4, mpX + 18, ry + 20, lc);
                    String letter = mod[0].isEmpty() ? "?" : String.valueOf(mod[0].charAt(0)).toUpperCase();
                    g.method_25300(field_22793, "§f" + letter, mpX + 10, ry + 8, C_TEXT);
                }
                // Mod ID + name
                int tx2 = mpX + 22;
                int txMax2 = mpW - 24;
                String modIdStr = field_22793.method_1727(mod[0]) > txMax2 ? field_22793.method_1714(net.minecraft.class_2561.method_43470(mod[0]), txMax2 - 4).getString() + "…" : mod[0];
                String modNameStr = field_22793.method_1727(mod[1]) > txMax2 ? field_22793.method_1714(net.minecraft.class_2561.method_43470(mod[1]), txMax2 - 4).getString() + "…" : mod[1];
                g.method_51433(field_22793, hov2 ? "§b" + modIdStr : "§f" + modIdStr, tx2, ry + 4, C_TEXT, false);
                g.method_51433(field_22793, "§8" + modNameStr, tx2, ry + 14, C_TEXT_DIM, false);
            }
            // Scrollbar
            if (mpMax > 0) {
                int sbX2 = cX + cW - 6;
                g.method_25294(sbX2, mpY, sbX2 + 3, barSep - 2, 0xFF252533);
                int th2 = Math.max(8, mpH * visRows2 / (visRows2 + mpMax));
                int ty2 = mpY + (mpH - th2) * modPickerScroll / mpMax;
                g.method_25294(sbX2, ty2, sbX2 + 3, ty2 + th2, C_BORDER);
            }
        }

        // Grid of icon cards
        int pad     = 10;
        int gridTop = cY + 48;
        int gridBot = barSep - 4;
        int gridWid = gridRight - cX - pad * 2;
        int cols    = Math.max(2, gridWid / 130);
        int cardW   = (gridWid - (cols - 1) * 6) / cols;
        int cardH   = 50;
        int rowH    = cardH + 6;
        int visRows = Math.max(1, (gridBot - gridTop) / rowH);
        int maxScr  = Math.max(0, (int)Math.ceil((double)all.size() / cols) - visRows);
        if (manageScroll > maxScr) manageScroll = maxScr;

        for (int i = 0; i < all.size(); i++) {
            int row    = i / cols;
            int col    = i % cols;
            int visRow = row - manageScroll;
            if (visRow < 0 || visRow >= visRows) continue;

            int cx2 = cX + pad + col * (cardW + 6);
            int cy2 = gridTop + visRow * rowH;
            if (cx2 + cardW > gridRight - 2) continue; // don't draw in picker area
            boolean sel = (i == manageSelected);
            boolean hov = mx >= cx2 && mx < cx2 + cardW && my >= cy2 && my < cy2 + cardH;

            // Card background
            int cardBg = sel ? C_ENTRY_SEL : (hov ? C_ENTRY_HOV : 0xFF19192A);
            g.method_25294(cx2, cy2, cx2 + cardW, cy2 + cardH, cardBg);

            // Border (4 sides)
            int bc = sel ? C_ACCENT : (hov ? C_BORDER : 0xFF25253A);
            g.method_25294(cx2,            cy2,            cx2 + cardW, cy2 + 1,     bc);
            g.method_25294(cx2,            cy2 + cardH - 1, cx2 + cardW, cy2 + cardH, bc);
            g.method_25294(cx2,            cy2,            cx2 + 1,     cy2 + cardH, bc);
            g.method_25294(cx2 + cardW - 1, cy2,           cx2 + cardW, cy2 + cardH, bc);
            if (sel) g.method_25294(cx2, cy2, cx2 + 3, cy2 + cardH, C_ACCENT); // left bar

            String entry = all.get(i);
            int colon    = entry.indexOf(':');
            String ns    = colon > 0 ? entry.substring(0, colon)    : "";
            String path  = colon > 0 ? entry.substring(colon + 1)   : entry;

            // Resolve icon
            class_1799 stack = class_1799.field_8037;
            if (colon > 0) {
                net.minecraft.class_2960 rl;
                try { rl = new net.minecraft.class_2960(entry); } catch (Exception e) { rl = null; }
                if (rl != null) {
                    var optItem  = class_7923.field_41178.method_17966(rl);
                    if (optItem.isPresent() && optItem.get() != net.minecraft.class_1802.field_8162)
                        stack = new class_1799(optItem.get());
                    else {
                        var optBlock = class_7923.field_41175.method_17966(rl);
                        if (optBlock.isPresent()) {
                            net.minecraft.class_1792 bi = optBlock.get().method_8389();
                            if (bi != net.minecraft.class_1802.field_8162) stack = new class_1799(bi);
                        }
                    }
                }
            }

            // Icon area (left)
            int iconX = cx2 + 5;
            int iconY = cy2 + (cardH - 16) / 2;
            if (!stack.method_7960()) {
                drawItemSlot(g, iconX - 1, iconY - 1, 18, 0xFF111120);
                g.method_51427(stack, iconX, iconY);
            } else {
                // Letter badge
                drawItemSlot(g, iconX - 1, iconY - 1, 18, 0xFF111120);
                int lc = typeChipColor(ns.isEmpty() ? "?" : ns + ":");
                g.method_25294(iconX, iconY, iconX + 16, iconY + 16, lc);
                String letter = ns.isEmpty() ? "?" : String.valueOf(ns.charAt(0)).toUpperCase();
                g.method_25300(field_22793, letter, iconX + 8, iconY + 4, C_TEXT);
            }

            // Text area (right of icon)
            int tx    = iconX + 23;
            int txMax = cardW - 30;
            String displayPath = field_22793.method_1727(path) > txMax - 2
                    ? field_22793.method_1714(net.minecraft.class_2561.method_43470(path), txMax - 6).getString() + "…"
                    : path;
            g.method_51433(field_22793, sel ? "§b" + displayPath : "§f" + displayPath,
                    tx, cy2 + 10, sel ? 0xFFCCEEFF : C_TEXT, false);

            // Namespace chip (small, bottom)
            if (!ns.isEmpty()) {
                int nsCol  = typeChipColor(ns + ":");
                int nsW    = field_22793.method_1727(ns) + 6;
                g.method_25294(tx, cy2 + cardH - 16, tx + nsW, cy2 + cardH - 5, nsCol & 0x55FFFFFF);
                g.method_25294(tx, cy2 + cardH - 16, tx + nsW, cy2 + cardH - 15, nsCol);
                g.method_51433(field_22793, "§8" + ns, tx + 3, cy2 + cardH - 15, C_TEXT_DIM, false);
            }
        }

        // Empty state
        if (all.isEmpty()) {
            g.method_25300(field_22793, "§8No hay entradas.", cX + cW / 2, (gridTop + gridBot) / 2, C_TEXT_DIM);
        }

        // Scrollbar
        int totalRows = (all.size() + cols - 1) / cols;
        if (totalRows > visRows) {
            int sbX  = cX + cW - 6;
            int sbH  = gridBot - gridTop;
            g.method_25294(sbX, gridTop, sbX + 3, gridBot, 0xFF252533);
            int thumbH = Math.max(12, sbH * visRows / totalRows);
            int thumbY = gridTop + (totalRows > visRows ? (sbH - thumbH) * manageScroll / (totalRows - visRows) : 0);
            g.method_25294(sbX, thumbY, sbX + 3, thumbY + thumbH, C_BORDER);
        }
    }

    // ── new-recipe decorations ────────────────────────────────────────────────
    private void drawNewRecipe(class_332 g, int mx, int my, float dt) {
        RecipeType rt = TYPES.get(selectedType);
        int pad   = 8;
        int formX = cX + TYPE_COL_W + pad;
        int formW = FORM_COL_W;

        // ── Left type-selector column ─────────────────────────────────────
        g.method_25294(cX, cY, cX + TYPE_COL_W, cY + cH, 0xFF161622);
        g.method_25294(cX + TYPE_COL_W, cY, cX + TYPE_COL_W + 1, cY + cH, C_BORDER);
        // category header
        g.method_25294(cX, cY, cX + TYPE_COL_W, cY + 14, 0xFF0F0F1C);
        g.method_25294(cX, cY + 13, cX + TYPE_COL_W, cY + 14, C_BORDER);
        g.method_25294(cX, cY + 2, cX + 3, cY + 12, C_ACCENT);
        g.method_51433(field_22793, "§b Tipo", cX + 6, cY + 3, C_TEXT_ACC, false);

        int rowH  = 14;
        int listY = cY + 16;
        for (int i = 0; i < TYPES.size(); i++) {
            int ry  = listY + i * rowH;
            if (ry + rowH > cY + cH - 2) break;
            boolean sel = (i == selectedType);
            boolean hov = mx >= cX && mx < cX + TYPE_COL_W && my >= ry && my < ry + rowH;
            if      (sel) { g.method_25294(cX, ry, cX + TYPE_COL_W, ry + rowH, C_NAV_SEL); g.method_25294(cX, ry, cX + 3, ry + rowH, C_ACCENT); }
            else if (hov) { g.method_25294(cX, ry, cX + TYPE_COL_W, ry + rowH, C_ENTRY_HOV); g.method_25294(cX, ry, cX + 2, ry + rowH, C_BORDER); }
            int tc = sel ? 0xFFCCEEFF : (hov ? C_TEXT : C_TEXT_DIM);
            g.method_51433(field_22793, (sel ? "§b»§r " : "  ") + TYPES.get(i).label(), cX + 4, ry + 3, tc, false);
        }

        // ── Diagram card ─────────────────────────────────────────────────
        // At:  formX, cY + pad + 10 + 18 = cY + pad + 28
        int diagY = cY + pad + 28;
        drawDiagramCard(g, rt, formX, diagY, formW, DIAG_H);

        // ── Hint: click a slot in the diagram to pick item ────────────────
        g.method_51433(field_22793, "\u00a78\u2190 Clic en un slot del diagrama para seleccionar \u00edtem",
                formX + 2, diagY + DIAG_H + 4, C_TEXT_DIM, false);

        // ── Field underlines ──────────────────────────────────────────────
        if (recipeIdBox != null)
            g.method_25294(recipeIdBox.method_46426(), recipeIdBox.method_46427() + recipeIdBox.method_25364(),
                   recipeIdBox.method_46426() + recipeIdBox.method_25368(),
                   recipeIdBox.method_46427() + recipeIdBox.method_25364() + 1, C_ACCENT);

        // Highlight active picker slot (glow border)
        if (activePicker >= 0 && diagSlotBounds.containsKey(activePicker)) {
            int[] b = diagSlotBounds.get(activePicker);
            g.method_25294(b[0] - 2, b[1] - 2, b[0] + b[2] + 2, b[1] + b[3] + 2, 0x5550C8E0);
        }
    }

    /** Render items in diagram slots (from fieldItems) + tooltip for hoverId. */
    private void drawItemSlotOverlay(class_332 g, int mx, int my) {
        // Draw item icons in diagram slots
        for (var e : diagSlotBounds.entrySet()) {
            int fi = e.getKey();
            int[] b = e.getValue(); // [x, y, w, h]
            class_1799 stack = fieldItems.get(fi);
            if (stack != null && !stack.method_7960()) {
                g.method_51427(stack, b[0], b[1]);
            }
        }
        // Hover: show tooltip + slightly bright slot
        for (var e : diagSlotBounds.entrySet()) {
            int[] b = e.getValue();
            boolean hov = mx >= b[0] && mx < b[0]+b[2] && my >= b[1] && my < b[1]+b[3];
            if (hov) {
                g.method_25294(b[0], b[1], b[0]+b[2], b[1]+b[3], 0x3350C8E0);
                class_1799 stack = fieldItems.get(e.getKey());
                if (stack != null && !stack.method_7960())
                    g.method_51446(field_22793, stack, mx, my);
                else {
                    RecipeType rt = TYPES.get(selectedType);
                    if (e.getKey() < rt.fields().length) {
                        String lbl = rt.fields()[e.getKey()][1];
                        g.method_51438(field_22793, class_2561.method_43470("\u00a77" + lbl), mx, my);
                    }
                }
            }
        }
        // Picker hover tooltip drawn last so nothing renders on top
        if (pickerHoverItem != null) {
            g.method_51446(field_22793, new class_1799(pickerHoverItem), mx, my);
        }
    }

    /** Draws a small count badge and consume indicator overlaid on a diagram slot. */
    private void drawSlotBadges(class_332 g, int fi, int sx, int sy, int slotSize) {
        int count = fieldCounts.getOrDefault(fi, 1);
        boolean consumed = fieldConsumed.getOrDefault(fi, consumeInput);
        // Consume dot: green = consumed, red = NOT consumed (kept)
        int dotCol = consumed ? 0xFF44CC44 : 0xFFCC4444;
        g.method_25294(sx + slotSize - 4, sy, sx + slotSize, sy + 4, dotCol);
        // Count badge (only if > 1)
        if (count > 1) {
            String badge = String.valueOf(count);
            g.method_25294(sx, sy + slotSize - 7, sx + field_22793.method_1727(badge) + 3, sy + slotSize, 0xAA000000);
            g.method_51433(field_22793, badge, sx + 1, sy + slotSize - 7, 0xFFFFFF88, false);
        }
    }

    /**
     * Draws the recipe diagram card: a dark rounded rect with the ASCII diagram,
     * role labels (IN → machine → OUT), and small item icons for filled fields.
     */
    private void drawDiagramCard(class_332 g, RecipeType rt,
                                 int x, int y, int w, int h) {
        // Card background + borders
        g.method_25294(x, y, x + w, y + h, C_DIAGRAM);
        g.method_25294(x, y,         x + w, y + 1,    C_BORDER);
        g.method_25294(x, y + h - 1, x + w, y + h,    C_BORDER);
        g.method_25294(x, y,         x + 1, y + h,    C_BORDER);
        g.method_25294(x + w - 1, y, x + w, y + h,    C_BORDER);
        // Accent top bar (orange)
        g.method_25294(x, y, x + w, y + 2, C_ACCENT_OR);

        // Type name + description
        g.method_51433(field_22793, "§e" + rt.label() + " §8— §7" + rt.typeId(),
                x + 5, y + 5, C_TEXT, false);
        String desc = rt.shortDesc();
        if (field_22793.method_1727(desc) > w - 10) {
            while (field_22793.method_1727(desc + "…") > w - 10 && !desc.isEmpty())
                desc = desc.substring(0, desc.length() - 1);
            desc += "…";
        }
        g.method_51433(field_22793, desc, x + 5, y + 15, C_TEXT_DIM, false);

        // Determine slots from fields
        List<String[]> inputs  = new ArrayList<>();
        List<String[]> outputs = new ArrayList<>();
        for (String[] f : rt.fields()) {
            if (f[0].startsWith("IN"))  inputs.add(f);
            if (f[0].startsWith("OUT")) outputs.add(f);
        }

        final int slotSize = 16;
        int diagramY = y + 27;
        int diagramH = h - 32;

        int nIn     = Math.min(inputs.size(),  3);
        int nOut    = Math.min(outputs.size(), 3);
        // inputs[0] → LEFT of machine; inputs[1..] → ABOVE machine (max 2 above)
        int nAbove  = Math.min(nIn - 1, 2);   // extra inputs shown above (0 if nIn<=1)

        // ── Geometry ──────────────────────────────────────────────────────────
        final int arrLen = 10;
        int inputX = x + 6;
        int arrX   = inputX + slotSize + 4;
        int machX  = arrX + arrLen + 4;
        int machW  = 28;
        int machH  = 28;
        int machCX = machX + machW / 2;

        // If there are above-inputs, push the machine down so they fit above it
        int aboveAreaH = nAbove > 0 ? nAbove * (slotSize + 2) + 4 : 0;
        int machTop    = diagramY + aboveAreaH;
        int machBot    = machTop + machH;
        int machCY     = machTop + machH / 2;

        // ── Above-inputs (inputs[1..]) ────────────────────────────────────────
        for (int si = 0; si < nAbove; si++) {
            int fi      = findFieldIdx(rt, "IN", si + 1);
            boolean sel = activePicker == fi;
            int slotBg  = sel ? 0xFF60301A : 0xFF2E1A10;
            int abX     = machCX - slotSize / 2;
            int abY     = diagramY + si * (slotSize + 2);
            drawItemSlot(g, abX, abY, slotSize, slotBg);
            g.method_25294(abX, abY, abX + 2, abY + slotSize, 0xFFAA3311); // red accent
            if (fi >= 0) {
                diagSlotBounds.put(fi, new int[]{abX, abY, slotSize, slotSize});
                if (fieldItems.containsKey(fi) && !fieldItems.get(fi).method_7960())
                    drawSlotBadges(g, fi, abX, abY, slotSize);
            }
        }
        // Down-arrow from above-inputs to machine top
        if (nAbove > 0) {
            int dax = machCX;
            int dayStart = diagramY + nAbove * (slotSize + 2);
            g.method_25294(dax,     dayStart, dax + 1,  machTop,     0xFF5577AA); // shaft
            g.method_25294(dax - 2, machTop - 3, dax + 3, machTop,   0xFF5577AA); // head
        }

        // ── Left input (inputs[0]) ────────────────────────────────────────────
        int arrY = machCY;
        if (nIn > 0) {
            int fi      = findFieldIdx(rt, "IN", 0);
            boolean sel = activePicker == fi;
            int slotBg  = sel ? 0xFF60301A : 0xFF2E1A10;
            int leftSlotY = machCY - slotSize / 2;
            drawItemSlot(g, inputX, leftSlotY, slotSize, slotBg);
            g.method_25294(inputX, leftSlotY, inputX + 2, leftSlotY + slotSize, 0xFFAA3311);
            if (fi >= 0) {
                diagSlotBounds.put(fi, new int[]{inputX, leftSlotY, slotSize, slotSize});
                if (fieldItems.containsKey(fi) && !fieldItems.get(fi).method_7960())
                    drawSlotBadges(g, fi, inputX, leftSlotY, slotSize);
            }
        }
        // Left arrow ──►
        g.method_25294(arrX,              arrY,     arrX + arrLen,      arrY + 1, 0xFF5577AA);
        g.method_25294(arrX + arrLen - 3, arrY - 2, arrX + arrLen + 1,  arrY + 3, 0xFF5577AA);

        // ── Machine box ───────────────────────────────────────────────────────
        g.method_25294(machX, machTop, machX + machW, machBot, 0xFF18192A);
        g.method_25294(machX,             machTop,     machX + machW, machTop + 1, C_ACCENT);
        g.method_25294(machX,             machBot - 1, machX + machW, machBot,     C_ACCENT);
        g.method_25294(machX,             machTop,     machX + 1,     machBot,     C_ACCENT);
        g.method_25294(machX + machW - 1, machTop,     machX + machW, machBot,     C_ACCENT);

        // Machine icon — static, centered
        class_1799 machStack = machineItemStack(rt.typeId());
        if (!machStack.method_7960()) {
            g.method_51448().method_22903();
            g.method_51448().method_46416(machCX - 8, machCY - 8, 200);
            g.method_51427(machStack, 0, 0);
            g.method_51448().method_22909();
        } else {
            g.method_25300(field_22793, "§e" + machineName(rt.typeId()), machCX, machCY - 4, C_TEXT);
        }

        // Name label below machine box
        g.method_25300(field_22793, "§8" + machineName(rt.typeId()), machCX, machBot + 2, C_TEXT_DIM);

        // ── Right arrow ──► and output slots ──────────────────────────────────
        int arrX2   = machX + machW + 4;
        g.method_25294(arrX2,              arrY,     arrX2 + arrLen,      arrY + 1, 0xFF5577AA);
        g.method_25294(arrX2 + arrLen - 3, arrY - 2, arrX2 + arrLen + 1,  arrY + 3, 0xFF5577AA);

        int outputX      = arrX2 + arrLen + 4;
        int outputsH     = nOut * (slotSize + 2) - 2;
        int outputStartY = machCY - outputsH / 2;
        for (int si = 0; si < nOut; si++) {
            int sy      = outputStartY + si * (slotSize + 2);
            int fi      = findFieldIdx(rt, "OUT", si);
            boolean sel = activePicker == fi;
            int slotBg  = sel ? 0xFF1A5028 : 0xFF0E2414;
            drawItemSlot(g, outputX, sy, slotSize, slotBg);
            g.method_25294(outputX, sy, outputX + 2, sy + slotSize, 0xFF33AA44);
            if (fi >= 0) {
                diagSlotBounds.put(fi, new int[]{outputX, sy, slotSize, slotSize});
                if (fieldItems.containsKey(fi) && !fieldItems.get(fi).method_7960())
                    drawSlotBadges(g, fi, outputX, sy, slotSize);
            }
        }

        // Labels
        int labY = diagramY + diagramH + 2;
        if (nIn  > 0) g.method_51433(field_22793, "§8Entrada", inputX,  labY, C_TEXT_DIM, false);
        if (nOut > 0) g.method_51433(field_22793, "§8Salida",  outputX, labY, C_TEXT_DIM, false);
    }

    private void drawItemSlot(class_332 g, int x, int y, int size, int bg) {
        g.method_25294(x, y, x + size, y + size, bg);
        g.method_25294(x,            y,       x + size, y + 1,        C_BORDER);
        g.method_25294(x,            y+size-1, x+size, y + size,      C_BORDER);
        g.method_25294(x,            y,       x + 1,    y + size,     C_BORDER);
        g.method_25294(x + size - 1, y,       x + size, y + size,     C_BORDER);
    }

    /** Returns the index within this type's fields array for the Nth IN or OUT slot */
    private int findFieldIdx(RecipeType rt, String rolePrefix, int nth) {
        int count = 0;
        String[][] fields = rt.fields();
        for (int i = 0; i < fields.length; i++) {
            if (fields[i][0].startsWith(rolePrefix)) {
                if (count == nth) return i;
                count++;
            }
        }
        return -1;
    }

    /** Resolves the Create mod block/item that represents the given recipe type. */
    private class_1799 machineItemStack(String typeId) {
        String id = switch (typeId) {
            case "create:deploying"           -> "create:deployer";
            case "create:mixing"              -> "create:mechanical_mixer";
            case "create:crushing"            -> "create:crushing_wheel";
            case "create:splashing"           -> "create:encased_fan";
            case "create:pressing"            -> "create:mechanical_press";
            case "createaddition:rolling"     -> "createaddition:rolling_mill";
            case "create:cutting"             -> "create:mechanical_saw";
            case "create:haunting"            -> "create:encased_fan";
            case "create:compacting"          -> "create:mechanical_press";
            case "create:sandpaper_polishing" -> "create:sand_paper";
            case "create:mechanical_crafting" -> "create:mechanical_crafter";
            case "create:sequenced_assembly"  -> "create:sequenced_gearshift";
            case "create:emptying"            -> "create:fluid_tank";
            case "create:filling"             -> "create:fluid_tank";
            default -> "";
        };
        if (id.isEmpty()) return class_1799.field_8037;
        try {
            return class_7923.field_41178
                    .method_17966(new net.minecraft.class_2960(id))
                    .map(class_1799::new)
                    .orElse(class_1799.field_8037);
        } catch (Exception e) { return class_1799.field_8037; }
    }

    /** Short name for the diagram machine box */
    private String machineName(String typeId) {
        return switch (typeId) {
            case "create:deploying"           -> "Deployer";
            case "create:mixing"              -> "Mixer";
            case "create:crushing"            -> "Crusher";
            case "create:splashing"           -> "Fan/H2O";
            case "create:pressing"            -> "Press";
            case "create:rolling",
                 "createaddition:rolling"     -> "Roller";
            case "create:cutting"             -> "Saw";
            case "create:haunting"            -> "Fan/Soul";
            case "create:compacting"          -> "Compact";
            case "create:sandpaper_polishing" -> "Sandppr";
            case "create:mechanical_crafting" -> "Crafters";
            case "create:sequenced_assembly"  -> "Assembly";
            case "create:emptying"            -> "Tank";
            case "create:filling"             -> "Tank";
            default -> "Machine";
        };
    }

    // ─── process-chain draw ───────────────────────────────────────────────────
    private void drawProcessChain(class_332 g, int mx, int my) {
        // Title strip
        g.method_25294(cX, cY, cX + cW, cY + 28, 0xFF181824);
        g.method_25294(cX, cY + 27, cX + cW, cY + 28, C_BORDER);
        g.method_25294(cX, cY + 5, cX + 3, cY + 23, C_ACCENT);
        g.method_51433(field_22793, "§b• §rProceso Encadenado", cX + 9, cY + 6, C_TEXT, false);
        g.method_51433(field_22793, "§8Cadena de pasos de manufactura.", cX + 230, cY + 16, C_TEXT_DIM, false);

        int splitX = cX + cW * 35 / 100;
        // Left: flow canvas
        g.method_25294(cX, cY + 28, splitX, cY + cH, 0xFF16162A);
        // Right: config panel
        g.method_25294(splitX + 1, cY + 28, cX + cW, cY + cH, 0xFF1A1A2E);
        g.method_25294(splitX, cY + 28, splitX + 1, cY + cH, C_BORDER);

        // ID box underline
        if (chainIdBox != null)
            g.method_25294(chainIdBox.method_46426(), chainIdBox.method_46427() + chainIdBox.method_25364(),
                   chainIdBox.method_46426() + chainIdBox.method_25368(), chainIdBox.method_46427() + chainIdBox.method_25364() + 1, C_ACCENT);

        // === FLOW DIAGRAM NODES (horizontal, wrapping) ===
        final int NODE_W    = 82;
        final int NODE_H    = 50;
        final int ARROW_W   = 18;
        final int NODE_GAP  = NODE_W + ARROW_W;
        int canvasW = splitX - cX - 8;
        int nodesPerRow = Math.max(1, canvasW / NODE_GAP);
        int flowTop     = cY + 54;
        int rowH        = NODE_H + 14;

        if (chainNodes.isEmpty()) {
            g.method_25300(field_22793, "§8Pulsa §7+ Paso §8para añadir el primer eslabón.",
                    cX + (splitX - cX) / 2, cY + cH / 2, C_TEXT_DIM);
        }

        for (int i = 0; i < chainNodes.size(); i++) {
            int row   = i / nodesPerRow;
            int col   = i % nodesPerRow;
            int nx    = cX + 6 + col * NODE_GAP;
            int ny    = flowTop + row * rowH;

            if (ny + NODE_H > cY + cH - 30) break; // out of visible area

            int typeIdx = chainNodes.get(i)[0];
            RecipeType rt = TYPES.get(typeIdx);
            boolean sel = (chainSelected == i);
            boolean hov = mx >= nx && mx < nx + NODE_W && my >= ny && my < ny + NODE_H;

            // Node card background
            int nodeBg = sel ? 0xFF1E2845 : (hov ? 0xFF1C1C30 : 0xFF14142A);
            g.method_25294(nx, ny, nx + NODE_W, ny + NODE_H, nodeBg);

            // Border + left accent bar for selected
            int bc = sel ? C_ACCENT : (hov ? C_BORDER : 0xFF222238);
            g.method_25294(nx,            ny,            nx + NODE_W, ny + 1,     bc);
            g.method_25294(nx,            ny + NODE_H - 1, nx + NODE_W, ny + NODE_H, bc);
            g.method_25294(nx,            ny,            nx + 1,     ny + NODE_H, bc);
            g.method_25294(nx + NODE_W - 1, ny,          nx + NODE_W, ny + NODE_H, bc);
            if (sel) {
                g.method_25294(nx, ny, nx + 3, ny + NODE_H, C_ACCENT);
                // Glow inner frame
                g.method_25294(nx + 3, ny + 1, nx + NODE_W - 1, ny + 2, 0x2050C8E0);
            }

            // Step number badge (top-right corner)
            int badgeBg = sel ? 0xFF2A4060 : 0xFF1A1A35;
            g.method_25294(nx + NODE_W - 18, ny + 2, nx + NODE_W - 2, ny + 12, badgeBg);
            g.method_25300(field_22793, "§8" + (i + 1), nx + NODE_W - 10, ny + 3, sel ? C_TEXT_ACC : C_TEXT_DIM);

            // Machine type chip (top-left area, colored)
            int chipCol = typeChipColor(rt.typeId());
            int typeLen = Math.min(rt.label().length(), 9);
            String shortLabel = typeLen < rt.label().length() ? rt.label().substring(0, typeLen) + "…" : rt.label();
            int chipW = field_22793.method_1727(shortLabel) + 6;
            g.method_25294(nx + 3, ny + 3, nx + 3 + chipW, ny + 13, chipCol & 0x44FFFFFF);
            g.method_25294(nx + 3, ny + 3, nx + 3 + chipW, ny + 4, chipCol);
            g.method_51433(field_22793, "§7" + shortLabel, nx + 6, ny + 4, sel ? 0xFFDDEEFF : C_TEXT_DIM, false);

            // Item icon + short name in center — read from per-node storage
            Map<Integer, class_1799> nStks2 = i < chainFieldStacks.size() ? chainFieldStacks.get(i) : java.util.Collections.emptyMap();
            Map<Integer, String>    nVals2 = i < chainFieldVals.size()   ? chainFieldVals.get(i)   : java.util.Collections.emptyMap();
            class_1799 outStack = class_1799.field_8037;
            String outId = "";
            for (int fi2 = 0; fi2 < rt.fields().length; fi2++) {
                if ("OUT".equals(rt.fields()[fi2][0])) {
                    outStack = nStks2.getOrDefault(fi2, class_1799.field_8037);
                    outId    = nVals2.getOrDefault(fi2, "");
                    break;
                }
            }
            if (!outStack.method_7960()) {
                g.method_51427(outStack, nx + 4, ny + 16);
                String display = outId.contains(":") ? outId.substring(outId.indexOf(':') + 1) : outId;
                if (field_22793.method_1727(display) > NODE_W - 26)
                    display = field_22793.method_1714(net.minecraft.class_2561.method_43470(display), NODE_W - 28).getString() + "…";
                g.method_51433(field_22793, "§f" + display, nx + 22, ny + 20, sel ? 0xFFCCEEFF : C_TEXT, false);
            } else {
                g.method_25300(field_22793, "§8clic para", nx + NODE_W / 2, ny + 20, C_TEXT_DIM);
                g.method_25300(field_22793, "§8configurar", nx + NODE_W / 2, ny + 32, C_TEXT_DIM);
            }

        // Connector arrow to next node
            boolean isLastInRow = (col == nodesPerRow - 1) || (i == chainNodes.size() - 1);
            if (!isLastInRow && i < chainNodes.size() - 1) {
                int ax = nx + NODE_W + 2;
                int ay = ny + NODE_H / 2 - 3;
                g.method_25294(ax,     ay + 3, ax + 10, ay + 4, C_ACCENT);
                g.method_25294(ax + 8, ay + 1, ax + 12, ay + 6, C_ACCENT);
                g.method_25294(ax + 10, ay + 2, ax + 13, ay + 5, C_ACCENT);
            } else if (i < chainNodes.size() - 1 && isLastInRow) {
                int ax = nx + NODE_W / 2;
                int ay = ny + NODE_H + 2;
                g.method_25294(ax, ay, ax + 1, ay + 6, C_BORDER);
            }
        }

        // ─── Right panel with diagram card ───

        int rightX = splitX + 2;
        int rightW = cX + cW - rightX - 2;

        if (chainSelected >= 0 && chainSelected < chainNodes.size()) {
            int typeIdx = chainNodes.get(chainSelected)[0];
            RecipeType rt = TYPES.get(typeIdx);

            // Title strip for right panel
            g.method_25294(rightX, cY + 28, cX + cW, cY + 50, 0xFF111122);
            g.method_25294(rightX, cY + 49, cX + cW, cY + 50, C_BORDER);
            g.method_51433(field_22793, "§bPaso §e" + (chainSelected + 1) + "  §b\u2500  " + rt.label(),
                    rightX + 8, cY + 34, C_TEXT_ACC, false);

            // Compact type chip row
            int typeRowY = cY + 52;
            int typeRowH = 14;
            int txc = rightX + 4;
            for (int i = 0; i < TYPES.size(); i++) {
                RecipeType trt = TYPES.get(i);
                String shortT = trt.label().length() > 7 ? trt.label().substring(0, 7) : trt.label();
                int tcW = field_22793.method_1727(shortT) + 8;
                if (txc + tcW > cX + cW - 4) { txc = rightX + 4; typeRowY += typeRowH + 2; }
                boolean tSel = (i == typeIdx);
                boolean tHov = mx >= txc && mx < txc + tcW && my >= typeRowY && my < typeRowY + typeRowH;
                int chipCol2 = typeChipColor(trt.typeId());
                int tcBg = tSel ? (chipCol2 & 0x00FFFFFF | 0x55000000) : (tHov ? 0xFF1E2030 : 0xFF161626);
                g.method_25294(txc, typeRowY, txc + tcW, typeRowY + typeRowH, tcBg);
                g.method_25294(txc, typeRowY, txc + tcW, typeRowY + 1, tSel ? chipCol2 : C_BORDER);
                g.method_25294(txc, typeRowY + typeRowH - 1, txc + tcW, typeRowY + typeRowH, tSel ? chipCol2 : C_BORDER);
                g.method_25294(txc, typeRowY, txc + 1, typeRowY + typeRowH, tSel ? chipCol2 : C_BORDER);
                g.method_25294(txc + tcW - 1, typeRowY, txc + tcW, typeRowY + typeRowH, tSel ? chipCol2 : C_BORDER);
                int tc2 = tSel ? 0xFFCCEEFF : (tHov ? C_TEXT : C_TEXT_DIM);
                g.method_51433(field_22793, shortT, txc + 4 + 1, typeRowY + 3, tc2, false);
                txc += tcW + 3;
            }
            int typeChipEndY = typeRowY + typeRowH + 4;

            // Diagram card for selected node
            int diagY = typeChipEndY + 2;
            // Sync fieldValues/fieldItems from per-node storage so diagram shows correct items
            Map<Integer, String>    nodeVals = chainSelected < chainFieldVals.size()   ? chainFieldVals.get(chainSelected)   : java.util.Collections.emptyMap();
            Map<Integer, class_1799> nodeStks = chainSelected < chainFieldStacks.size() ? chainFieldStacks.get(chainSelected) : java.util.Collections.emptyMap();
            fieldValues.clear(); fieldValues.putAll(nodeVals);
            fieldItems.clear();  fieldItems.putAll(nodeStks);
            diagSlotBounds.clear();
            drawDiagramCard(g, rt, rightX + 2, diagY, rightW - 4, DIAG_H);

            // Item picker hint / picker grid below diagram
            int pickerY = diagY + DIAG_H + 6;
            if (pickerY + 30 < cY + cH - 28) {
                if (activePicker >= 0 && activePicker < rt.fields().length) {
                    String fLabel = rt.fields()[activePicker][1];
                    g.method_25294(rightX, pickerY, cX + cW - 1, pickerY + 14, 0xFF141430);
                    g.method_25294(rightX, pickerY + 13, cX + cW - 1, pickerY + 14, C_ACCENT);
                    g.method_51433(field_22793, "§7Slct: §e" + fLabel, rightX + 4, pickerY + 3, C_TEXT, false);
                    pickerY += 16;
                } else {
                    g.method_25294(rightX, pickerY, cX + cW - 1, pickerY + 11, 0xFF111122);
                    g.method_25294(rightX, pickerY + 10, cX + cW - 1, pickerY + 11, C_BORDER);
                    g.method_51433(field_22793, "§8Clic en slot para elegir", rightX + 4, pickerY + 1, C_TEXT_DIM, false);
                    pickerY += 13;
                }
                if (chainPickerSearch != null) {
                    g.method_25294(chainPickerSearch.method_46426(), chainPickerSearch.method_46427() + chainPickerSearch.method_25364(),
                           chainPickerSearch.method_46426() + chainPickerSearch.method_25368(),
                           chainPickerSearch.method_46427() + chainPickerSearch.method_25364() + 1, C_ACCENT);
                    pickerY = chainPickerSearch.method_46427() + chainPickerSearch.method_25364() + 4;
                }
                final int CELL2 = 18;
                int gridX2 = rightX + 4;
                int gridW2 = rightW - 10;
                int cols2  = Math.max(1, gridW2 / CELL2);
                int gridH2 = cY + cH - 30 - pickerY;
                int rows2  = Math.max(1, gridH2 / CELL2);
                int maxSc2 = Math.max(0, (chainPickerFiltered.size() + cols2 - 1) / cols2 - rows2);
                if (chainPickerScroll > maxSc2) chainPickerScroll = maxSc2;
                chainPickerHoverItem = null;
                for (int row = 0; row <= rows2; row++) {
                    for (int col2 = 0; col2 < cols2; col2++) {
                        int idx = (row + chainPickerScroll) * cols2 + col2;
                        if (idx >= chainPickerFiltered.size()) break;
                        int ix = gridX2 + col2 * CELL2;
                        int iy = pickerY + row * CELL2;
                        if (iy + CELL2 > cY + cH - 28) continue;
                        class_1792 pItem = chainPickerFiltered.get(idx);
                        boolean hov2 = mx >= ix && mx < ix + CELL2 && my >= iy && my < iy + CELL2;
                        if (hov2) { g.method_25294(ix, iy, ix + CELL2, iy + CELL2, 0xFF3A4A6A); chainPickerHoverItem = pItem; }
                        g.method_51427(new class_1799(pItem), ix + 1, iy + 1);
                    }
                }
                if (maxSc2 > 0) {
                    int sbX2 = cX + cW - 6;
                    g.method_25294(sbX2, pickerY, sbX2 + 3, cY + cH - 28, 0xFF252533);
                    int thumbH3 = Math.max(8, gridH2 * rows2 / (rows2 + maxSc2));
                    int thumbY3 = pickerY + (gridH2 - thumbH3) * chainPickerScroll / maxSc2;
                    g.method_25294(sbX2, thumbY3, sbX2 + 3, thumbY3 + thumbH3, C_BORDER);
                }
            }
        }

        // Picker search underline
        if (chainPickerSearch != null)
            g.method_25294(chainPickerSearch.method_46426(), chainPickerSearch.method_46427() + chainPickerSearch.method_25364(),
                   chainPickerSearch.method_46426() + chainPickerSearch.method_25368(),
                   chainPickerSearch.method_46427() + chainPickerSearch.method_25364() + 1, C_ACCENT);
    }

    private void drawChainPickerOverlay(class_332 g, int mx, int my) {
        if (chainPickerHoverItem != null)
            g.method_51446(field_22793, new class_1799(chainPickerHoverItem), mx, my);
    }

    // ─── mod-recipes draw ─────────────────────────────────────────────────────
    private List<CreateNewRecipesClient.CustomRecipeInfo> filteredModRecipes() {
        List<CreateNewRecipesClient.CustomRecipeInfo> src = CreateNewRecipesClient.customRecipes;
        if (modRecipesFilter.isEmpty()) return src;
        return src.stream().filter(r ->
                r.recipeId().toLowerCase().contains(modRecipesFilter) ||
                r.type().toLowerCase().contains(modRecipesFilter)).toList();
    }

    private void drawModRecipes(class_332 g, int mx, int my) {
        // Title strip
        g.method_25294(cX, cY, cX + cW, cY + 28, 0xFF181824);
        g.method_25294(cX, cY + 27, cX + cW, cY + 28, C_BORDER);
        g.method_25294(cX, cY + 5, cX + 3, cY + 23, C_ACCENT);
        g.method_51433(field_22793, "§b• §rRecetas del Mod", cX + 9, cY + 6, C_TEXT, false);
        int cnt = CreateNewRecipesClient.customRecipes.size();
        String badge = "§7(" + cnt + " registradas)";
        g.method_51433(field_22793, badge, cX + cW - field_22793.method_1727(badge) - 8, cY + 9, C_TEXT_ACC, false);
        g.method_51433(field_22793, "§8Recetas creadas e inyectadas por este mod.", cX + 14, cY + 16, C_TEXT_DIM, false);

        int listW = cW * 55 / 100;
        g.method_25294(cX, cY + 28, cX + listW, cY + cH, 0xFF191924);
        g.method_25294(cX + listW + 1, cY + 28, cX + cW, cY + cH, 0xFF1C1C2E);
        g.method_25294(cX + listW, cY + 28, cX + listW + 1, cY + cH, C_BORDER);

        // Search underline
        if (modRecipesSearchBox != null)
            g.method_25294(modRecipesSearchBox.method_46426(), modRecipesSearchBox.method_46427() + modRecipesSearchBox.method_25364(),
                   modRecipesSearchBox.method_46426() + modRecipesSearchBox.method_25368(),
                   modRecipesSearchBox.method_46427() + modRecipesSearchBox.method_25364() + 1, C_ACCENT);

        g.method_25294(cX, cY + 50, cX + listW, cY + 51, C_BORDER);
    }

    private void drawModRecipeRows(class_332 g, int mx, int my) {
        List<CreateNewRecipesClient.CustomRecipeInfo> list = filteredModRecipes();
        int listW    = cW * 55 / 100;
        int rowH     = 20;
        int listTop  = cY + 52;
        int listBot  = cY + cH - 4;
        int maxVis   = Math.max(1, (listBot - listTop) / rowH);
        if (modRecipesScroll > Math.max(0, list.size() - maxVis))
            modRecipesScroll = Math.max(0, list.size() - maxVis);

        if (list.isEmpty()) {
            g.method_25300(field_22793, "§8No hay recetas registradas todavía.",
                    cX + listW / 2, cY + cH / 2 - 5, C_TEXT_DIM);
            g.method_25300(field_22793, "§8Crea una en §7Nueva Receta §8y guárdala.",
                    cX + listW / 2, cY + cH / 2 + 6, C_TEXT_DIM);
            return;
        }

        for (int i = 0; i < maxVis; i++) {
            int idx = i + modRecipesScroll;
            if (idx >= list.size()) break;
            CreateNewRecipesClient.CustomRecipeInfo rec = list.get(idx);
            int ry = listTop + i * rowH;
            boolean sel = idx == modRecipesSelected;
            boolean hov = mx >= cX && mx < cX + listW && my >= ry && my < ry + rowH;

            if      (sel) { g.method_25294(cX, ry, cX + listW, ry + rowH, C_ENTRY_SEL); g.method_25294(cX, ry, cX + 3, ry + rowH, C_ACCENT); }
            else if (hov) { g.method_25294(cX, ry, cX + listW, ry + rowH, C_ENTRY_HOV); }

            // Type chip
            String shortType = rec.type().contains(":") ? rec.type().substring(rec.type().indexOf(':') + 1) : rec.type();
            int chipCol = typeChipColor(rec.type());
            int chipW   = field_22793.method_1727(shortType) + 6;
            g.method_25294(cX + 5, ry + 2, cX + 5 + chipW, ry + rowH - 2, chipCol & 0x40FFFFFF);
            g.method_25294(cX + 5, ry + 2, cX + 5 + chipW, ry + 3, chipCol);
            g.method_51433(field_22793, shortType, cX + 8, ry + 4, sel ? 0xFFDDEEFF : C_TEXT_DIM, false);

            // Recipe path
            String rid = rec.recipeId();
            int txOff = cX + 5 + chipW + 6;
            if (rid.contains(":")) {
                String ns   = rid.substring(0, rid.indexOf(':') + 1);
                String path = rid.substring(rid.indexOf(':') + 1);
                g.method_51433(field_22793, "§8" + ns, txOff, ry + 4, C_TEXT_DIM, false);
                g.method_51433(field_22793, "§f" + path, txOff + field_22793.method_1727("§8" + ns), ry + 4, sel ? 0xFFCCEEFF : C_TEXT, false);
            } else {
                g.method_51433(field_22793, rid, txOff, ry + 4, sel ? 0xFFCCEEFF : C_TEXT, false);
            }

            // Consume badge
            g.method_51433(field_22793, rec.consumeInput() ? "§a▣" : "§c□", txOff, ry + 12, C_TEXT_DIM, false);
        }

        // Scrollbar
        if (list.size() > maxVis) {
            int sbX   = cX + listW - 5;
            int sbH   = listBot - listTop;
            g.method_25294(sbX, listTop, sbX + 3, listBot, 0xFF252533);
            int thumbH = Math.max(8, sbH * maxVis / list.size());
            int thumbY = listTop + (list.size() > maxVis
                    ? (sbH - thumbH) * modRecipesScroll / (list.size() - maxVis) : 0);
            g.method_25294(sbX, thumbY, sbX + 3, thumbY + thumbH, C_BORDER);
        }

        // Detail panel (right)
        int detailX = cX + listW + 10;
        int detailW = cW - listW - 14;
        if (modRecipesSelected >= 0 && modRecipesSelected < list.size()) {
            CreateNewRecipesClient.CustomRecipeInfo r = list.get(modRecipesSelected);
            int dy = cY + 32;
            g.method_51433(field_22793, "§b• §r" + r.recipeId(), detailX, dy, C_TEXT, false); dy += 14;
            g.method_25300(field_22793, "§8── Tipo ──", detailX + detailW / 2, dy, C_TEXT_DIM); dy += 11;
            g.method_51433(field_22793, "  §e" + r.type(), detailX, dy, C_TEXT, false); dy += 12;
            g.method_51433(field_22793, r.consumeInput() ? "§a▣ Consume: Sí" : "§c□ Consume: No", detailX, dy, C_TEXT, false); dy += 12;
            g.method_25300(field_22793, "§8── Valores ──", detailX + detailW / 2, dy, C_TEXT_DIM); dy += 11;
            RecipeType rt = TYPES.stream().filter(t -> t.typeId().equals(r.type())).findFirst().orElse(null);
            for (int i = 0; i < r.fields().size(); i++) {
                String val = r.fields().get(i);
                if (val == null || val.isEmpty()) continue;
                if (dy + 20 > cY + cH - 10) break;
                String lbl = (rt != null && i < rt.fields().length) ? rt.fields()[i][1] : "Campo " + (i + 1);
                boolean isItem = rt != null && i < rt.fields().length && "true".equals(rt.fields()[i][2]);
                if (isItem) {
                    class_1799 stk = class_1799.field_8037;
                    try {
                        stk = class_7923.field_41178.method_17966(new net.minecraft.class_2960(val))
                                .map(class_1799::new).orElse(class_1799.field_8037);
                    } catch (Exception ignored) {}
                    drawItemSlot(g, detailX + 2, dy - 1, 16, 0xFF1A2A3A);
                    if (!stk.method_7960()) g.method_51427(stk, detailX + 2, dy - 1);
                    g.method_51433(field_22793, "§8" + lbl, detailX + 22, dy - 1, C_TEXT_DIM, false);
                    g.method_51433(field_22793, "§f" + val, detailX + 22, dy + 7, C_TEXT, false);
                    dy += 20;
                } else {
                    g.method_51433(field_22793, "§8" + lbl + ": §f" + val, detailX + 2, dy, C_TEXT_DIM, false);
                    dy += 11;
                }
            }
            if (dy + 14 < cY + cH - 5)
                g.method_51433(field_22793, "§8" + r.createdAt(), detailX + 2, cY + cH - 14, C_TEXT_DIM, false);
        } else {
            g.method_25300(field_22793, "§8← Selecciona una receta",
                    detailX + detailW / 2, cY + cH / 2 - 4, C_TEXT_DIM);
        }
    }

    private int typeChipColor(String typeId) {
        return switch (typeId) {
            case "create:deploying"  -> 0xFF5B88BF;
            case "create:mixing"     -> 0xFF4A90A0;
            case "create:crushing"   -> 0xFFB06040;
            case "create:pressing"   -> 0xFF9040A0;
            case "create:splashing"  -> 0xFF4080B0;
            case "create:compacting" -> 0xFF707020;
            default                  -> 0xFF507050;
        };
    }

    // ─── inline picker panel ──────────────────────────────────────────────────
    private void drawInlinePicker(class_332 g, int mx, int my) {
        int pad   = 8;
        int formX = cX + TYPE_COL_W + pad;
        int pickX = formX + FORM_COL_W + pad;
        int pickW = cX + cW - pickX - 2;
        if (pickW < 40) return;

        int pickY = cY;
        int pickH = cH;

        // Panel bg + left border
        g.method_25294(pickX, pickY, pickX + pickW, pickY + pickH, 0xFF1C1C26);
        g.method_25294(pickX, pickY, pickX + 1, pickY + pickH, C_BORDER);

        // Header strip
        g.method_25294(pickX, pickY, pickX + pickW, pickY + 24, 0xFF14141C);
        g.method_25294(pickX, pickY, pickX + pickW, pickY + 2, C_ACCENT);
        g.method_25294(pickX, pickY + 23, pickX + pickW, pickY + 24, C_BORDER);

        String hdr = activePicker >= 0
                ? "§7Selecting for: §e" + TYPES.get(selectedType).fields()[activePicker][1]
                : "§8Click §7⊞ Pick §8on any item field";
        g.method_51433(field_22793, hdr, pickX + 6, pickY + 7, C_TEXT, false);

        String cnt = pickerFiltered.size() + " items";
        g.method_51433(field_22793, cnt, pickX + pickW - field_22793.method_1727(cnt) - 6, pickY + 7, C_TEXT_DIM, false);

        // search-box underline (box widget rendered by super.render after this call)
        if (pickerSearchBox != null)
            g.method_25294(pickerSearchBox.method_46426(),
                   pickerSearchBox.method_46427() + pickerSearchBox.method_25364(),
                   pickerSearchBox.method_46426() + pickerSearchBox.method_25368(),
                   pickerSearchBox.method_46427() + pickerSearchBox.method_25364() + 1, C_ACCENT);

        // ── Item grid ────────────────────────────────────────────────────
        final int CELL  = 20;
        int gridX = pickX + 4;
        int gridY = pickY + 44;          // header(24) + searchbox(14) + gap(6)
        int gridW = pickW - 10;          // leave room for scrollbar
        int cols  = Math.max(1, gridW / CELL);
        int gridH = pickY + pickH - gridY - 4;
        int rows  = Math.max(1, gridH / CELL);
        int maxSc = Math.max(0, (pickerFiltered.size() + cols - 1) / cols - rows);
        if (pickerScroll > maxSc) pickerScroll = maxSc;

        pickerHoverItem = null;

        for (int row = 0; row <= rows; row++) {
            for (int col = 0; col < cols; col++) {
                int idx = (row + pickerScroll) * cols + col;
                if (idx >= pickerFiltered.size()) break;
                int ix = gridX + col * CELL;
                int iy = gridY + row * CELL;
                if (iy + CELL > pickY + pickH - 2) continue;

                class_1792 item = pickerFiltered.get(idx);
                boolean hov = mx >= ix && mx < ix + CELL && my >= iy && my < iy + CELL;
                if (hov) {
                    g.method_25294(ix, iy, ix + CELL, iy + CELL, 0xFF3A4A6A);
                    pickerHoverItem = item;
                }
                g.method_51427(new class_1799(item), ix + 2, iy + 2);
            }
        }

        // Scrollbar
        if (maxSc > 0) {
            int sbX = pickX + pickW - 5;
            g.method_25294(sbX, gridY, sbX + 3, gridY + gridH, 0xFF252533);
            int thumbH = Math.max(8, gridH * rows / (rows + maxSc));
            int thumbY = gridY + (gridH - thumbH) * pickerScroll / maxSc;
            g.method_25294(sbX, thumbY, sbX + 3, thumbY + thumbH, C_BORDER);
        }
    }

    // ─── mouse ────────────────────────────────────────────────────────────────
    @Override
    public boolean method_25402(double mx, double my, int btn) {
        if (closeHov) { method_25419(); return true; }

        // Manage grid click (RECIPES / ITEMS / BLOCKS / MODS)
        if (activeNav == Nav.RECIPES || activeNav == Nav.ITEMS
                || activeNav == Nav.BLOCKS || activeNav == Nav.MODS) {
            boolean useItemPicker2   = (activeNav == Nav.ITEMS || activeNav == Nav.BLOCKS);
            boolean useModPicker2    = (activeNav == Nav.MODS);
            boolean useRecipePicker2 = (activeNav == Nav.RECIPES);
            boolean anyPickerOpen2   = (managePickerOpen && (useItemPicker2 || useModPicker2))
                                    || (useRecipePicker2 && recipePickerOpen);
            int gridRight2 = anyPickerOpen2 ? cX + cW / 2 - 4 : cX + cW;
            int pad      = 10;
            int gridTop  = cY + 48;
            int gridBot  = cY + cH - 28;

            // Manage picker grid click (right half, ITEMS/BLOCKS when open)
            if (useItemPicker2 && managePickerOpen) {
                int pickerLeft2 = cX + cW / 2;
                int pgY2 = cY + 52;
                final int MPCEL = 18;
                int pgW2 = cX + cW - pickerLeft2 - 10;
                int pgCols2 = Math.max(1, pgW2 / MPCEL);
                if (mx >= pickerLeft2 + 4 && mx < cX + cW - 6 && my >= pgY2 && my < gridBot) {
                    int col3 = (int)((mx - (pickerLeft2 + 4)) / MPCEL);
                    int row3 = (int)((my - pgY2) / MPCEL) + managePickerScroll;
                    int idx3 = row3 * pgCols2 + col3;
                    if (idx3 >= 0 && idx3 < managePickerFiltered.size()) {
                        String itemId2 = class_7923.field_41178.method_10221(managePickerFiltered.get(idx3)).toString();
                        doAddItem(itemId2);
                        return true;
                    }
                }
            }

            // Recipe picker click (right half, RECIPES when open)
            if (useRecipePicker2 && recipePickerOpen) {
                final int RECIPE_ROW_H = 22;
                int rpX2 = cX + cW / 2 + 4;
                int rpY2 = cY + 70; // list starts below search row
                int rpW2 = cX + cW - (cX + cW / 2) - 10;
                int rpBar2 = cY + cH - 28;
                int rpH2 = rpBar2 - rpY2 - 2;
                if (mx >= rpX2 && mx < rpX2 + rpW2 && (int)my >= rpY2 && (int)my < rpY2 + rpH2) {
                    int visRow2 = (int)((my - rpY2) / RECIPE_ROW_H) + recipePickerScroll;
                    if (visRow2 >= 0 && visRow2 < recipePickerFiltered.size()) {
                        doBlockByItemId(recipePickerFiltered.get(visRow2)[0]);
                        return true;
                    }
                }
            }

            // Mod picker click (right half, MODS when open)
            if (useModPicker2 && managePickerOpen) {
                final int MOD_ROW_H = 24;
                int mpX2 = cX + cW / 2 + 4;
                int mpY2 = cY + 70; // list starts below search row (search row: cY+49 to cY+67)
                int mpW2 = cX + cW - (cX + cW / 2) - 10;
                int mpH2 = gridBot - mpY2 - 2;
                if (mx >= mpX2 && mx < mpX2 + mpW2 && my >= mpY2 && my < mpY2 + mpH2) {
                    int visRow2 = (int)((my - mpY2) / MOD_ROW_H) + modPickerScroll;
                    if (visRow2 >= 0 && visRow2 < modPickerFiltered.size()) {
                        doAddMod(modPickerFiltered.get(visRow2)[0]);
                        return true;
                    }
                }
            }

            // Main grid click
            if (mx >= cX && mx < gridRight2 && my >= gridTop && my < gridBot) {
                List<String> fl = filteredManageList();
                int gridWid2 = gridRight2 - cX - pad * 2;
                int cols   = Math.max(2, gridWid2 / 130);
                int cardW  = (gridWid2 - (cols - 1) * 6) / cols;
                int cardH  = 50;
                int rowH2  = cardH + 6;
                int visRows = Math.max(1, (gridBot - gridTop) / rowH2);
                int col2   = (int)((mx - cX - pad) / (cardW + 6));
                int visRow = (int)((my - gridTop) / rowH2);
                if (col2 >= 0 && col2 < cols && visRow >= 0 && visRow < visRows) {
                    int idx = (visRow + manageScroll) * cols + col2;
                    if (idx >= 0 && idx < fl.size()) {
                        manageSelected = idx;
                        if (addBox != null) addBox.method_1852(fl.get(idx));
                        return true;
                    }
                }
            }
        }

        if (activeNav == Nav.NEW_RECIPE) {
            // Type-list column click
            int rowH  = 14;
            int listY = cY + 16;
            if (mx >= cX && mx < cX + TYPE_COL_W && my >= listY) {
                int idx = (int)((my - listY) / rowH);
                if (idx >= 0 && idx < TYPES.size()) {
                    selectedType = idx;
                    fieldValues.clear();
                    fieldItems.clear();
                    activePicker = -1;
                    diagSlotBounds.clear();
                    method_25426();
                    return true;
                }
            }

            // Diagram slot click → open picker for that field
            for (var e : diagSlotBounds.entrySet()) {
                int[] b = e.getValue();
                if (mx >= b[0] && mx < b[0]+b[2] && my >= b[1] && my < b[1]+b[3]) {
                    activePicker = e.getKey();
                    pickerScroll = 0;
                    return true;
                }
            }

            // Inline picker grid click
            if (activePicker >= 0) {
                int pad   = 8;
                int formX = cX + TYPE_COL_W + pad;
                int pickX = formX + FORM_COL_W + pad;
                int pickW = cX + cW - pickX - 2;
                if (pickW > 40) {
                    final int CELL  = 20;
                    int gridX = pickX + 4;
                    int gridY = cY + 44;
                    int gridW = pickW - 10;
                    int cols  = Math.max(1, gridW / CELL);
                    int gridH = cY + cH - gridY - 4;
                    int rows  = Math.max(1, gridH / CELL);
                    if (mx >= gridX && mx < gridX + cols * CELL
                            && my >= gridY && my < cY + cH - 2) {
                        int col = (int)((mx - gridX) / CELL);
                        int row = (int)((my - gridY) / CELL) + pickerScroll;
                        int idx = row * cols + col;
                        if (idx >= 0 && idx < pickerFiltered.size()) {
                            String id = class_7923.field_41178.method_10221(
                                    pickerFiltered.get(idx)).toString();
                            int fi = activePicker;
                            // Preserve existing count/consumed when replacing item
                            fieldValues.put(fi, id);
                            // Reset count/consumed only if slot was previously empty
                            if (!fieldItems.containsKey(fi) || fieldItems.get(fi).method_7960()) {
                                fieldCounts.put(fi, 1);
                                fieldConsumed.put(fi, consumeInput);
                            }
                            class_7923.field_41178.method_17966(
                                    new net.minecraft.class_2960(id)).ifPresent(item ->
                                fieldItems.put(fi, new class_1799(item)));
                            // Keep picker open so user can immediately adjust count/consume
                            return true;
                        }
                    }
                }
                activePicker = -1; // dismiss
            }
        }

        // PROCESS_CHAIN interactions
        if (activeNav == Nav.PROCESS_CHAIN) {
            int splitX = cX + cW * 35 / 100;
            int rightX = splitX + 2;
            int rightW = cX + cW - rightX - 2;

            // Flow node click (left panel) → select node and load its field data
            final int NODE_W  = 82;
            final int NODE_H  = 50;
            final int ARROW_W = 18;
            final int NODE_GAP = NODE_W + ARROW_W;
            int canvasW      = splitX - cX - 8;
            int nodesPerRow  = Math.max(1, canvasW / NODE_GAP);
            int flowTop      = cY + 54;
            int rowH2        = NODE_H + 14;
            if (mx >= cX && mx < splitX && my >= flowTop) {
                for (int i = 0; i < chainNodes.size(); i++) {
                    int row  = i / nodesPerRow;
                    int col  = i % nodesPerRow;
                    int nx   = cX + 6 + col * NODE_GAP;
                    int ny   = flowTop + row * rowH2;
                    if (mx >= nx && mx < nx + NODE_W && my >= ny && my < ny + NODE_H) {
                        int prevSel = chainSelected;
                        chainSelected     = i;
                        activePicker      = -1;
                        chainPickerScroll = 0;
                        diagSlotBounds.clear();
                        // Load this node's stored field data into fieldValues/fieldItems
                        fieldValues.clear();
                        fieldItems.clear();
                        if (i < chainFieldVals.size())   fieldValues.putAll(chainFieldVals.get(i));
                        if (i < chainFieldStacks.size()) fieldItems.putAll(chainFieldStacks.get(i));
                        if (prevSel != i) method_25426(); // rebuild search box
                        return true;
                    }
                }
            }

            // Right panel interactions (only when a node is selected)
            if (chainSelected >= 0 && chainSelected < chainNodes.size() && mx >= rightX) {
                int typeIdx = chainNodes.get(chainSelected)[0];
                RecipeType rt = TYPES.get(typeIdx);

                // Type chip row click → change node's machine type
                int typeRowY = cY + 52;
                int typeRowH = 14;
                int txc = rightX + 4;
                boolean typeClicked = false;
                for (int i = 0; i < TYPES.size(); i++) {
                    RecipeType trt = TYPES.get(i);
                    String shortT = trt.label().length() > 7 ? trt.label().substring(0, 7) : trt.label();
                    int tcW = field_22793.method_1727(shortT) + 8;
                    if (txc + tcW > cX + cW - 4) { txc = rightX + 4; typeRowY += typeRowH + 2; }
                    if (mx >= txc && mx < txc + tcW && my >= typeRowY && my < typeRowY + typeRowH) {
                        if (chainNodes.get(chainSelected)[0] != i) {
                            chainNodes.get(chainSelected)[0] = i;
                            // Clear this node's field data on type change
                            if (chainSelected < chainFieldVals.size())   chainFieldVals.get(chainSelected).clear();
                            if (chainSelected < chainFieldStacks.size()) chainFieldStacks.get(chainSelected).clear();
                            fieldValues.clear();
                            fieldItems.clear();
                            diagSlotBounds.clear();
                            activePicker = -1;
                            method_25426(); // rebuild search box for new type
                        }
                        typeClicked = true;
                        return true;
                    }
                    txc += tcW + 3;
                }

                // Diagram slot click → open chain item picker for that field
                if (!typeClicked) {
                    for (var e : diagSlotBounds.entrySet()) {
                        int[] b = e.getValue();
                        if (mx >= b[0] && mx < b[0]+b[2] && my >= b[1] && my < b[1]+b[3]) {
                            activePicker      = e.getKey();
                            chainPickerScroll = 0;
                            return true;
                        }
                    }
                }

                // Chain picker grid click (below diagram) → store item in per-node data
                if (activePicker >= 0 && chainPickerSearch != null) {
                    int pickerYStart = chainPickerSearch.method_46427() + chainPickerSearch.method_25364() + 4;
                    final int CELL2 = 18;
                    int gridX2 = rightX + 4;
                    int gridW2 = rightW - 10;
                    int cols2  = Math.max(1, gridW2 / CELL2);
                    if (mx >= gridX2 && mx < gridX2 + cols2 * CELL2 && my >= pickerYStart && my < cY + cH - 28) {
                        int col2 = (int)((mx - gridX2) / CELL2);
                        int row2 = (int)((my - pickerYStart) / CELL2) + chainPickerScroll;
                        int idx  = row2 * cols2 + col2;
                        if (idx >= 0 && idx < chainPickerFiltered.size()) {
                            String itemId = class_7923.field_41178.method_10221(chainPickerFiltered.get(idx)).toString();
                            int fi = activePicker;
                            // Save to current fieldValues/fieldItems
                            fieldValues.put(fi, itemId);
                            class_7923.field_41178.method_17966(
                                    new net.minecraft.class_2960(itemId)).ifPresent(item -> {
                                class_1799 stk = new class_1799(item);
                                fieldItems.put(fi, stk);
                                // Persist to per-node storage
                                while (chainFieldVals.size()   <= chainSelected) chainFieldVals.add(new java.util.HashMap<>());
                                while (chainFieldStacks.size() <= chainSelected) chainFieldStacks.add(new java.util.HashMap<>());
                                chainFieldVals.get(chainSelected).put(fi, itemId);
                                chainFieldStacks.get(chainSelected).put(fi, stk);
                                // Also update legacy chainItemIds/chainItemStacks for first OUT field
                                if ("OUT".equals(rt.fields()[fi][0])) {
                                    if (chainSelected < chainItemIds.size())   chainItemIds.set(chainSelected, itemId);
                                    if (chainSelected < chainItemStacks.size()) chainItemStacks.set(chainSelected, stk);
                                }
                            });
                            activePicker = -1;
                            return true;
                        }
                    }
                    activePicker = -1; // click outside picker — dismiss
                }
            }
        }

        // MOD_RECIPES: row selection
        if (activeNav == Nav.MOD_RECIPES) {
            int listW = cW * 55 / 100;
            int rowH  = 20;
            int listTop = cY + 52;
            if (mx >= cX && mx < cX + listW && my >= listTop && my < cY + cH - 4) {
                List<CreateNewRecipesClient.CustomRecipeInfo> list = filteredModRecipes();
                int i = (int)((my - listTop) / rowH) + modRecipesScroll;
                if (i >= 0 && i < list.size()) {
                    modRecipesSelected = i;
                    return true;
                }
            }
        }

        // MY_RECIPES: list row selection
        if (activeNav == Nav.MY_RECIPES) {
            int listW   = cW * 55 / 100;
            int rowH    = 18;
            int listTop = cY + 44;
            int listBot = cY + cH - 30;
            if (mx >= cX && mx < cX + listW && my >= listTop && my < listBot) {
                List<CreateNewRecipesClient.CustomRecipeInfo> list = filteredCustom();
                int i = (int)((my - listTop) / rowH) + customListScroll;
                if (i >= 0 && i < list.size()) {
                    selectedCustomIdx = i;
                    return true;
                }
            }
        }
        return super.method_25402(mx, my, btn);
    }
    @Override
    public boolean method_25401(double mx, double my, double delta) {
        // Manage grid scroll (RECIPES / ITEMS / BLOCKS / MODS)
        if (activeNav == Nav.RECIPES || activeNav == Nav.ITEMS
                || activeNav == Nav.BLOCKS || activeNav == Nav.MODS) {
            boolean usePickerScr       = (activeNav == Nav.ITEMS || activeNav == Nav.BLOCKS) && managePickerOpen;
            boolean useModPickerScr    = (activeNav == Nav.MODS) && managePickerOpen;
            boolean useRecipePickerScr = (activeNav == Nav.RECIPES) && recipePickerOpen;
            int gridTop = cY + 48;
            int gridBot = cY + cH - 28;
            // Item picker half scroll
            if (usePickerScr && mx >= cX + cW / 2 && my >= gridTop && my < gridBot) {
                managePickerScroll = Math.max(0, managePickerScroll - (int) Math.signum(delta));
                return true;
            }
            // Recipe picker half scroll
            if (useRecipePickerScr && mx >= cX + cW / 2 && my >= gridTop && my < gridBot) {
                recipePickerScroll = Math.max(0, recipePickerScroll - (int) Math.signum(delta));
                return true;
            }
            // Mod picker half scroll
            if (useModPickerScr && mx >= cX + cW / 2 && my >= gridTop && my < gridBot) {
                modPickerScroll = Math.max(0, modPickerScroll - (int) Math.signum(delta));
                return true;
            }
            // Grid scroll
            if (my >= gridTop && my < gridBot) {
                manageScroll = Math.max(0, manageScroll - (int) Math.signum(delta));
                return true;
            }
        }
        if (activeNav == Nav.MY_RECIPES) {
            int listW = cW * 55 / 100;
            if (mx >= cX && mx < cX + listW) {
                customListScroll = Math.max(0, customListScroll - (int) Math.signum(delta));
                return true;
            }
        }
        if (activeNav == Nav.NEW_RECIPE) {
            int pad   = 8;
            int formX = cX + TYPE_COL_W + pad;
            int pickX = formX + FORM_COL_W + pad;
            if (mx >= pickX) {
                pickerScroll = Math.max(0, pickerScroll - (int) Math.signum(delta));
                return true;
            }
        }
        if (activeNav == Nav.PROCESS_CHAIN) {
            int splitX = cX + cW * 35 / 100;
            if (mx >= splitX) {
                chainPickerScroll = Math.max(0, chainPickerScroll - (int) Math.signum(delta));
                return true;
            }
        }
        if (activeNav == Nav.MOD_RECIPES) {
            int listW = cW * 55 / 100;
            if (mx >= cX && mx < cX + listW) {
                modRecipesScroll = Math.max(0, modRecipesScroll - (int) Math.signum(delta));
                return true;
            }
        }
        return super.method_25401(mx, my, delta);
    }

    @Override public boolean method_25421() { return false; }

    // =========================================================================
    //  ItemSlotButton
    // =========================================================================
    public class ItemSlotButton extends class_4185 {
        private String itemId = "";
        private class_1799 stack = class_1799.field_8037;
        private final int fieldIdx;

        ItemSlotButton(int x, int y, int fieldIdx) {
            super(x, y, 20, 20, class_2561.method_43473(), b -> {}, field_40754);
            this.fieldIdx = fieldIdx;
        }

        @Override public void method_25306() { /* picker opened by adjacent FlatBtn */ }

        public void setItemId(String id) {
            this.itemId = id;
            fieldValues.put(fieldIdx, id);
            class_7923.field_41178.method_17966(
                    new net.minecraft.class_2960(id)).ifPresent(item -> {
                this.stack = new class_1799(item);
                fieldItems.put(fieldIdx, this.stack);
            });
        }

        public String getItemId() { return itemId; }
        public class_1799 getStack() { return stack; }

        @Override
        public void method_48579(class_332 g, int mx, int my, float dt) {
            boolean hov = method_49606();
            int bg = hov ? 0xFF2A3A4E : 0xFF1A1A2A;
            g.method_25294(method_46426(), method_46427(), method_46426()+20, method_46427()+20, bg);
            int bc = hov ? C_ACCENT : (stack.method_7960() ? C_BORDER : C_ACCENT2);
            g.method_25294(method_46426(),    method_46427(),    method_46426()+20, method_46427()+1,  bc);
            g.method_25294(method_46426(),    method_46427()+19, method_46426()+20, method_46427()+20, bc);
            g.method_25294(method_46426(),    method_46427(),    method_46426()+1,  method_46427()+20, bc);
            g.method_25294(method_46426()+19, method_46427(),    method_46426()+20, method_46427()+20, bc);
            if (!stack.method_7960()) {
                g.method_51427(stack, method_46426()+2, method_46427()+2);
            } else {
                // Empty: show dimmed cross
                g.method_25294(method_46426()+9,  method_46427()+4,  method_46426()+11, method_46427()+16, 0x33FFFFFF);
                g.method_25294(method_46426()+4,  method_46427()+9,  method_46426()+16, method_46427()+11, 0x33FFFFFF);
            }
        }
    }

    // =========================================================================
    //  FlatBtn
    // =========================================================================
    private class FlatBtn extends class_4185 {
        private final int bg, hov, tc;
        private float hoverT = 0f;
        FlatBtn(int x, int y, int w, int h, String label,
                int bg, int hov, int tc, class_4241 p) {
            super(x, y, w, h, class_2561.method_43470(label), p, field_40754);
            this.bg = bg; this.hov = hov; this.tc = tc;
        }
        @Override
        public void method_48579(class_332 g, int mx, int my, float dt) {
            boolean hovered = method_49606();
            hoverT = hovered ? Math.min(1f, hoverT + 0.18f) : Math.max(0f, hoverT - 0.12f);
            float ease = hoverT * hoverT * (3 - 2 * hoverT);
            int fill = lerpColor(bg, hov, ease);
            int bc   = lerpColor(C_BORDER, 0xFF6080A0, ease);
            g.method_25294(method_46426(), method_46427(), method_46426()+method_25368(), method_46427()+method_25364(), fill);
            g.method_25294(method_46426(), method_46427(), method_46426()+method_25368(), method_46427()+1, bc);
            g.method_25294(method_46426(), method_46427()+method_25364()-1, method_46426()+method_25368(), method_46427()+method_25364(), bc);
            g.method_25294(method_46426(), method_46427(), method_46426()+1, method_46427()+method_25364(), bc);
            g.method_25294(method_46426()+method_25368()-1, method_46427(), method_46426()+method_25368(), method_46427()+method_25364(), bc);
            // top glow line on hover
            if (ease > 0.05f) {
                int glowAlpha = (int)(0x33 * ease);
                g.method_25294(method_46426()+1, method_46427(), method_46426()+method_25368()-1, method_46427()+1,
                        (glowAlpha << 24) | (tc & 0xFFFFFF));
            }
            g.method_27534(field_22793, method_25369(),
                    method_46426()+method_25368()/2, method_46427()+(method_25364()-8)/2,
                    field_22763 ? lerpColor(tc, 0xFFFFFFFF, ease * 0.2f) : C_TEXT_DIM);
        }
    }

    // =========================================================================
    //  ToggleBtn — label/color supplied dynamically via lambdas
    // =========================================================================
    private class ToggleBtn extends class_4185 {
        private final java.util.function.Supplier<String>  label;
        private final java.util.function.Supplier<Integer> bgSupplier;
        private final java.util.function.Supplier<Integer> hovSupplier;
        private float hoverT = 0f;

        ToggleBtn(int x, int y, int w, int h,
                  java.util.function.Supplier<String>  label,
                  java.util.function.Supplier<Integer> bgSupplier,
                  java.util.function.Supplier<Integer> hovSupplier,
                  class_4241 press) {
            super(x, y, w, h, class_2561.method_43473(), press, field_40754);
            this.label = label; this.bgSupplier = bgSupplier; this.hovSupplier = hovSupplier;
        }
        @Override
        public void method_48579(class_332 g, int mx, int my, float dt) {
            boolean hovered = method_49606();
            hoverT = hovered ? Math.min(1f, hoverT + 0.18f) : Math.max(0f, hoverT - 0.12f);
            float ease = hoverT * hoverT * (3 - 2 * hoverT);
            int fill = lerpColor(bgSupplier.get(), hovSupplier.get(), ease);
            int bc   = lerpColor(C_BORDER, 0xFF6080A0, ease);
            g.method_25294(method_46426(), method_46427(), method_46426()+method_25368(), method_46427()+method_25364(), fill);
            g.method_25294(method_46426(), method_46427(), method_46426()+method_25368(), method_46427()+1, bc);
            g.method_25294(method_46426(), method_46427()+method_25364()-1, method_46426()+method_25368(), method_46427()+method_25364(), bc);
            g.method_25294(method_46426(), method_46427(), method_46426()+1, method_46427()+method_25364(), bc);
            g.method_25294(method_46426()+method_25368()-1, method_46427(), method_46426()+method_25368(), method_46427()+method_25364(), bc);
            g.method_25300(field_22793, label.get(),
                    method_46426()+method_25368()/2, method_46427()+(method_25364()-8)/2, C_TEXT);
        }
    }

    // =========================================================================
    //  NavBtn
    // =========================================================================
    private class NavBtn extends class_4185 {
        private final Nav target;
        private float hoverT = 0f;
        NavBtn(int x, int y, int w, int h, String label, Nav target) {
            super(x, y, w, h, class_2561.method_43470(label), b -> {}, field_40754);
            this.target = target;
        }
        @Override public void method_25306() { switchNav(target); }
        @Override
        public void method_48579(class_332 g, int mx, int my, float dt) {
            boolean sel = activeNav == target;
            boolean hov = method_49606();
            hoverT = hov ? Math.min(1f, hoverT + 0.15f) : Math.max(0f, hoverT - 0.1f);
            float ease = hoverT * hoverT * (3 - 2 * hoverT); // smoothstep

            // Background — interpolate sidebar → hover color
            int bgCol = sel ? C_NAV_SEL : lerpColor(C_SIDEBAR, 0xFF1E1E2E, ease);
            g.method_25294(method_46426(), method_46427(), method_46426()+method_25368(), method_46427()+method_25364(), bgCol);

            // Left accent bar — animated width (1→3px) and color
            if (sel) {
                g.method_25294(method_46426(), method_46427(), method_46426()+3, method_46427()+method_25364(), C_ACCENT);
                // glow: extra faint bar next to it
                g.method_25294(method_46426()+3, method_46427(), method_46426()+5, method_46427()+method_25364(), 0x2250C8E0);
            } else if (hoverT > 0.01f) {
                int barW = (int)(1 + ease);
                int barCol = lerpColor(C_BORDER, C_ACCENT, ease * 0.4f);
                g.method_25294(method_46426(), method_46427(), method_46426()+barW, method_46427()+method_25364(), barCol);
            }

            // Top/bottom highlight line on hover
            if (!sel && hoverT > 0.05f) {
                int lineAlpha = (int)(0x22 * ease);
                g.method_25294(method_46426(), method_46427(), method_46426()+method_25368(), method_46427()+1,
                        (lineAlpha << 24) | 0xAAEEFF);
            }

            String prefix = sel ? "§b• §r" : "§8• §7";
            int tc = sel ? C_TEXT : lerpColor(C_TEXT_DIM, 0xFFBBBBCC, ease);
            g.method_51433(field_22793, prefix + method_25369().getString(), method_46426()+6, method_46427()+(method_25364()-8)/2, tc, false);

            List<String> lst = switch (target) {
                case RECIPES -> CreateNewRecipesClient.recipes;
                case ITEMS   -> CreateNewRecipesClient.items;
                case BLOCKS  -> CreateNewRecipesClient.blocks;
                case MODS    -> CreateNewRecipesClient.mods;
                default      -> null;
            };
            if (lst != null && sel) {
                String cnt = String.valueOf(lst.size());
                // Pulsing count badge
                double pulse = 0.85 + 0.15 * Math.sin(shimmer * Math.PI * 2);
                int badgeCol = lerpColor(C_TEXT_DIM, C_TEXT_ACC, (float)pulse);
                g.method_51433(field_22793, cnt, method_46426()+method_25368()-field_22793.method_1727(cnt)-5,
                        method_46427()+(method_25364()-8)/2, badgeCol, false);
            }
        }
    }

    // =========================================================================
    //  Label widget
    // =========================================================================
    private class Label extends net.minecraft.class_339 {
        private final String text;
        Label(int x, int y, String t) { super(x,y,0,9, class_2561.method_43473()); text=t; }
        @Override public void method_47399(class_6382 n) {}
        @Override public boolean method_25402(double mx, double my, int b) { return false; }
        @Override public void method_48579(class_332 g, int mx, int my, float dt) {
            g.method_51433(field_22793, text, method_46426(), method_46427(), C_TEXT_DIM, false);
        }
    }

    // =========================================================================
    //  EntryList
    // =========================================================================
    private class EntryList extends class_4280<EntryList.Entry> {
        EntryList(int y0, int y1) {
            super(RecipeBlockerScreen.this.field_22787,
                    RecipeBlockerScreen.this.field_22789,
                    RecipeBlockerScreen.this.field_22790, y0, y1, 15);
            method_31322(false);
            method_31323(false);
        }
        void populate(List<String> src, String q) {
            method_25339();
            src.stream().filter(s -> q.isEmpty() || s.toLowerCase().contains(q))
               .sorted().forEach(s -> method_25321(new Entry(s)));
        }
        @Override public int method_25322() { return cW - 22; }
        @Override protected int method_25329() { return cX + cW - 6; }

        class Entry extends class_4280.class_4281<Entry> {
            final String value;
            private float hoverT = 0f;
            Entry(String v) { value = v; }
            @Override public class_2561 method_37006() { return class_2561.method_43470(value); }
            @Override public boolean method_25402(double mx, double my, int b) {
                EntryList.this.method_25313(this);
                if (addBox != null) addBox.method_1852(value);
                return true;
            }
            @Override
            public void method_25343(class_332 g, int idx, int top, int left,
                               int w, int h, int mx, int my, boolean hov, float dt) {
                boolean sel = EntryList.this.method_25334() == this;
                hoverT = hov ? Math.min(1f, hoverT + 0.18f) : Math.max(0f, hoverT - 0.12f);
                float ease = hoverT * hoverT * (3 - 2 * hoverT);

                if (sel) {
                    g.method_25294(left, top, left+w, top+h, C_ENTRY_SEL);
                    g.method_25294(left, top, left+3, top+h, C_ACCENT);
                    // glow next to bar
                    g.method_25294(left+3, top, left+5, top+h, 0x2250C8E0);
                } else if (ease > 0.01f) {
                    g.method_25294(left, top, left+w, top+h, lerpColor(0x00000000, C_ENTRY_HOV, ease));
                    g.method_25294(left, top, left+(int)(2*ease), top+h,
                            lerpColor(0x00333345, C_BORDER, ease));
                }

                int colon = value.indexOf(':');
                if (colon > 0) {
                    String ns   = value.substring(0, colon+1);
                    String path = value.substring(colon+1);
                    g.method_51433(field_22793, ns,   left+6, top+(h-8)/2, C_TEXT_DIM, false);
                    int pathCol = sel ? 0xFFCCEEFF : lerpColor(C_TEXT, 0xFFDDEEFF, ease);
                    g.method_51433(field_22793, path, left+6+field_22793.method_1727(ns), top+(h-8)/2, pathCol, false);
                } else {
                    int textCol = sel ? 0xFFCCEEFF : lerpColor(C_TEXT, 0xFFDDEEFF, ease);
                    g.method_51433(field_22793, value, left+6, top+(h-8)/2, textCol, false);
                }
            }
        }
    }

    // =========================================================================
    //  Color helpers
    // =========================================================================
    /** Linear interpolation between two ARGB colors. t in [0,1]. */
    private static int lerpColor(int a, int b, float t) {
        if (t <= 0f) return a;
        if (t >= 1f) return b;
        int aa = (a >> 24) & 0xFF, ra = (a >> 16) & 0xFF, ga = (a >> 8) & 0xFF, ba2 = a & 0xFF;
        int ab = (b >> 24) & 0xFF, rb = (b >> 16) & 0xFF, gb = (b >> 8) & 0xFF, bb2 = b & 0xFF;
        int ar = aa + (int)((ab - aa) * t);
        int rr = ra + (int)((rb - ra) * t);
        int gr = ga + (int)((gb - ga) * t);
        int br = ba2 + (int)((bb2 - ba2) * t);
        return (ar << 24) | (rr << 16) | (gr << 8) | br;
    }
}
