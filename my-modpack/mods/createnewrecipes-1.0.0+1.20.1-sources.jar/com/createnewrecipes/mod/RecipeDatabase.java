package com.createnewrecipes.mod;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.*;
import java.util.*;

/**
 * Manages a SQLite database of user-created custom recipes.
 *
 * File: config/createnewrecipes/recipes.db
 *
 * Schema:
 *   custom_recipes(id PK AUTOINCREMENT, type, recipe_id UNIQUE, consume_input, fields_json, created_at)
 */
public class RecipeDatabase {

    private static final Logger LOGGER = LoggerFactory.getLogger("createnewrecipes/db");

    private final Path dbPath;
    private Connection conn;

    public RecipeDatabase(Path configDir) {
        this.dbPath = configDir.resolve("createnewrecipes").resolve("recipes.db");
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    public void open() {
        try {
            Files.createDirectories(dbPath.getParent());
            // SQLite JDBC 3.45 auto-registers via ServiceLoader – no Class.forName needed
            conn = DriverManager.getConnection("jdbc:sqlite:" + dbPath.toAbsolutePath());
            conn.setAutoCommit(true);
            createTables();
            LOGGER.info("[CNR-DB] Opened database: {}", dbPath);
        } catch (Exception e) {
            LOGGER.error("[CNR-DB] Failed to open database: {}", e.getMessage());
            conn = null;
        }
    }

    public void close() {
        if (conn != null) {
            try { conn.close(); } catch (SQLException ignored) {}
            conn = null;
        }
    }

    public boolean isOpen() { return conn != null; }

    // ── Schema ────────────────────────────────────────────────────────────────

    private void createTables() throws SQLException {
        try (Statement s = conn.createStatement()) {
            s.execute("""
                CREATE TABLE IF NOT EXISTS custom_recipes (
                    id            INTEGER PRIMARY KEY AUTOINCREMENT,
                    type          TEXT    NOT NULL,
                    recipe_id     TEXT    NOT NULL UNIQUE,
                    consume_input INTEGER NOT NULL DEFAULT 1,
                    fields_json   TEXT    NOT NULL,
                    created_at    TEXT    NOT NULL DEFAULT (datetime('now'))
                )
            """);
        }
    }

    // ── CRUD ──────────────────────────────────────────────────────────────────

    /**
     * Insert or replace a recipe entry.
     * @return true if saved successfully
     */
    public boolean saveRecipe(String type, String recipeId, boolean consumeInput, List<String> fields) {
        if (conn == null) return false;
        String rid = recipeId.isBlank()
                ? "auto_" + System.currentTimeMillis()
                : recipeId.strip();
        try (PreparedStatement ps = conn.prepareStatement(
                "INSERT OR REPLACE INTO custom_recipes (type, recipe_id, consume_input, fields_json) VALUES (?,?,?,?)")) {
            ps.setString(1, type);
            ps.setString(2, rid);
            ps.setInt(3, consumeInput ? 1 : 0);
            ps.setString(4, toJsonArray(fields));
            ps.executeUpdate();
            LOGGER.info("[CNR-DB] Saved recipe: {} ({})", rid, type);
            return true;
        } catch (SQLException e) {
            LOGGER.error("[CNR-DB] Failed to save recipe '{}': {}", rid, e.getMessage());
            return false;
        }
    }

    /**
     * Delete a recipe by its recipe_id.
     * @return true if a row was deleted
     */
    public boolean deleteRecipe(String recipeId) {
        if (conn == null) return false;
        try (PreparedStatement ps = conn.prepareStatement(
                "DELETE FROM custom_recipes WHERE recipe_id = ?")) {
            ps.setString(1, recipeId);
            int n = ps.executeUpdate();
            if (n > 0) LOGGER.info("[CNR-DB] Deleted recipe: {}", recipeId);
            return n > 0;
        } catch (SQLException e) {
            LOGGER.error("[CNR-DB] Failed to delete recipe '{}': {}", recipeId, e.getMessage());
            return false;
        }
    }

    /**
     * Return all saved custom recipes, newest-first.
     */
    public List<CustomRecipeEntry> getAllRecipes() {
        List<CustomRecipeEntry> result = new ArrayList<>();
        if (conn == null) return result;
        try (Statement s = conn.createStatement();
             ResultSet rs = s.executeQuery(
                     "SELECT type, recipe_id, consume_input, fields_json, created_at " +
                     "FROM custom_recipes ORDER BY id DESC")) {
            while (rs.next()) {
                result.add(new CustomRecipeEntry(
                        rs.getString("type"),
                        rs.getString("recipe_id"),
                        rs.getInt("consume_input") != 0,
                        fromJsonArray(rs.getString("fields_json")),
                        rs.getString("created_at")
                ));
            }
        } catch (SQLException e) {
            LOGGER.error("[CNR-DB] Failed to list recipes: {}", e.getMessage());
        }
        return result;
    }

    // ── JSON helpers (no external deps) ──────────────────────────────────────

    /** Serialize a list of strings into a minimal JSON array. */
    static String toJsonArray(List<String> fields) {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < fields.size(); i++) {
            if (i > 0) sb.append(",");
            sb.append('"')
              .append(fields.get(i).replace("\\", "\\\\").replace("\"", "\\\""))
              .append('"');
        }
        sb.append("]");
        return sb.toString();
    }

    /** Deserialize a minimal JSON array string into a list of strings. */
    static List<String> fromJsonArray(String json) {
        List<String> out = new ArrayList<>();
        if (json == null || json.isBlank()) return out;
        json = json.strip();
        if (!json.startsWith("[") || !json.endsWith("]")) return out;
        json = json.substring(1, json.length() - 1).strip();
        if (json.isEmpty()) return out;

        boolean inQ = false, esc = false;
        StringBuilder cur = new StringBuilder();
        for (char c : json.toCharArray()) {
            if (esc) { cur.append(c); esc = false; }
            else if (c == '\\') { esc = true; cur.append(c); }
            else if (c == '"') { inQ = !inQ; }
            else if (c == ',' && !inQ) {
                out.add(cur.toString().strip()
                           .replaceAll("^\"|\"$", "")
                           .replace("\\\"", "\"")
                           .replace("\\\\", "\\"));
                cur.setLength(0);
            } else { cur.append(c); }
        }
        if (!cur.isEmpty())
            out.add(cur.toString().strip()
                       .replaceAll("^\"|\"$", "")
                       .replace("\\\"", "\"")
                       .replace("\\\\", "\\"));
        return out;
    }

    // ── Data record ──────────────────────────────────────────────────────────

    public record CustomRecipeEntry(
            String type,
            String recipeId,
            boolean consumeInput,
            List<String> fields,
            String createdAt
    ) {}
}
