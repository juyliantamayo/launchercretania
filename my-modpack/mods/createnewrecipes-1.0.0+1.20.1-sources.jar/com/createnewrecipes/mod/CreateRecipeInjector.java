package com.createnewrecipes.mod;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1860;
import net.minecraft.class_1863;
import net.minecraft.class_1865;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

/**
 * Converts CustomRecipeEntry objects (stored in SQLite) into live Minecraft
 * Recipe<?> instances and injects them into the server's RecipeManager.
 *
 * Each Create processing type is handled by a dedicated JSON builder that maps
 * the stored field list (same order as RecipeBlockerScreen.TYPES) to a valid
 * Create recipe JSON object, which is then deserialized via the registered
 * RecipeSerializer.
 *
 * Call injectAll() after RecipeRegistry.reapplyBlocking() so custom recipes
 * are added on top of the clean (de-blocked) recipe maps.
 */
public final class CreateRecipeInjector {

    private static final Logger LOGGER = LoggerFactory.getLogger("createnewrecipes.inject");

    private CreateRecipeInjector() {}

    // =========================================================================
    //  Public API
    // =========================================================================

    /**
     * Injects all custom recipes from {@code entries} into the live RecipeManager.
     * Existing entries with the {@code createnewrecipes:} namespace are replaced.
     * Safe to call from the server thread.
     */
    @SuppressWarnings({"rawtypes", "unchecked"})
    public static void injectAll(class_1863 manager,
                                 List<RecipeDatabase.CustomRecipeEntry> entries) {
        if (entries == null || entries.isEmpty()) return;

        // Read current recipes using public API (reliable, no accessor)
        Map<class_2960, class_1860<?>> byName = new HashMap<>();
        for (class_1860<?> r : manager.method_8126()) {
            byName.put(r.method_8114(), r);
        }

        int injected = 0;
        for (RecipeDatabase.CustomRecipeEntry entry : entries) {
            try {
                JsonObject json = buildJson(entry.type(), entry.fields());
                if (json == null) {
                    LOGGER.warn("[CNR] No JSON builder for type '{}' (recipe '{}') — skipped.",
                            entry.type(), entry.recipeId());
                    continue;
                }
                class_2960 typeId = new class_2960(entry.type());
                class_1865 ser = class_7923.field_41189.method_10223(typeId);
                if (ser == null) {
                    LOGGER.warn("[CNR] No serializer for '{}' — is Create installed? (recipe '{}' skipped)",
                            entry.type(), entry.recipeId());
                    continue;
                }
                class_2960 id = safeId(entry.recipeId());
                class_1860<?> recipe = ser.method_8121(id, json);
                byName.put(id, recipe);
                injected++;
            } catch (Exception ex) {
                LOGGER.warn("[CNR] Failed to inject recipe '{}': {}",
                        entry.recipeId(), ex.getMessage());
            }
        }

        // Write back using vanilla replaceRecipes() — guaranteed to set the fields
        manager.method_20702(byName.values());

        if (injected > 0)
            LOGGER.info("[CNR] Injected {} custom Create recipe(s) into the recipe system.", injected);
    }

    // =========================================================================
    //  Dispatch
    // =========================================================================

    /**
     * Builds a JsonObject for the given Create recipe type and field list.
     * Returns null when the type is unsupported or required fields are blank.
     *
     * Field order matches RecipeBlockerScreen.TYPES (client-side definition):
     *
     *  create:deploying         [OUT=0, IN=1,  IN2=2]
     *  create:mixing            [OUT=0, IN=1,  IN2=2, IN3=3, HEAT=4]
     *  create:crushing          [IN=0,  OUT=1, OUT2=2(+chance%), TIME=3]
     *  create:cutting           [IN=0,  OUT=1, TIME=2]
     *  create:compacting        [OUT=0, IN=1,  IN2=2, IN3=3, HEAT=4]
     *  create:mechanical_crafting [OUT=0, PAT1=1, PAT2=2, PAT3=3, KEY_A=4, KEY_B=5, KEY_C=6]
     *  create:emptying          [IN=0(filled), FLUID=1, OUT2=2(empty container)]
     *  create:filling           [IN=0(empty),  FLUID=1, OUT=2(filled)]
     *  create:sequenced_assembly → not yet supported (returns null)
     *  simple pair types        [IN=0, OUT=1]
     */
    private static JsonObject buildJson(String type, List<String> fields) {
        return switch (type) {
            case "create:deploying"           -> deploying(fields);
            case "create:mixing"              -> mixing(fields);
            case "create:crushing"            -> crushing(fields);
            case "create:cutting"             -> cutting(fields);
            case "create:compacting"          -> compacting(fields);
            case "create:mechanical_crafting" -> mechCrafting(fields);
            case "create:emptying"            -> emptying(fields);
            case "create:filling"             -> filling(fields);
            case "create:sequenced_assembly"  -> sequencedAssembly(fields);
            // Simple single-input → single-output
            case "create:splashing",
                 "create:pressing",                 "createaddition:rolling",                 "create:rolling",
                 "create:haunting",
                 "create:sandpaper_polishing" -> simpleIO(type, fields);
            default                           -> null;
        };
    }

    // =========================================================================
    //  Per-type JSON builders
    // =========================================================================

    /** create:deploying — fields[OUT=0, IN=1, IN2=2] */
    private static JsonObject deploying(List<String> fields) {
        String out = get(fields, 0), in1 = get(fields, 1), in2 = get(fields, 2);
        if (out.isEmpty() || in1.isEmpty()) return null;
        JsonObject obj = base("create:deploying");
        JsonArray ing = arr(item(in1));
        if (!in2.isEmpty()) ing.add(item(in2));
        obj.add("ingredients", ing);
        obj.add("results", arr(item(out)));
        return obj;
    }

    /** create:mixing — fields[OUT=0, IN=1, IN2=2, IN3=3(opt), HEAT=4(opt)] */
    private static JsonObject mixing(List<String> fields) {
        String out = get(fields, 0);
        if (out.isEmpty()) return null;
        JsonArray ing = new JsonArray();
        for (int i = 1; i <= 3; i++) {
            String v = get(fields, i);
            if (!v.isEmpty()) ing.add(item(v));
        }
        if (ing.size() == 0) return null;
        JsonObject obj = base("create:mixing");
        obj.add("ingredients", ing);
        obj.add("results", arr(item(out)));
        String heat = get(fields, 4).toLowerCase();
        if (heat.equals("heated") || heat.equals("superheated"))
            obj.addProperty("heatRequirement", heat);
        return obj;
    }

    /** create:crushing — fields[IN=0, OUT=1, OUT2=2(opt+chance%), TIME=3(opt)] */
    private static JsonObject crushing(List<String> fields) {
        String in = get(fields, 0), out = get(fields, 1);
        if (in.isEmpty() || out.isEmpty()) return null;
        JsonObject obj = base("create:crushing");
        obj.add("ingredients", arr(item(in)));
        JsonArray results = arr(item(out));
        String out2 = get(fields, 2);
        if (!out2.isEmpty()) results.add(itemWithChance(out2));
        obj.add("results", results);
        String time = get(fields, 3);
        if (!time.isEmpty()) tryInt(obj, "processingTime", time);
        return obj;
    }

    /** create:cutting — fields[IN=0, OUT=1, TIME=2(opt)] */
    private static JsonObject cutting(List<String> fields) {
        String in = get(fields, 0), out = get(fields, 1);
        if (in.isEmpty() || out.isEmpty()) return null;
        JsonObject obj = base("create:cutting");
        obj.add("ingredients", arr(item(in)));
        obj.add("results", arr(item(out)));
        String time = get(fields, 2);
        if (!time.isEmpty()) tryInt(obj, "processingTime", time);
        return obj;
    }

    /** create:compacting — fields[OUT=0, IN=1, IN2=2, IN3=3(opt), HEAT=4(opt)] */
    private static JsonObject compacting(List<String> fields) {
        String out = get(fields, 0);
        if (out.isEmpty()) return null;
        JsonArray ing = new JsonArray();
        for (int i = 1; i <= 3; i++) {
            String v = get(fields, i);
            if (!v.isEmpty()) ing.add(item(v));
        }
        if (ing.size() == 0) return null;
        JsonObject obj = base("create:compacting");
        obj.add("ingredients", ing);
        obj.add("results", arr(item(out)));
        String heat = get(fields, 4).toLowerCase();
        if (heat.equals("heated") || heat.equals("superheated"))
            obj.addProperty("heatRequirement", heat);
        return obj;
    }

    /**
     * create:mechanical_crafting
     * fields[OUT=0, PATTERN_ROW1=1, PATTERN_ROW2=2(opt), PATTERN_ROW3=3(opt),
     *        KEY_A=4, KEY_B=5(opt), KEY_C=6(opt)]
     */
    private static JsonObject mechCrafting(List<String> fields) {
        String out = get(fields, 0);
        if (out.isEmpty()) return null;
        JsonArray pattern = new JsonArray();
        for (int i = 1; i <= 3; i++) {
            String row = get(fields, i);
            if (!row.isEmpty()) pattern.add(row.trim().toUpperCase());
        }
        if (pattern.size() == 0) return null;
        JsonObject key = new JsonObject();
        String[] keys = {"A", "B", "C"};
        for (int i = 0; i < 3; i++) {
            String v = get(fields, 4 + i);
            if (!v.isEmpty()) key.add(keys[i], item(v));
        }
        if (key.size() == 0) return null;
        JsonObject obj = base("create:mechanical_crafting");
        obj.add("pattern", pattern);
        obj.add("key", key);
        obj.add("result", item(out));   // mechanical_crafting uses "result" (singular)
        return obj;
    }

    /**
     * create:emptying
     * fields[IN=0(filled container), FLUID_OUT=1("namespace:fluid amount mb"), EMPTY_OUT=2]
     */
    private static JsonObject emptying(List<String> fields) {
        String in = get(fields, 0);
        if (in.isEmpty()) return null;
        JsonObject obj = base("create:emptying");
        obj.add("ingredients", arr(item(in)));
        JsonArray results = new JsonArray();
        String fluidStr = get(fields, 1);
        if (!fluidStr.isEmpty()) results.add(fluidEntry(fluidStr));
        String emptyContainer = get(fields, 2);
        if (!emptyContainer.isEmpty()) results.add(item(emptyContainer));
        if (results.size() == 0) return null;
        obj.add("results", results);
        return obj;
    }

    /**
     * create:filling
     * fields[IN=0(empty container), FLUID_IN=1("namespace:fluid amount mb"), OUT=2(filled)]
     */
    private static JsonObject filling(List<String> fields) {
        String in = get(fields, 0), out = get(fields, 2);
        if (in.isEmpty() || out.isEmpty()) return null;
        JsonObject obj = base("create:filling");
        JsonArray ing = arr(item(in));
        String fluidStr = get(fields, 1);
        if (!fluidStr.isEmpty()) ing.add(fluidEntry(fluidStr));
        obj.add("ingredients", ing);
        obj.add("results", arr(item(out)));
        return obj;
    }

    /**
     * create:sequenced_assembly
     * fields[OUT=0, TRANSITION=1, STEP1=2, STEP2=3(opt), STEP3=4(opt), STEP4=5(opt)]
     * Each step string: "create:deploying minecraft:iron_nugget" or "create:pressing"
     */
    private static JsonObject sequencedAssembly(List<String> fields) {
        String out = get(fields, 0), trans = get(fields, 1);
        if (out.isEmpty() || trans.isEmpty()) return null;

        JsonArray sequence = new JsonArray();
        for (int i = 2; i <= 5; i++) {
            String step = get(fields, i);
            if (step.isEmpty()) continue;
            String[] parts = step.trim().split("\\s+");
            String stepType = parts[0];

            JsonObject stepObj = new JsonObject();
            stepObj.addProperty("type", stepType);

            JsonArray stepIng = new JsonArray();
            stepIng.add(item(trans)); // transitional item always first
            if (parts.length >= 2) stepIng.add(item(parts[1]));
            stepObj.add("ingredients", stepIng);
            stepObj.add("results", arr(item(trans)));

            // deploying with a held tool — keep the tool
            if ("create:deploying".equals(stepType) && parts.length >= 2)
                stepObj.addProperty("keepHeldItem", true);

            sequence.add(stepObj);
        }
        if (sequence.size() == 0) return null;

        JsonObject obj = new JsonObject();
        obj.addProperty("type", "create:sequenced_assembly");
        obj.add("ingredient", item(trans));
        obj.add("results", arr(item(out)));
        obj.add("sequence", sequence);
        obj.add("transitionalItem", item(trans));
        obj.addProperty("loops", 1);
        return obj;
    }

    /** Simple single-input, single-output: fields[IN=0, OUT=1] */
    private static JsonObject simpleIO(String type, List<String> fields) {
        String in = get(fields, 0), out = get(fields, 1);
        if (in.isEmpty() || out.isEmpty()) return null;
        JsonObject obj = base(type);
        obj.add("ingredients", arr(item(in)));
        obj.add("results", arr(item(out)));
        return obj;
    }

    // =========================================================================
    //  JSON micro-helpers
    // =========================================================================

    private static JsonObject base(String type) {
        JsonObject o = new JsonObject();
        o.addProperty("type", type);
        return o;
    }

    private static JsonArray arr(JsonObject first) {
        JsonArray a = new JsonArray();
        if (first != null) a.add(first);
        return a;
    }

    /**
     * Parses "namespace:item [count] [nc]" → { "item": "...", "count": N }
     * The optional "nc" suffix (not-consumed marker added by the GUI) is stripped here.
     * Count is omitted if == 1.
     */
    private static JsonObject item(String raw) {
        raw = raw.trim();
        // Strip trailing "nc" tag
        String lower = raw.toLowerCase();
        if (lower.endsWith(" nc")) raw = raw.substring(0, raw.length() - 3).trim();
        String[] parts = raw.split("\\s+");
        JsonObject o = new JsonObject();
        o.addProperty("item", parts[0]);
        if (parts.length >= 2) {
            try {
                int c = Integer.parseInt(parts[1]);
                if (c > 1) o.addProperty("count", c);
            } catch (NumberFormatException ignored) {}
        }
        return o;
    }

    /**
     * Parses "namespace:item [count] [chance%] [nc]" → result entry that may include chance.
     * E.g. "minecraft:flint 50%" → { "item": "minecraft:flint", "chance": 0.5 }
     */
    private static JsonObject itemWithChance(String raw) {
        raw = raw.trim();
        // Strip trailing "nc" tag
        String lower = raw.toLowerCase();
        if (lower.endsWith(" nc")) raw = raw.substring(0, raw.length() - 3).trim();
        String[] parts = raw.split("\\s+");
        JsonObject o = new JsonObject();
        o.addProperty("item", parts[0]);
        for (int i = 1; i < parts.length; i++) {
            String p = parts[i];
            if (p.endsWith("%")) {
                try { o.addProperty("chance", Float.parseFloat(p.replace("%", "")) / 100f); }
                catch (NumberFormatException ignored) {}
            } else {
                try {
                    int c = Integer.parseInt(p);
                    if (c > 1) o.addProperty("count", c);
                } catch (NumberFormatException ignored) {}
            }
        }
        return o;
    }

    /**
     * Parses "namespace:fluid [amount] [mb]" → fluid ingredient/result entry.
     * E.g. "minecraft:water 1000 mb" → { "fluid": "minecraft:water", "amount": 1000 }
     */
    private static JsonObject fluidEntry(String raw) {
        raw = raw.trim();
        String[] p = raw.split("\\s+");
        JsonObject o = new JsonObject();
        o.addProperty("fluid", p[0]);
        int amount = 1000; // Create default fluid amount
        if (p.length >= 2) {
            try { amount = Integer.parseInt(p[1]); } catch (NumberFormatException ignored) {}
        }
        o.addProperty("amount", amount);
        return o;
    }

    /** Adds an int property from a string; silently ignores non-integer strings. */
    private static void tryInt(JsonObject obj, String key, String raw) {
        try { obj.addProperty(key, Integer.parseInt(raw.trim())); }
        catch (NumberFormatException ignored) {}
    }

    /** Returns the field value at {@code idx}, trimmed, or "" if absent/null. */
    private static String get(List<String> list, int idx) {
        if (list == null || idx >= list.size()) return "";
        String v = list.get(idx);
        return v == null ? "" : v.trim();
    }

    /**
     * Converts a user-entered recipe ID to a valid ResourceLocation.
     * Accepts both "my_recipe" (→ createnewrecipes:my_recipe) and
     * "namespace:my_recipe" (→ namespace:my_recipe). The colon is preserved.
     */
    private static class_2960 safeId(String raw) {
        raw = raw.trim().toLowerCase();
        int colon = raw.indexOf(':');
        String namespace, path;
        if (colon > 0) {
            namespace = raw.substring(0, colon).replaceAll("[^a-z0-9_.-]", "_");
            path      = raw.substring(colon + 1).replace(' ', '_').replaceAll("[^a-z0-9/_.-]", "_");
        } else {
            namespace = "createnewrecipes";
            path      = raw.replace(' ', '_').replaceAll("[^a-z0-9/_.-]", "_");
        }
        if (namespace.isEmpty()) namespace = "createnewrecipes";
        if (path.isEmpty()) path = "custom_" + System.currentTimeMillis();
        return new class_2960(namespace, path);
    }
}
