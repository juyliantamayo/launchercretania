package com.createnewrecipes.mod.network;

import net.minecraft.class_2960;

/**
 * Network channel identifiers and operation codes for the in-game config GUI.
 *
 * Flow:
 *   1. Client sends C2S_REQUEST (empty) → server sends S2C_DATA back.
 *   2. Client sends C2S_MODIFY (byte op + String value) → server applies, saves, hot-reloads.
 */
public final class ConfigPackets {

    /** Client → Server: request full config dump. No payload. */
    public static final class_2960 C2S_REQUEST =
            new class_2960("createnewrecipes", "c2s_req");

    /** Server → Client: full config snapshot (4 string lists). */
    public static final class_2960 S2C_DATA =
            new class_2960("createnewrecipes", "s2c_data");

    /** Client → Server: apply one add/remove operation. Payload: byte op + String value. */
    public static final class_2960 C2S_MODIFY =
            new class_2960("createnewrecipes", "c2s_mod");

    /**
     * Client → Server: save a new Create recipe JSON to the config folder.
     * Payload: String type, String id, boolean consumeInput (byte), VarInt fieldCount, String... fieldValues
     */
    public static final class_2960 C2S_NEW_RECIPE =
            new class_2960("createnewrecipes", "c2s_new_recipe");

    /** Server → Client: list of all saved custom recipes. */
    public static final class_2960 S2C_CUSTOM_RECIPES =
            new class_2960("createnewrecipes", "s2c_custom");

    /** Client → Server: delete a saved custom recipe. Payload: String recipe_id */
    public static final class_2960 C2S_DELETE_CUSTOM =
            new class_2960("createnewrecipes", "c2s_del_custom");

    // ── Operation codes for C2S_MODIFY ──────────────────────────────────────
    public static final byte ADD_RECIPE     = 0;
    public static final byte REMOVE_RECIPE  = 1;
    public static final byte ADD_ITEM       = 2;
    public static final byte REMOVE_ITEM    = 3;
    public static final byte ADD_BLOCK      = 4;
    public static final byte REMOVE_BLOCK   = 5;
    public static final byte ADD_MOD        = 6;
    public static final byte REMOVE_MOD     = 7;

    private ConfigPackets() {}
}
